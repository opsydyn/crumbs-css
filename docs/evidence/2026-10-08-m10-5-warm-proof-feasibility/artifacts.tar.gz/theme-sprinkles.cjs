Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_theme_sprinkles_resolver = require("./theme-sprinkles-resolver-B7H6mMc3.cjs");
exports.createSprinklesResolver = require_theme_sprinkles_resolver.createSprinklesResolver;
