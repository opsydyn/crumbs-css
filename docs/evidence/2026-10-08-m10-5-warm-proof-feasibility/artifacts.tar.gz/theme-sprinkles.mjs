import { t as createSprinklesResolver } from "./theme-sprinkles-resolver-BovVAHPp.mjs";
export { createSprinklesResolver };
