import { _ as nativeThemeValuesBrand, f as ThemeVar, o as NativeThemeVar, r as LegacyNativeThemeVar } from "./theme-token-t1oauSi6.mjs";

//#region src/theme-contract.d.ts
/** The legacy, unscoped shape accepted by createThemeContract. */
type ThemeContractInput = {
  readonly [key: string]: ThemeContractInput | null;
};
type NativeThemeValue = string | number;
type ThemeContract<T extends ThemeContractInput> = { readonly [K in keyof T]: T[K] extends null ? LegacyNativeThemeVar : T[K] extends ThemeContractInput ? ThemeContract<T[K]> : never };
type LegacyThemeValues<T> = { readonly [K in keyof T]: T[K] extends NativeThemeVar ? NativeThemeValue : T[K] extends Record<string, unknown> ? LegacyThemeValues<T[K]> : never };
type ThemeValues<T> = T extends {
  readonly [nativeThemeValuesBrand]: infer TValues;
} ? TValues : LegacyThemeValues<T>;
type NativeTheme<TContract> = {
  readonly contract: TContract;
  readonly tokens: Readonly<Record<string, NativeThemeValue>>;
  readonly values: ThemeValues<TContract>;
};
declare function createThemeContract<T extends ThemeContractInput>(shape: T): ThemeContract<T>;
declare function createTheme<TContract extends Record<string, unknown>>(contract: TContract, values: ThemeValues<TContract>): NativeTheme<TContract>;
declare function isThemeVar(value: unknown): value is ThemeVar;
declare function getThemeVarName(value: ThemeVar): string;
declare function getThemeTokenPath(value: ThemeVar): ReadonlyArray<string>;
//#endregion
export { ThemeValues as a, getThemeTokenPath as c, ThemeContractInput as i, getThemeVarName as l, NativeThemeValue as n, createTheme as o, ThemeContract as r, createThemeContract as s, NativeTheme as t, isThemeVar as u };