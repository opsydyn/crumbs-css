import { n as createNativeStylesCacheStore, t as withNativeStyles } from "./metro-plugin-BkIX4OVP.mjs";
export { createNativeStylesCacheStore, withNativeStyles };