import {afterAll,describe,expect,test} from 'bun:test'
import {mkdtempSync,writeFileSync,rmSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {createHash} from 'node:crypto'
let api:any={}
try { api=await import('../test-support/contract-kernel-qualification') } catch(error:any) { if(!String(error).includes('Cannot find module')) throw error }
const dir=mkdtempSync(join(tmpdir(),'crumbs-kernel-oracle-test-'))
afterAll(()=>rmSync(dir,{recursive:true,force:true}))
const file=join(dir,'kernel.mjs'),bytes='export const value=1;\n'
writeFileSync(file,bytes)
const hash=(s:string)=>createHash('sha256').update(s).digest('hex')
function fixture(){
 const identity={version:1,cacheable:true,files:[{sourcePath:join(dir,'entry.css.ts'),sourceHash:hash('entry'),canonicalPath:join(dir,'entry.css.ts')}],links:[]}
 const proof={kind:'current',entryHash:hash('entry'),inputs:{'entry.css.ts':{bytes:5,imports:[]}},resolutionIdentity:identity,context:{compilerKey:'control:style-explanations=0',platform:'ios',dev:true,strictDiagnostics:true,useStyleSheet:true,identOption:'debug'},dependencies:[]}
 // Hand-checked fixed vector for the unchanged marker recipe, not production code.
 const marker='90cecee5c8301e003938fb09456121d32b6a4a90f3601a089c000f121b15c893'
 return {version:1,case:'literal',status:'ok',code:`/* @crumbs-native-cache ${marker} */\nexport const value = 1;`,proof,metadata:{$$type:'crumbs.css.transform-cache',dependencies:[],resolutionIdentity:identity},maps:{direct:[[1,0,1,0]],nested:[]},observation:{kind:'number',value:1},authoredInputs:[],privateInputs:[{path:file,sha256:hash(bytes),bytes:Buffer.byteLength(bytes)}],externalVersions:{integration:'8.0.10'},sidecar:null,diagnostics:[],events:[],error:null,provenance:{packageRoot:dir,repoRoot:dir,format:'esm',pid:1,node:'v22.0.0',compilerKey:'control',keyOwner:{path:file,sha256:hash(bytes)}}}
}
// Stable paths are part of this vector: replace them with fixed strings before hashing.
function fixed(){const r=fixture();r.proof.resolutionIdentity.files[0]={sourcePath:'/fixture/entry.css.ts',sourceHash:hash('entry'),canonicalPath:'/fixture/entry.css.ts'};r.metadata.resolutionIdentity=r.proof.resolutionIdentity;return r}
describe('independent kernel qualification oracle',()=>{
 test('rejects_forged_marker_or_private_inventory',()=>{
  expect(typeof api.verifyCurrentMarker).toBe('function')
  const r=fixed();expect(api.verifyCurrentMarker(r)).toEqual([])
  const bad=structuredClone(r);bad.code=bad.code.replace(/cache [a-f0-9]{64}/,'cache '+'0'.repeat(64));expect(api.verifyCurrentMarker(bad).length).toBeGreaterThan(0)
  const forged=structuredClone(r);forged.privateInputs[0].sha256='0'.repeat(64);expect(api.compareKernelTransformReceipts(r,forged).length).toBeGreaterThan(0)
 })
 test('rejects_changed_native_value_symbol_descriptor_or_map',()=>{
  expect(typeof api.compareKernelTransformReceipts).toBe('function')
  const r=fixed();expect(api.compareKernelTransformReceipts(r,structuredClone(r))).toEqual([])
  for(const field of ['observation','maps','diagnostics','events','authoredInputs','externalVersions','sidecar']){const bad:any=structuredClone(r);bad[field]={changed:true};expect(api.compareKernelTransformReceipts(r,bad).length).toBeGreaterThan(0)}
  const bad=structuredClone(r);bad.code+='\nthrow new Error("bad");';expect(api.compareKernelTransformReceipts(r,bad).length).toBeGreaterThan(0)
 })
 test('rejects_unknown_or_missing_receipt_fields',()=>{
  expect(typeof api.compareKernelTransformReceipts).toBe('function')
  const r=fixed();expect(api.compareKernelTransformReceipts(r,{...r,unknown:1}).length).toBeGreaterThan(0)
  const bad:any=structuredClone(r);delete bad.proof;expect(api.compareKernelTransformReceipts(r,bad).length).toBeGreaterThan(0)
  bad.proof={kind:'crumbs-fresh-input-v1'};expect(api.verifyCurrentMarker(bad).length).toBeGreaterThan(0)
  expect(api.compareKernelTransformReceipts(r,null).length).toBeGreaterThan(0)
 })
 test('rejects_unapproved_path_alignment',()=>{
  expect(typeof api.compareKernelTransformReceipts).toBe('function')
  const r=fixed(),bad=structuredClone(r);bad.code=bad.code.replace('value = 1','value = 2');expect(api.compareKernelTransformReceipts(r,bad).length).toBeGreaterThan(0)
  bad.code=r.code;bad.proof.dependencies=[{importPath:'./changed.css.ts',sourceHash:hash('different')}];expect(api.verifyCurrentMarker(bad).length).toBeGreaterThan(0)
 })
})

test('compiled_floor_node_worker_evaluates_native_output_without_reexecuting_tracking_imports',async()=>{
 const {readFileSync}=await import('node:fs'),{resolve}=await import('node:path')
 const inputs=JSON.parse(readFileSync(resolve(import.meta.dir,'../../../../inputs.json'),'utf8'))
 const request=join(dir,'node-request.json')
 writeFileSync(request,JSON.stringify({packageRoot:join(inputs.controlRepoRoot,'packages/css'),format:'esm',cases:[{filename:'examples/recipe.css.ts',projectRoot:'.',platform:'ios',dev:true,strictDiagnostics:true,useStyleSheet:true,step:'baseline',mapShape:'tuples'}]}))
 const child=Bun.spawn([inputs.floorNode,resolve(import.meta.dir,'../test-support/contract-kernel-worker.mjs'),request],{stdout:'pipe',stderr:'pipe'})
 const [code,stdout,stderr]=await Promise.all([child.exited,new Response(child.stdout).text(),new Response(child.stderr).text()])
 expect({code,stderr}).toEqual({code:0,stderr:''})
 const row=JSON.parse(stdout.split('CRUMBS_KERNEL_RECEIPT ')[1]!.trim())[0]
 expect(api.verifyCurrentMarker(row)).toEqual([])
 expect(row.observation.properties.length).toBeGreaterThan(0)
},20000)

test('compiled_floor_node_worker_uses_explicit_dual_format_runtime_factory_package',async()=>{
 const {readFileSync}=await import('node:fs'),{resolve}=await import('node:path')
 const inputs=JSON.parse(readFileSync(resolve(import.meta.dir,'../../../../inputs.json'),'utf8'))
 const request=join(dir,'factory-request.json')
 writeFileSync(request,JSON.stringify({packageRoot:join(inputs.controlRepoRoot,'packages/css'),format:'esm',cases:[{filename:'fixtures/.contract-kernel-owned/factory.css.ts',projectRoot:'.',platform:'ios',dev:true,strictDiagnostics:true,useStyleSheet:true,step:'baseline',mapShape:'tuples'}]}))
 const child=Bun.spawn([inputs.floorNode,resolve(import.meta.dir,'../test-support/contract-kernel-worker.mjs'),request],{stdout:'pipe',stderr:'pipe'})
 const [code,stdout,stderr]=await Promise.all([child.exited,new Response(child.stdout).text(),new Response(child.stderr).text()])
 expect({code,stderr}).toEqual({code:0,stderr:''})
 const row=JSON.parse(stdout.split('CRUMBS_KERNEL_RECEIPT ')[1]!.trim())[0]
 expect(api.verifyCurrentMarker(row)).toEqual([])
 expect(row.observation.properties.some((p:any)=>p.key==='wrapped')).toBe(true)
},20000)

test('requires_complete_graph_guards_and_both_H1_closure_limits',()=>{
 expect(typeof api.assessKernelStructure).toBe('function')
 const good={exportRows:59,ordinaryRows:30,sourceGuardFailures:0,kernelExternals:0,duplicateMembers:0,esmStyleFiles:3,cjsStyleFiles:4,nonliteralLoads:0}
 expect(api.assessKernelStructure(good)).toEqual([])
 for(const bad of [{...good,exportRows:58},{...good,ordinaryRows:29},{...good,sourceGuardFailures:1},{...good,kernelExternals:1},{...good,duplicateMembers:1},{...good,esmStyleFiles:4},{...good,cjsStyleFiles:5},{...good,nonliteralLoads:1}])expect(api.assessKernelStructure(bad).length).toBeGreaterThan(0)
})
