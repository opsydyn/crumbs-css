import {afterAll,describe,expect,test} from 'bun:test'
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,cpSync,rmSync,existsSync,readdirSync,symlinkSync,realpathSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {join,resolve,basename} from 'node:path'
import {createHash} from 'node:crypto'
let kernel:any={},linker:any={},driver:any={}
for(const [name,set] of [['../build/contract-kernel.mjs',(v:any)=>kernel=v],['../build/contract-kernel-link.mjs',(v:any)=>linker=v],['../build.mjs',(v:any)=>driver=v]] as const){try{set(await import(name))}catch(error){if(!String(error).includes('Cannot find module'))throw error}}
const five=['src/diagnostics.ts','src/tokens/identity.ts','src/theme-token.ts','src/theme-contract.ts','src/tokens/domain-values.ts']
const facade='src/internal/contract-kernel.ts'
const exports40=['NativeStylesDiagnosticCode','formatNativeStylesDiagnostic','encodeTokenPath','normalizeTokenContractIdentity','tokenContractIdentityKey','tokenContractShapeSignature','tokenContractVisibilitySignature','tokenPublicId','tokenVariableName','NativeThemeTokenReferenceType','assertThemeContractIdentityAvailable','assertThemeTokenReference','createThemeTokenReference','getThemeContractIdentity','getThemeContractIdentityKey','getThemeContractShapeSignature','getThemeTokenAliasForContract','getThemeTokenDomainForContract','getThemeTokenLocalDomain','getThemeTokenMetadata','getThemeTokenOrigin','getThemeTokenPublicId','getThemeTokenVisibility','isRegisteredThemeVar','isThemeTokenContract','isThemeTokenOwnedByContract','isThemeTokenReference','isThemeTokenReferenceCandidate','registerThemeContractIdentity','registerThemeTokenContract','registerThemeTokenReference','validateThemeTokenValueForContract','createTheme','createThemeContract','getThemeTokenPath','getThemeVarName','isThemeVar','isTokenDomainValue','normalizeTokenDomainDefinition','tokenDomainsEqual'].sort()
const roots:string[]=[];afterAll(()=>roots.forEach(p=>rmSync(p,{recursive:true,force:true})))
function fixture(){
 const root=realpathSync(mkdtempSync(join(tmpdir(),'crumbs-kernel-build-test-')));roots.push(root)
 const packageRoot=join(root,'pkg'),stageRoot=join(root,'stage'),outDir=join(packageRoot,'dist');mkdirSync(stageRoot);mkdirSync(outDir,{recursive:true})
 for(const name of five){const dest=join(packageRoot,name);mkdirSync(resolve(dest,'..'),{recursive:true});cpSync(resolve(import.meta.dir,'..',name),dest)}
 mkdirSync(join(packageRoot,'src/internal'),{recursive:true});writeFileSync(join(packageRoot,facade),five.map(p=>`export * from '../${p.slice(4).replace(/\.ts$/,'')}'`).join('\n'))
 writeFileSync(join(packageRoot,'package.json'),JSON.stringify({name:'fixture',exports:{'.':{types:'./dist/index.d.mts',import:'./dist/index.mjs',require:'./dist/index.cjs'}}}))
 return {root,packageRoot,stageRoot,outDir,generation:basename(stageRoot)}
}
function bundles(f:any){return ['es','cjs'].map(format=>{
 const fileName='raw.'+(format==='es'?'mjs':'cjs'),code=format==='es'?'export const value=1;\n':'exports.value=1;\n';writeFileSync(join(f.stageRoot,fileName),code)
 return {config:{format},outDir:f.stageRoot,chunks:[{outDir:f.stageRoot,type:'chunk',fileName,code,exports:exports40,imports:[],dynamicImports:[],modules:Object.fromEntries([...five,facade].map(id=>[realpathSync(join(f.packageRoot,id)),{}]))}]}
})}
function stage(f:any){return kernel.stageKernelArtifacts({...f,bundles:bundles(f)})}
const hash=(b:Buffer)=>createHash('sha256').update(b).digest('hex')
describe('staged contract kernel',()=>{
 test('retains_exact_kernel_members_exports_and_content_addressed_bytes',()=>{
  expect(typeof kernel.stageKernelArtifacts).toBe('function');const f=fixture(),m=stage(f)
  expect(m.exports).toEqual(exports40);expect(m.sources.map((s:any)=>s.path).sort()).toEqual([...five,facade].map(p=>realpathSync(join(f.packageRoot,p))).sort())
  for(const format of ['es','cjs']){const a=m.artifacts[format],ext=format==='es'?'mjs':'cjs';expect(a.sha256).toBe(hash(readFileSync(a.path)));expect(basename(a.path)).toBe('theme-contract-kernel-'+a.sha256+'.'+ext)}
  expect(Object.isFrozen(m)).toBe(true);expect(Object.isFrozen(m.artifacts.es)).toBe(true)
 })
 test('rejects_extra_members_runtime_externals_and_missing_exports',()=>{
  expect(typeof kernel.stageKernelArtifacts).toBe('function')
  for(const kind of ['node','vanilla','effect','sixth','missing-export']){const f=fixture(),b=bundles(f);if(kind==='missing-export')b[0]!.chunks[0]!.exports=exports40.slice(1);else if(kind==='node')b[0]!.chunks[0]!.imports=['node:fs'];else b[0]!.chunks[0]!.modules[join(f.packageRoot,kind==='sixth'?'src/tokens/domains.ts':'node_modules/'+(kind==='effect'?'effect/index.js':'@vanilla-extract/css/index.js'))]={};expect(()=>kernel.stageKernelArtifacts({...f,bundles:b})).toThrow()}
 })
 test('rejects_stale_or_mutated_manifest_and_wrong_format',()=>{
  expect(typeof kernel.readKernelManifest).toBe('function');const f=fixture(),m=stage(f),file=join(f.stageRoot,'manifest.json'),context={packageRoot:f.packageRoot,outDir:f.outDir}
  expect(kernel.readKernelManifest(file,context)).toEqual(m)
  for(const edit of [(v:any)=>v.generation='wrong',(v:any)=>v.outDir=f.root,(v:any)=>v.sources[0].sha256='0'.repeat(64),(v:any)=>v.artifacts.cjs.path=v.artifacts.es.path,(v:any)=>v.extra=true]){const bad=structuredClone(m);edit(bad);writeFileSync(file,JSON.stringify(bad));expect(()=>kernel.readKernelManifest(file,context)).toThrow()}
  writeFileSync(file,JSON.stringify(m));writeFileSync(m.artifacts.es.path,'changed');expect(()=>kernel.readKernelManifest(file,context)).toThrow()
  expect(typeof linker.createContractKernelLinker).toBe('function');expect(()=>linker.createContractKernelLinker({packageRoot:f.packageRoot,format:'esm',manifest:m})).toThrow()
 })
 test('selects_same_format_exact_source_but_not_other_copy_virtual_or_private_facade',async()=>{
  expect(typeof linker.createContractKernelLinker).toBe('function');const f=fixture(),m=stage(f)
  for(const format of ['es','cjs']){const p=linker.createContractKernelLinker({packageRoot:f.packageRoot,format,manifest:m});expect(p.resolveId.order).toBe('pre');const handler=p.resolveId.handler
   const call=(id:string)=>handler.call({resolve:async(_source:string,_importer:string,options:any)=>{expect(options.skipSelf).toBe(true);return {id}}},'./theme-token',join(f.packageRoot,'src/native-style.ts'))
   expect(await call(join(f.packageRoot,'src/theme-token.ts'))).toEqual({id:m.artifacts[format].path,external:'relative'})
   expect(await call(join(f.packageRoot,facade))).toBe(null)
   const other=join(f.root,'second-copy/theme-token.ts');mkdirSync(resolve(other,'..'),{recursive:true});writeFileSync(other,'export const x=1');expect(await call(other)).toBe(null)
   expect(await handler.call({resolve:()=>{throw Error('virtual must not be resolved')}},'\0virtual',undefined)).toBe(null)
  }
 })
 test('never_follows_output_symlink_and_never_starts_tools_after_kernel_failure',async()=>{
  expect(typeof driver.runPackageBuild).toBe('function');const f=fixture(),outside=join(f.root,'outside');mkdirSync(outside);const sentinel=join(outside,'keep');writeFileSync(sentinel,'preserve');rmSync(f.outDir,{recursive:true});symlinkSync(outside,f.outDir)
  await expect(driver.runPackageBuild(f.packageRoot,async()=>{throw Error('must not start')})).rejects.toThrow();expect(readFileSync(sentinel,'utf8')).toBe('preserve');rmSync(f.outDir);mkdirSync(f.outDir)
  let calls=0,ownedStage='';const before=process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST;process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST='previous-value'
  try{await expect(driver.runPackageBuild(f.packageRoot,async(options:any)=>{calls++;ownedStage=options.outDir;throw Error('kernel-failure')})).rejects.toThrow('kernel-failure');expect(calls).toBe(1);expect(existsSync(ownedStage)).toBe(false);expect(process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST).toBe('previous-value')}finally{before===undefined?delete process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST:process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST=before}
 })
 test('selects_current_generation_with_skip_clean_and_restores_env_after_success',async()=>{
  expect(typeof driver.runPackageBuild).toBe('function');const f=fixture(),old=join(f.outDir,'theme-contract-kernel-'+('f'.repeat(64))+'.mjs');writeFileSync(old,'old');const before={skip:process.env.CRUMBS_CSS_SKIP_CLEAN,manifest:process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST};process.env.CRUMBS_CSS_SKIP_CLEAN='1';process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST='before-success';let calls=0,stagePath=''
  try{await driver.runPackageBuild(f.packageRoot,async(options:any)=>{calls++;if(calls===1){stagePath=options.outDir;return bundles({...f,stageRoot:options.outDir,generation:basename(options.outDir)})}const m=kernel.readKernelManifest(process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST,{packageRoot:f.packageRoot,outDir:f.outDir});expect(m.artifacts.es.path).not.toBe(old);for(const name of ['index.mjs','index.cjs','index.d.mts'])writeFileSync(join(f.outDir,name),'export {};');return []});expect(calls).toBe(2);expect(existsSync(old)).toBe(true);expect(existsSync(stagePath)).toBe(false);expect(process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST).toBe('before-success')}finally{before.skip===undefined?delete process.env.CRUMBS_CSS_SKIP_CLEAN:process.env.CRUMBS_CSS_SKIP_CLEAN=before.skip;before.manifest===undefined?delete process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST:process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST=before.manifest}
 })
})

test('rejects_selected_artifact_symlink_before_overwriting_external_bytes',()=>{
 expect(typeof kernel.stageKernelArtifacts).toBe('function');const f=fixture(),b=bundles(f),outside=join(f.root,'valuable');writeFileSync(outside,'preserve');const digest=hash(Buffer.from(b[0]!.chunks[0]!.code));symlinkSync(outside,join(f.outDir,'theme-contract-kernel-'+digest+'.mjs'))
 expect(()=>kernel.stageKernelArtifacts({...f,bundles:b})).toThrow();expect(readFileSync(outside,'utf8')).toBe('preserve')
})
test('rejects_nested_output_symlinks_before_starting_a_build',async()=>{
 expect(typeof driver.runPackageBuild).toBe('function');const f=fixture(),outside=join(f.root,'outside-public-target');writeFileSync(outside,'preserve');mkdirSync(join(f.outDir,'nested'));symlinkSync(outside,join(f.outDir,'nested','public.mjs'));let started=false
 await expect(driver.runPackageBuild(f.packageRoot,async()=>{started=true;throw Error('unexpected-build')})).rejects.toThrow('Symlink');expect(started).toBe(false);expect(readFileSync(outside,'utf8')).toBe('preserve')
})
