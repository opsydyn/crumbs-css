import {defineConfig} from 'tsdown'
import {runtimeDependencies} from './build-policy.ts'
export default defineConfig({entry:{kernel:'src/internal/contract-kernel.ts'},format:['esm','cjs'],target:'node22',minify:true,shims:false,dts:false,clean:false,deps:runtimeDependencies,outputOptions:{codeSplitting:false}})
