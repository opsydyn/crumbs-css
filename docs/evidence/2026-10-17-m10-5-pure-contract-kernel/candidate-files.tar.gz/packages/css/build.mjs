import {build} from 'tsdown';
import {mkdtempSync,rmSync,lstatSync,readFileSync,existsSync,realpathSync,readdirSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,dirname,resolve,basename} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {stageKernelArtifacts,readKernelManifest} from './build/contract-kernel.mjs';
const dispose=Symbol.asyncDispose||Symbol.for('Symbol.asyncDispose');
function serialize(bundles){return bundles.map(b=>({format:b.config.format,entry:b.config.entry,clean:b.config.clean,dts:b.config.dts,chunks:b.chunks.map(c=>({type:c.type,fileName:c.fileName,outDir:c.outDir,...(c.type==='chunk'?{imports:c.imports,dynamicImports:c.dynamicImports,exports:c.exports,facadeModuleId:c.facadeModuleId,modules:Object.keys(c.modules),bytes:Buffer.byteLength(c.code)}:{})}))}))}
function exportTargets(value,targets=[]){if(typeof value==='string'){if(value.startsWith('./'))targets.push(value)}else if(value&&typeof value==='object')Object.values(value).forEach(v=>exportTargets(v,targets));return targets}
function rejectOutputSymlinks(directory){for(const name of readdirSync(directory)){const path=join(directory,name),stat=lstatSync(path);if(stat.isSymbolicLink())throw Error('Symlink output member '+path);if(stat.isDirectory())rejectOutputSymlinks(path)}}
export async function runPackageBuild(packageRoot,runBuild=build){
 packageRoot=realpathSync(packageRoot);const outDir=join(packageRoot,'dist'),previous=process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST,oldCwd=process.cwd();let stageRoot;const resources=[];
 try{
  try{if(lstatSync(outDir).isSymbolicLink())throw Error('Symlink output destination')}catch(error){if(error.code!=='ENOENT')throw error}
  if(existsSync(outDir))rejectOutputSymlinks(outDir);
  if(process.env.CRUMBS_CSS_SKIP_CLEAN!=='1')rmSync(outDir,{recursive:true,force:true});
  stageRoot=realpathSync(mkdtempSync(join(tmpdir(),'crumbs-contract-kernel-')));process.chdir(packageRoot);
  const raw=await runBuild({config:join(packageRoot,'tsdown.kernel.config.ts'),cwd:packageRoot,outDir:stageRoot,clean:false});resources.push(...raw);
  const kernel=stageKernelArtifacts({packageRoot,stageRoot,outDir,generation:basename(stageRoot),bundles:raw});
  const manifestPath=join(stageRoot,'manifest.json');readKernelManifest(manifestPath,{packageRoot,outDir});process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST=manifestPath;
  const tools=await runBuild({config:join(packageRoot,'tsdown.config.ts'),cwd:packageRoot,outDir,clean:false});resources.push(...tools);
  readKernelManifest(manifestPath,{packageRoot,outDir});
  const pkg=JSON.parse(readFileSync(join(packageRoot,'package.json'),'utf8'));for(const target of exportTargets(pkg.exports))if(!existsSync(resolve(packageRoot,target)))throw Error('Missing public target '+target);
  console.log('CRUMBS_KERNEL_BUILD '+JSON.stringify({kernel,kernelBundles:serialize(raw),toolBundles:serialize(tools)}));
 }finally{
  previous===undefined?delete process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST:process.env.CRUMBS_INTERNAL_KERNEL_MANIFEST=previous;process.chdir(oldCwd);
  try{for(const r of resources)if(typeof r[dispose]==='function')await r[dispose]()}finally{if(stageRoot)rmSync(stageRoot,{recursive:true,force:true})}
 }
}
if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url)await runPackageBuild(dirname(fileURLToPath(import.meta.url)));
