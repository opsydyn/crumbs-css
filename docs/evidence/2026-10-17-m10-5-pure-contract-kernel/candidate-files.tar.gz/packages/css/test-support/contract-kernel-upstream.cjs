exports.transform=async function(config,root,filename,data){
 const code=data.toString();
 const tuples=code.split('\n').flatMap((line,index)=>[...line.matchAll(/[A-Za-z_$][\w$]*/g)].map(match=>[index+1,match.index,index+1,match.index,match[0]]));
 if(config.kernelMapShape==='encoded'){
  const {encode}=require('@jridgewell/sourcemap-codec');
  const lines=[];
  for(const [line,column,sourceLine,sourceColumn] of tuples){while(lines.length<line)lines.push([]);lines[line-1].push([column,0,sourceLine-1,sourceColumn])}
  const map={version:3,sources:[filename],names:[],mappings:encode(lines)};
  return {code,map,output:[{type:'js/module',data:{code,map,lineCount:lines.length}}]};
 }
 return {code,map:tuples,output:[{type:'js/module',data:{code,map:tuples,lineCount:code.split('\n').length}}]};
};
