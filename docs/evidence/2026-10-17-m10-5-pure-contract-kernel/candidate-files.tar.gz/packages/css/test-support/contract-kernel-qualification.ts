import {createHash} from 'node:crypto'
import {readFileSync} from 'node:fs'
const sha=(v:string|Buffer)=>createHash('sha256').update(v).digest('hex')
function record(v:unknown):Record<string,any>{if(v===null||typeof v!=='object'||Array.isArray(v))throw Error('expected record');return v as Record<string,any>}
const keys=['version','case','status','code','proof','metadata','maps','observation','authoredInputs','privateInputs','externalVersions','sidecar','diagnostics','events','error','provenance']
export function verifyCurrentMarker(value:unknown):readonly string[]{
 try{
  const r=record(value),p=record(r.proof),c=record(p.context)
  if(r.status!=='ok'||p.kind!=='current'||typeof r.code!=='string'||!Array.isArray(p.dependencies))throw Error('missing current marker proof')
  const resolutionKey=sha(JSON.stringify({entryHash:p.entryHash,inputs:p.inputs,resolutionIdentity:p.resolutionIdentity}))
  if(typeof p.entryHash!=='string'||!p.inputs||!p.resolutionIdentity||typeof c.compilerKey!=='string')throw Error('incomplete marker material')
  let material='crumbs-native-cache-v1\0'+`compiler=${c.compilerKey}\0platform=${c.platform??''}\0dev=${c.dev?'1':'0'}\0strict=${c.strictDiagnostics?'1':'0'}\0styleSheet=${c.useStyleSheet?'1':'0'}\0ident=${c.identOption}\0`
  for(const d of [...p.dependencies].sort((a,b)=>a.importPath.localeCompare(b.importPath))){if(typeof d.importPath!=='string'||typeof d.sourceHash!=='string')throw Error('invalid authored hash');material+=`${d.importPath}\0${d.sourceHash}\0`}
  material+=`resolution=${resolutionKey}\0`
  const marker=r.code.match(/^\/\* @crumbs-native-cache ([a-f0-9]{64}) \*\//)
  if(!marker||marker[1]!==sha(material))throw Error('marker disagrees with independent current recipe')
  return []
 }catch(e){return [String(e)]}
}
function validate(v:unknown):Record<string,any>{
 const r=record(v)
 if(Object.keys(r).sort().join('|')!==[...keys].sort().join('|'))throw Error('unknown or missing receipt field')
 if(r.version!==1||typeof r.case!=='string'||!['ok','error'].includes(r.status)||!Array.isArray(r.privateInputs))throw Error('invalid receipt schema')
 if(r.status==='ok'){const issues=verifyCurrentMarker(r);if(issues.length)throw Error(issues.join('; '))}
 else if(!r.error||typeof r.error.message!=='string')throw Error('missing error')
 for(const f of r.privateInputs){if(typeof f.path!=='string'||sha(readFileSync(f.path))!==f.sha256||readFileSync(f.path).length!==f.bytes)throw Error('private artifact inventory mismatch')}
 return r
}
export function compareKernelTransformReceipts(control:unknown,candidate:unknown):readonly string[]{
 try{
  const a=validate(control),b=validate(candidate),issues:string[]=[]
  for(const key of ['case','status','observation','maps','authoredInputs','externalVersions','sidecar','diagnostics','events','error','metadata']){
   if(JSON.stringify(a[key])!==JSON.stringify(b[key]))issues.push(`changed ${key}`)
  }
  if(a.status==='ok'&&b.status==='ok'){
   const align=(code:string)=>code.replace(/^(\/\* @crumbs-native-cache )[a-f0-9]{64}( \*\/)/,'$1'+'0'.repeat(64)+'$2')
   if(align(a.code)!==align(b.code))issues.push('changed statements outside verified marker')
   if(JSON.stringify(a.privateInputs)!==JSON.stringify(b.privateInputs))issues.push('changed private inventories (explicit layout correspondence required)')
  }
  return issues
 }catch(e){return [String(e)]}
}
export function assessKernelStructure(value:unknown):readonly string[]{
 const r=record(value),issues:string[]=[]
 for(const [key,want] of [['exportRows',59],['ordinaryRows',30],['sourceGuardFailures',0],['kernelExternals',0],['duplicateMembers',0],['nonliteralLoads',0]] as const)if(r[key]!==want)issues.push(`${key}: ${r[key]} (required ${want})`)
 if(!Number.isInteger(r.esmStyleFiles)||r.esmStyleFiles<1||r.esmStyleFiles>3)issues.push(`H1 ESM style files ${r.esmStyleFiles}; required <=3`)
 if(!Number.isInteger(r.cjsStyleFiles)||r.cjsStyleFiles<1||r.cjsStyleFiles>4)issues.push(`H1 CJS style files ${r.cjsStyleFiles}; required <=4`)
 return issues
}
