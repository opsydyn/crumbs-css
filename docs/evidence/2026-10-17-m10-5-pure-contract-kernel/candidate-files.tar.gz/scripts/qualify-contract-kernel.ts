import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs'
import {resolve,join,relative} from 'node:path'
import {createHash} from 'node:crypto'
import {compareKernelTransformReceipts,verifyCurrentMarker,assessKernelStructure} from '../packages/css/test-support/contract-kernel-qualification'
const [stage,inputsFile]=process.argv.slice(2)
if(!stage||!inputsFile)throw Error('stage and absolute inputs path required')
const inputs=JSON.parse(readFileSync(inputsFile,'utf8')),evidence=inputs.evidenceRoot
const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex')
const json=(p:string,v:unknown)=>writeFileSync(join(evidence,p),JSON.stringify(v,null,2)+'\n')
function check(ok:unknown,message:string):asserts ok{if(!ok)throw Error(message)}
function prior(name:string){const r=JSON.parse(readFileSync(join(evidence,name+'.json'),'utf8'));check(r.status==='pass','failed predecessor '+name)}
function matrix(){
 const cases:any[]=[]
 for(const filename of ['examples/recipe.css.ts','fixtures/consumer/styles/button.css.ts'])for(const platform of ['ios','android','web'])for(const dev of [true,false])for(const strictDiagnostics of [true,false])for(const mapShape of ['tuples','encoded'])cases.push({filename,projectRoot:filename.startsWith('examples')?'.':'fixtures/consumer',platform,dev,strictDiagnostics,useStyleSheet:platform!=='web',step:'baseline',mapShape})
 for(const step of ['baseline','repeat','entry-edit','entry-restore','dependency-edit','dependency-restore','syntax-error','syntax-repair','authoring-error','authoring-repair','ambient-edit','ambient-restore'])cases.push({filename:'owned',projectRoot:'.',platform:'ios',dev:true,strictDiagnostics:true,useStyleSheet:true,step,mapShape:'tuples'})
 for(const filename of ['fixtures/tokens.css.ts','fixtures/primitive-references.css.ts','fixtures/.contract-kernel-owned/factory.css.ts'])cases.push({filename,projectRoot:'.',platform:'ios',dev:true,strictDiagnostics:true,useStyleSheet:true,step:'baseline',mapShape:'tuples'})
 return cases
}
async function workers(repoRoot:string,label:string){
 const results:any[]=[]
 for(const nodeKind of ['floorNode','currentNode'])for(const format of ['esm','cjs']){
  const requestFile=join(evidence,`${label}-${nodeKind}-${format}-request.json`)
  writeFileSync(requestFile,JSON.stringify({packageRoot:join(repoRoot,'packages/css'),format,cases:matrix()},null,2)+'\n')
  const child=Bun.spawn([inputs[nodeKind],join(inputs.candidateRepoRoot,'packages/css/test-support/contract-kernel-worker.mjs'),requestFile],{cwd:join(repoRoot,'packages/css'),stdout:'pipe',stderr:'pipe',env:{...process.env,CRUMBS_INTERNAL_KERNEL_MANIFEST:undefined}})
  const [code,stdout,stderr]=await Promise.all([child.exited,new Response(child.stdout).text(),new Response(child.stderr).text()])
  writeFileSync(join(evidence,`${label}-${nodeKind}-${format}.stdout.log`),stdout)
  writeFileSync(join(evidence,`${label}-${nodeKind}-${format}.stderr.log`),stderr)
  check(code===0,`${label} ${nodeKind} ${format} process failed (${code}): ${stderr.slice(-2500)}`)
  const lines=stdout.split('\n').filter(l=>l.startsWith('CRUMBS_KERNEL_RECEIPT '));check(lines.length===1,'missing or ambiguous worker receipt')
  const receipts=JSON.parse(lines[0]!.slice('CRUMBS_KERNEL_RECEIPT '.length));check(receipts.length===matrix().length,'missing cases')
  for(const r of receipts)if(r.status==='ok')check(verifyCurrentMarker(r).length===0,'independent marker verification failed '+r.case+': '+verifyCurrentMarker(r).join(';'))
  json(`${label}-${nodeKind}-${format}.json`,receipts);results.push({nodeKind,format,receipts})
 }
 return results
}
let result:any
try{
 if(stage==='preflight'){
  check(hash(inputs.controlTarball)===inputs.controlTarballSha256,'control tarball changed')
  const expected=JSON.parse(readFileSync(join(evidence,'control-package-files.json'),'utf8'))
  check(Object.keys(expected).length===185,'control package count')
  const installed=join(inputs.scratchRoot,'control-install/node_modules/@opsydyn/crumbs-css')
  for(const [file,digest] of Object.entries(expected))check(hash(join(installed,file))===digest,'control package drift '+file)
  const original=JSON.parse(readFileSync(join(evidence,'original-inputs.json'),'utf8'));let count=0
  for(const [directory,files] of Object.entries(original))for(const [file,digest] of Object.entries(files as any)){count++;for(const root of [inputs.controlRepoRoot,inputs.candidateRepoRoot])check(hash(join(root,'packages/css',directory,file))===digest,'original input drift '+file)}
  check(count===369,'original input count')
  for(const executable of ['floorNode','currentNode','bun'])check(existsSync(inputs[executable]),'missing executable')
  result={stage,status:'pass',issues:[],evidence:['control-package-files.json','original-inputs.json','environment.json'],controlPackageFiles:185,originalFiles:count}
 }else if(stage==='control'){
  prior('preflight');const a=await workers(inputs.controlRepoRoot,'control-a'),b=await workers(inputs.controlRepoRoot,'control-b'),issues:string[]=[]
  for(let i=0;i<a.length;i++)for(let j=0;j<a[i].receipts.length;j++){const left=a[i].receipts[j],right=b[i].receipts[j];issues.push(...compareKernelTransformReceipts(left,right).map(issue=>`${a[i].nodeKind}/${a[i].format}/${left.case}: ${issue}`))}
  check(issues.length===0,'control/control disagreement: '+issues.slice(0,12).join('; '))
  result={stage,status:'pass',issues:[],evidence:readdirSync(evidence).filter(n=>/^control-[ab]-.*\.json$/.test(n)),casesPerWorker:matrix().length,pairedReceipts:a.reduce((n,r)=>n+r.receipts.length,0)}
 }else if(stage==='structure'){
  prior('control');
  const {auditPackedRuntimeEntrypoints}=await import('./packed-runtime-graph')
  const {assertRuntimeBundleSources}=await import('./runtime-bundle-contract')
  const {readEmittedGraph}=await import('../packages/css/bench/effect-boundary-audit')
  const packet:any={};
  for(const label of ['control','candidate']){
   const root=join(inputs[label+'RepoRoot'],'packages/css'),graphs=await auditPackedRuntimeEntrypoints(root)
   const sourceGuards=graphs.filter(g=>g.classification==='ordinary-runtime').map(g=>{try{return {subpath:g.subpath,format:g.format,status:'pass',count:assertRuntimeBundleSources(g.files.map(f=>resolve(root,f)))}}catch(error){return {subpath:g.subpath,format:g.format,status:'fail',error:String(error)}}})
   packet[label]={graphs,sourceGuards,style:Object.fromEntries(['mjs','cjs'].map(format=>[format,readEmittedGraph(join(root,'dist/style.'+format))]))}
  }
  const build=JSON.parse(readFileSync(join(evidence,'build-initial.json'),'utf8'))
  const kernelMembers=new Set(build.kernel.sources.map((s:any)=>s.path));
  const toolJS=build.toolBundles.filter((b:any)=>b.entry?.transformer&&b.chunks.some((c:any)=>/\.(mjs|cjs)$/.test(c.fileName)))
  const duplicates=toolJS.flatMap((b:any)=>b.chunks.flatMap((c:any)=>(c.modules??[]).filter((m:any)=>kernelMembers.has(m))))
  const row=packet.candidate
  const summary={exportRows:row.graphs.length,ordinaryRows:row.sourceGuards.length,sourceGuardFailures:row.sourceGuards.filter((g:any)=>g.status==='fail').length,kernelExternals:build.kernelBundles.reduce((n:number,b:any)=>n+b.chunks.reduce((m:number,c:any)=>m+(c.imports?.length??0)+(c.dynamicImports?.length??0),0),0),duplicateMembers:duplicates.length,esmStyleFiles:row.style.mjs.files.length,cjsStyleFiles:row.style.cjs.files.length,nonliteralLoads:row.style.mjs.nonliteralLoads+row.style.cjs.nonliteralLoads}
  json('structure-graphs.json',{...packet,summary,duplicates,buildFamilies:build.toolBundles.map((b:any)=>({format:b.format,entry:b.entry,clean:b.clean,dts:b.dts}))})
  const issues=[...assessKernelStructure(summary)]
  if(build.toolBundles.some((b:any)=>b.clean.length!==0))issues.push('later build configuration cleans outputs')
  if(build.toolBundles.filter((b:any)=>b.dts?.emitDtsOnly===true).length!==1)issues.push('single declaration graph lost')
  result={stage,status:issues.length?'fail':'pass',issues,evidence:['build-initial.json','structure-graphs.json'],summary,nextSubstages:issues.length?'clean/skip-clean/prepack/negative-controls not-run after initial structure failure':'pending clean/skip-clean/prepack/negative-controls'}
 }else throw Error('stage not implemented before its test gate: '+stage)
}catch(error){result={stage,status:'fail',issues:[String(error)],evidence:readdirSync(evidence).filter(n=>n.startsWith('control-'))}}
json(stage+'.json',result)
console.log(JSON.stringify(result));if(result.status!=='pass')process.exitCode=1
