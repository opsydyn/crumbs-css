import {createRequire} from 'node:module';
import {readFileSync,writeFileSync,mkdirSync,rmSync,existsSync} from 'node:fs';
import {resolve,join,dirname,relative} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {runInNewContext} from 'node:vm';
const request=JSON.parse(readFileSync(process.argv[2],'utf8')),pkg=resolve(request.packageRoot),own=createRequire(join(pkg,'package.json'));
const hash=v=>createHash('sha256').update(v).digest('hex');
const integrationPath=own.resolve('@vanilla-extract/integration'),integration=own(integrationPath),realCompile=integration.compile,captures=[];
integration.compile=async function(options){
 let inputs;
 const capture={name:'crumbs-kernel-untimed-raw-inputs',setup(build){build.onEnd(result=>{inputs=result.metafile?.inputs})}};
 const result=await realCompile({...options,esbuildOptions:{...options.esbuildOptions,plugins:[...(options.esbuildOptions?.plugins??[]),capture]}});
 if(!inputs)throw Error('untimed observer missed compilation inputs');
 captures.push({filePath:resolve(options.filePath),cwd:options.cwd??process.cwd(),inputs,source:result.source});
 return result;
};
const transformerFile=join(pkg,'dist','transformer.'+(request.format==='esm'?'mjs':'cjs'));
const api=request.format==='esm'?await import(pathToFileURL(transformerFile).href):own(transformerFile);
const esbuild=createRequire(integrationPath)('esbuild'),ts=own('typescript');
function packageVersion(file,name){for(let dir=dirname(file);;dir=dirname(dir)){try{const p=JSON.parse(readFileSync(join(dir,'package.json'),'utf8'));if(p.name===name)return p.version}catch{}if(dir===dirname(dir))throw Error('missing external '+name)}}
const externalVersions={integration:packageVersion(integrationPath,'@vanilla-extract/integration'),esbuild:packageVersion(createRequire(integrationPath).resolve('esbuild'),'esbuild'),vanilla:packageVersion(own.resolve('@vanilla-extract/css'),'@vanilla-extract/css')};
function snapshot(value,seen=new Map()){
 if(value===null)return null;
 if(typeof value==='symbol')return {symbol:Symbol.keyFor(value)??value.description,global:Symbol.keyFor(value)!==undefined};
 if(typeof value==='undefined')return {undefined:true};
 if(typeof value==='number'&&!Number.isFinite(value))return {number:String(value)};
 if(Object.is(value,-0))return {number:'-0'};
 if(typeof value!=='object'&&typeof value!=='function')return value;
 if(seen.has(value))return {ref:seen.get(value)};
 const id=seen.size;seen.set(value,id);
 return {id,array:Array.isArray(value),frozen:Object.isFrozen(value),prototype:Object.getPrototypeOf(value)===null?'null':typeof value==='function'?'function':'object',properties:Reflect.ownKeys(value).map(key=>{const d=Object.getOwnPropertyDescriptor(value,key);return {key:typeof key==='symbol'?snapshot(key,seen):key,enumerable:d.enumerable,configurable:d.configurable,...('value'in d?{writable:d.writable,value:snapshot(d.value,seen)}:{get:typeof d.get,set:typeof d.set})}})};
}
const owned=join(pkg,'fixtures/.contract-kernel-owned'),counter=join(owned,'evaluations.txt');
if(existsSync(owned))throw Error('owned fixture already exists');
mkdirSync(owned);writeFileSync(join(owned,'.owner'),'M10.5');writeFileSync(counter,'');
const dependency='export const width = 24;\n';
const entry=`import {viewStyle,textStyle,createThemeContract,recipe} from '@opsydyn/crumbs-css/style';\nimport {appendFileSync} from 'node:fs';\nimport {width} from './dependency.css';\nappendFileSync(process.env.CRUMBS_KERNEL_COUNTER,'evaluation\\n');\nconst contract=createThemeContract({kernelProbe:{width:null}});\nexport const box=viewStyle({width,opacity:Number(process.env.CRUMBS_KERNEL_AMBIENT??'0.25'),transform:[{scale:2}]});\nexport const token=viewStyle({width:contract.kernelProbe.width});\nexport const label=textStyle({fontSize:14});\nexport const button=recipe({base:{width},variants:{tone:{normal:{opacity:1},muted:{opacity:0.5}}},defaultVariants:{tone:'normal'}});\n`;
writeFileSync(join(owned,'runtime.mjs'),'export function wrap(value){return Object.freeze([value])}\n');
writeFileSync(join(owned,'factory.css.ts'),`import {defineExtension} from '@opsydyn/crumbs-css/extensions';
import {viewStyle} from '@opsydyn/crumbs-css/style';
const wrap=defineExtension<{wrap:(value:unknown)=>readonly unknown[]}>().factory({importPath:'./runtime.mjs',importName:'wrap'});
export const wrapped=wrap(viewStyle({opacity:0.5}));
`);
const originalEnv={NODE_ENV:process.env.NODE_ENV,CRUMBS_KERNEL_COUNTER:process.env.CRUMBS_KERNEL_COUNTER,CRUMBS_KERNEL_AMBIENT:process.env.CRUMBS_KERNEL_AMBIENT};
const receipts=[];
function count(){return readFileSync(counter,'utf8').split('\n').filter(Boolean).length}
function keyOwner(key){const files=own('node:fs').readdirSync(join(pkg,'dist')).filter(f=>/\.(mjs|cjs)$/.test(f)),matches=files.filter(f=>createHash('md5').update('@opsydyn/crumbs-css').update(readFileSync(join(pkg,'dist',f))).digest('hex')===key);if(matches.length!==1)throw Error('compiler key owner ambiguity '+matches.length);const path=join(pkg,'dist',matches[0]);return {path,sha256:hash(readFileSync(path))}}
try{
 process.env.CRUMBS_KERNEL_COUNTER=counter;
 for(const item of request.cases){
  const isOwned=item.filename==='owned',filename=isOwned?join(owned,'probe.css.ts'):resolve(pkg,item.filename),cwd=isOwned?owned:resolve(pkg,item.projectRoot);
  writeFileSync(join(owned,'dependency.css.ts'),item.step==='dependency-edit'?dependency.replace('24','26'):dependency);
  writeFileSync(join(owned,'probe.css.ts'),item.step==='syntax-error'?'export const broken = ;':item.step==='authoring-error'?entry+'\nthrow new Error("owned authoring failure");':item.step==='entry-edit'?entry.replace('width,opacity:','width:width+2,opacity:'):entry);
  process.env.NODE_ENV=item.dev?'development':'production';process.env.CRUMBS_KERNEL_AMBIENT=item.step==='ambient-edit'?'0.75':'0.25';
  process.chdir(cwd);
  const before=count(),captureStart=captures.length,key=api.getCacheKey();
  const provenance={packageRoot:pkg,repoRoot:resolve(pkg,'../..'),format:request.format,pid:process.pid,node:process.version,compilerKey:key,keyOwner:keyOwner(key)};
  const caseName=[item.filename,item.platform,item.dev,item.strictDiagnostics,item.step,item.mapShape??'tuples'].join(':');
  try{
   const result=await api.transform({upstreamTransformerPath:fileURLToPath(new URL('./contract-kernel-upstream.cjs',import.meta.url)),kernelMapShape:item.mapShape??'tuples',nativeStyles:{strictDiagnostics:item.strictDiagnostics,includeStyleExplanations:item.dev}},cwd,filename,readFileSync(filename),{platform:item.platform,dev:item.dev});
   if(['syntax-error','authoring-error'].includes(item.step))throw Error('expected authored failure accepted');
   const observed=captures.slice(captureStart).filter(c=>c.filePath===filename).at(-1);
   if(!observed)throw Error('missing actual final entry compilation');
   const metadata=result.__crumbsNativeStyles,identity=metadata.resolutionIdentity;
   if(!identity)throw Error('missing resolution identity');
   const evaluatedModule={exports:{}},compiled=esbuild.transformSync(result.code,{loader:'js',format:'cjs',target:'node22'}).code;
   const evaluateRequire=createRequire(filename);
   const emittedAst=ts.createSourceFile('generated.mjs',result.code,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
   const trackingImports=new Set(emittedAst.statements.filter(n=>ts.isImportDeclaration(n)&&!n.importClause&&ts.isStringLiteral(n.moduleSpecifier)).map(n=>n.moduleSpecifier.text));
   runInNewContext(compiled,{module:evaluatedModule,exports:evaluatedModule.exports,require:specifier=>specifier==='react-native'?{StyleSheet:{create:v=>v}}:trackingImports.has(specifier)?{}:evaluateRequire(specifier),Object,Symbol,console,process});
   const dependencies=metadata.dependencies.map(d=>{const p=relative(dirname(filename),d.sourcePath).replaceAll('\\','/');return {importPath:p.startsWith('.')?p:'./'+p,sourceHash:d.sourceHash}});
   const inputPaths=Object.keys(observed.inputs).map(p=>resolve(observed.cwd,p));
   const privateInputs=inputPaths.filter(p=>p.startsWith(join(pkg,'dist')+'/')).sort().map(path=>({path,sha256:hash(readFileSync(path)),bytes:readFileSync(path).length}));
   const authoredInputs=metadata.dependencies.map(d=>({...d}));
   const proof={kind:'current',entryHash:identity.files.find(f=>f.sourcePath===filename)?.sourceHash,inputs:observed.inputs,resolutionIdentity:identity,context:{compilerKey:key+':style-explanations='+(item.dev?'1':'0'),platform:item.platform,dev:item.dev,strictDiagnostics:item.strictDiagnostics,useStyleSheet:item.platform!=='web',identOption:item.dev?'debug':'short'},dependencies};
   const events=isOwned?[{evaluations:count()-before}]:[];
   if(isOwned&&count()-before!==1)throw Error('owned authoring was not evaluated exactly once');
   const sidecarResult=await api.transformCssTsToStyleSheetWithManifestSidecar(filename,cwd,{strictDiagnostics:item.strictDiagnostics,platform:item.platform,dev:item.dev,useStyleSheet:item.platform!=='web',includeStyleExplanations:item.dev});
   receipts.push({version:1,case:caseName,status:'ok',code:result.code,proof,metadata,maps:{direct:result.map??null,nested:result.output?.map(o=>o.data?.map??null)??[]},observation:{...snapshot(Object.fromEntries(Object.keys(evaluatedModule.exports).map(key=>[key,evaluatedModule.exports[key]]))),exportDescriptors:Reflect.ownKeys(evaluatedModule.exports).map(key=>{const d=Object.getOwnPropertyDescriptor(evaluatedModule.exports,key);return {key,enumerable:d.enumerable,configurable:d.configurable,kind:'value'in d?'data':'accessor'}})},authoredInputs,privateInputs,externalVersions,sidecar:sidecarResult.sidecar,diagnostics:[],events,error:null,provenance});
  }catch(error){
   if(!['syntax-error','authoring-error'].includes(item.step))throw error;
   receipts.push({version:1,case:caseName,status:'error',code:null,proof:null,metadata:null,maps:null,observation:null,authoredInputs:[],privateInputs:[],externalVersions,sidecar:null,diagnostics:[],events:[],error:{name:error.name,message:error.message},provenance});
  }
 }
 console.log('CRUMBS_KERNEL_RECEIPT '+JSON.stringify(receipts));
}finally{integration.compile=realCompile;for(const [k,v] of Object.entries(originalEnv))v===undefined?delete process.env[k]:process.env[k]=v;if(readFileSync(join(owned,'.owner'),'utf8')==='M10.5')rmSync(owned,{recursive:true})}
