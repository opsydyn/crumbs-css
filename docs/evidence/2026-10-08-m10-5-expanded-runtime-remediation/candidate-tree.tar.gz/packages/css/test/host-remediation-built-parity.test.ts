import { expect, it } from "bun:test"
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from "node:fs"
import { tmpdir } from "node:os"
import { join } from "node:path"
import * as receipts from "../bench/host-remediation/receipts"
import { prepareHostRemediationControl } from "../bench/host-remediation/control"

it("records returned callable constructibility without invoking its body", () => {
  const capture = (receipts as unknown as {captureCallableShape?: (value: Function) => unknown}).captureCallableShape
  expect(typeof capture).toBe("function")
  let calls = 0
  function resolve(value: unknown) { calls++; return value }
  const method = { resolve(value: unknown) { calls++; return value } }.resolve
  expect(capture!(resolve)).toMatchObject({ name:"resolve", length:1, hasOwnPrototype:true, constructible:true })
  expect(capture!(method)).toMatchObject({ name:"resolve", length:1, hasOwnPrototype:false, constructible:false })
  expect(calls).toBe(0)
})

it("distinguishes callable arity, name and descriptor changes", () => {
  const capture = (receipts as unknown as {captureCallableShape?: (value: Function) => unknown}).captureCallableShape
  expect(typeof capture).toBe("function")
  const a = { resolve(x: unknown) { return x } }.resolve
  const b = { resolve() { return undefined } }.resolve
  const c = { other(x: unknown) { return x } }.other
  expect(capture!(a)).not.toEqual(capture!(b))
  expect(capture!(a)).not.toEqual(capture!(c))
  const original = capture!(a)
  Object.defineProperty(a,"diagnostic",{value:1,enumerable:true})
  expect(capture!(a)).not.toEqual(original)
})

it("does not invoke callable property getters during inspection", () => {
  const capture = (receipts as unknown as {captureCallableShape?: (value: Function) => unknown}).captureCallableShape
  expect(typeof capture).toBe("function")
  let calls = 0
  const method = { resolve() {} }.resolve
  Object.defineProperty(method,"diagnostic",{get(){calls++; return 1}})
  capture!(method)
  expect(calls).toBe(0)
})

it("honours an explicit control revision instead of silently building the legacy default", async () => {
  const parent = mkdtempSync(join(tmpdir(),"crumbs-explicit-control-"))
  try {
    await expect(prepareHostRemediationControl(join(parent,"control"),"crumbs-m105-nonexistent-revision")).rejects.toThrow("crumbs-m105-nonexistent-revision")
  } finally { rmSync(parent,{recursive:true,force:true}) }
},30_000)

const entries = ["theme","theme-core","theme-conditions","theme-expressions","theme-recipes","theme-sprinkles","theme-token"]
async function builtHarness() {
  const module = await import("../bench/host-remediation/built-runtime-parity").catch(() => ({}))
  const run = (module as {runBuiltRuntimeParity?: (options:any)=>Promise<any>}).runBuiltRuntimeParity
  expect(typeof run).toBe("function")
  return run!
}
function builtFixture(root:string, body:string) {
  mkdirSync(join(root,"dist"),{recursive:true})
  for (const entry of entries) {
    writeFileSync(join(root,"dist",entry+".mjs"),entry === "theme" ? body : 'export * from "./theme.mjs"')
    writeFileSync(join(root,"dist",entry+".cjs"),entry === "theme" ? body.replace("export function ","exports.createThemeDependencyResolver = function ") : 'module.exports = require("./theme.cjs")')
  }
}
it("detects a built returned-method arity change in both formats", async () => {
  const run=await builtHarness(), root=mkdtempSync(join(tmpdir(),"crumbs-built-parity-"))
  try {
    const control=join(root,"control"),candidate=join(root,"candidate")
    builtFixture(control,"export function createThemeDependencyResolver(){return {resolve(theme){return theme}}}")
    builtFixture(candidate,"export function createThemeDependencyResolver(){return {resolve(){return undefined}}}")
    const report=await run({controlPackageRoot:control,candidatePackageRoot:candidate,nodeExecutables:[process.env.CRUMBS_AUDIT_NODE_FLOOR || "/Users/alancurrie/.local/share/fnm/node-versions/v22.0.0/installation/bin/node"],outputRoot:join(root,"out")})
    expect(report.passed).toBe(false)
    expect(report.failures.some((s:string)=>s.includes("esm") && s.includes("returned:dependency"))).toBe(true)
    expect(report.failures.some((s:string)=>s.includes("cjs") && s.includes("returned:dependency"))).toBe(true)
  } finally {rmSync(root,{recursive:true,force:true})}
},30_000)
it("records independent built control-versus-control equality", async () => {
  const run=await builtHarness(), root=mkdtempSync(join(tmpdir(),"crumbs-built-equality-"))
  try {
    const control=join(root,"control"),candidate=join(root,"candidate")
    const body="export function createThemeDependencyResolver(){return {resolve(theme){return theme}}}"
    builtFixture(control,body);builtFixture(candidate,body)
    const report=await run({controlPackageRoot:control,candidatePackageRoot:candidate,nodeExecutables:[process.env.CRUMBS_AUDIT_NODE_FLOOR || "/Users/alancurrie/.local/share/fnm/node-versions/v22.0.0/installation/bin/node"],outputRoot:join(root,"out")})
    expect(report.passed).toBe(true);expect(report.failures).toEqual([])
  } finally {rmSync(root,{recursive:true,force:true})}
},30_000)
