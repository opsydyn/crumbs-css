import { mkdirSync, writeFileSync } from "node:fs"
import { join, resolve } from "node:path"
import { compareRuntimeOutcomes, type RuntimeOutcome } from "./receipts"

type BuiltRow={label:string;outcome:RuntimeOutcome}
type Cohort={node:string;format:string;rows:BuiltRow[]}
export async function runBuiltRuntimeParity(options:{controlPackageRoot:string;candidatePackageRoot:string;nodeExecutables:readonly string[];outputRoot:string}) {
  mkdirSync(options.outputRoot,{recursive:true})
  const worker=join(options.outputRoot,"built-runtime-worker.mjs")
  const result=await Bun.build({entrypoints:[join(import.meta.dir,"built-runtime-worker.ts")],target:"node",format:"esm",packages:"external"})
  if(!result.success)throw new Error("Built parity worker failed to bundle: "+result.logs.join("\n"))
  writeFileSync(worker,await result.outputs[0]!.text())
  const modes=["none","permission","state","sparse","symbol","accessor","proxy","cycle","null","changing-proxy","length-trap"]
  const cases=Array.from({length:110},(_,id)=>({id,scalar:(id*37)%201-100,mode:modes[id%modes.length]!}))
  const cohorts:Array<{node:string;format:string;control:Cohort;candidate:Cohort}>=[], failures:string[]=[]
  async function run(node:string,root:string,format:string):Promise<Cohort>{
    const child=Bun.spawn([node,worker,resolve(root),format],{cwd:root,stdin:"pipe",stdout:"pipe",stderr:"pipe"})
    child.stdin.write(JSON.stringify(cases));child.stdin.end()
    const [exit,out,err]=await Promise.all([child.exited,new Response(child.stdout).text(),new Response(child.stderr).text()])
    if(exit!==0)throw new Error(`Built worker failed (${exit}): ${err}`)
    const report=JSON.parse(out) as Cohort
    if(report.format!==format||!report.node||!Array.isArray(report.rows)||report.rows.length===0||new Set(report.rows.map(row=>row.label)).size!==report.rows.length)throw new Error("Malformed built parity cohort")
    return report
  }
  for(const node of options.nodeExecutables)for(const format of ["esm","cjs"]){
    const control=await run(node,options.controlPackageRoot,format),candidate=await run(node,options.candidatePackageRoot,format)
    cohorts.push({node,format,control,candidate})
    if(control.node!==candidate.node||control.rows.length!==candidate.rows.length)failures.push(`${control.node}/${format}: cohort identity/count`)
    for(const [index,row] of control.rows.entries()){
      const other=candidate.rows[index]
      if(!other||other.label!==row.label){failures.push(`${control.node}/${format}:${row.label}: label`);continue}
      const differences=compareRuntimeOutcomes(row.outcome,other.outcome)
      if(differences.length)failures.push(`${control.node}/${format}:${row.label}: ${differences.join(",")}`)
      if(row.label.startsWith("binding:")&&JSON.stringify(row.outcome.graph).includes('"value":false'))failures.push(`${control.node}/${format}:${row.label}: noncanonical binding`)
    }
  }
  const receiptsPath=join(options.outputRoot,"built-runtime-parity.json")
  writeFileSync(receiptsPath,JSON.stringify({cases,cohorts,failures},null,2)+"\n")
  return {passed:failures.length===0,failures,receiptsPath}
}
