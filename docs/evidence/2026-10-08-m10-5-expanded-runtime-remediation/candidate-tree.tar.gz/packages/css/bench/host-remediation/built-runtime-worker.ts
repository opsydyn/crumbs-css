import { readFileSync } from "node:fs"
import { createRequire } from "node:module"
import { join } from "node:path"
import { pathToFileURL } from "node:url"
import { captureCallableShape, captureRuntimeOutcome } from "./receipts"

const [root, format] = process.argv.slice(2)
const require = createRequire(import.meta.url)
const entries = ["theme","theme-core","theme-conditions","theme-expressions","theme-recipes","theme-sprinkles","theme-token"]
const namespaces: Record<string,any> = {}, rows: Array<{label:string;outcome:ReturnType<typeof captureRuntimeOutcome>}> = []
const record = (label:string, run:(trace:string[])=>unknown) => rows.push({label,outcome:captureRuntimeOutcome(run)})
const contexts = ["crumbs.css.theme-store-context.v1","crumbs.css.token-theme-context.v2"]
let priorContexts: unknown[] | undefined
for (const entry of entries) {
  const file=join(root!,"dist",entry+(format==="esm"?".mjs":".cjs"))
  const namespace=format==="esm"?await import(pathToFileURL(file).href):require(file)
  namespaces[entry]=namespace
  record(`exports:${entry}`,()=>Object.keys(namespace).sort())
  for (const name of Object.keys(namespace).sort()) {
    if(typeof namespace[name]==="function") record(`callable:${entry}:${name}`,()=>captureCallableShape(namespace[name]))
    else record(`value:${entry}:${name}`,()=>namespace[name])
  }
  const current=contexts.map(key=>Object.getOwnPropertyDescriptor(globalThis,Symbol.for(key))?.value)
  record(`contexts:${entry}`,()=>({present:current.map(x=>x!==undefined),same:priorContexts?.map((x,i)=>x===current[i])??null}))
  priorContexts=current
}
const theme=namespaces.theme, expressions=namespaces["theme-expressions"]
for (const entry of ["theme-conditions","theme-recipes","theme-sprinkles"]) {
  for(const name of Object.keys(namespaces[entry]).sort()) {
    if(name in theme) record(`binding:${entry}:${name}`,()=>theme[name]===namespaces[entry][name])
  }
}
const shapes=(value:any)=>Object.fromEntries(Reflect.ownKeys(value).filter((key):key is string=>typeof key==="string").filter(key=>typeof Object.getOwnPropertyDescriptor(value,key)?.value==="function").map(key=>[key,captureCallableShape(Object.getOwnPropertyDescriptor(value,key)!.value)]))
if(typeof theme.createThemeDependencyResolver==="function") record("returned:dependency",()=>shapes(theme.createThemeDependencyResolver({},{$$type:"crumbs.css.theme-dependency-plan",version:1,entries:[]})))
if(typeof theme.createNativeConditionStore==="function") record("returned:condition-store",()=>shapes(theme.createNativeConditionStore()))
if(typeof theme.createNativeConditionResolver==="function") record("returned:condition-resolver",()=>captureCallableShape(theme.createNativeConditionResolver([],1)))
const recipe={$$type:"crumbs.css.recipe",version:1,base:{opacity:0.8},variants:{tone:{on:{opacity:1},off:{opacity:0.4}}},defaultVariants:{tone:"on"},compoundVariants:[]}
if(typeof theme.createRecipeResolver==="function") record("returned:recipe",()=>{const value=theme.createRecipeResolver(recipe);return {callable:captureCallableShape(value),methods:shapes(value)}})
const lookup={$$type:"crumbs.css.sprinkles-lookup-plan",version:1,primitives:["view"],properties:{padding:{sm:{padding:4}}},shorthands:{p:["padding"]}}
if(typeof theme.createSprinklesResolver==="function") record("returned:sprinkles",()=>{const value=theme.createSprinklesResolver(lookup);return {callable:captureCallableShape(value),methods:shapes(value)}})
if(typeof expressions.createNativeExpressionProgram==="function") record("returned:expression",()=>shapes(expressions.createNativeExpressionRuntime(expressions.createNativeExpressionProgram(expressions.createNativeExpressionLiteral(expressions.createNativeExpressionDomain({kind:"number",unit:"unitless"}),1)))))
const cases=JSON.parse(readFileSync(0,"utf8")) as Array<{id:number;scalar:number;mode:string}>
for(const input of cases) {
  if(typeof theme.resolveThemeTokens!=="function") continue
  const identity={owner:"@fixture/expanded",name:`Component${input.id}`,version:1}
  const contract=(trace:string[])=>{
    let slots:any=["root"]
    if(input.mode==="sparse")slots=new Array(1)
    if(input.mode==="symbol")Object.defineProperty(slots,Symbol("x"),{value:true})
    if(input.mode==="accessor"){slots=new Array(1);Object.defineProperty(slots,"0",{enumerable:true,get(){trace.push("getter");return "root"}})}
    if(input.mode==="proxy")slots=new Proxy(["root"],{ownKeys(target){trace.push("ownKeys");return Reflect.ownKeys(target)},getOwnPropertyDescriptor(target,key){trace.push("descriptor:"+String(key));return Reflect.getOwnPropertyDescriptor(target,key)}})
    if(input.mode==="changing-proxy"){let reads=0;slots=new Proxy(["root"],{ownKeys(target){trace.push("keys:"+(++reads));return Reflect.ownKeys(target)},getOwnPropertyDescriptor(target,key){trace.push("descriptor:"+String(key));if(key==="0"&&reads>1)throw new TypeError("fixture changing descriptor");return Reflect.getOwnPropertyDescriptor(target,key)}})}
    if(input.mode==="length-trap")slots=new Proxy(["root"],{getOwnPropertyDescriptor(target,key){trace.push("descriptor:"+String(key));if(key==="length")throw new TypeError("fixture length descriptor");return Reflect.getOwnPropertyDescriptor(target,key)}})
    const value={identity,public:{slots,variants:{tone:["on","off"],status:["ready","loading"]}},extensionPoints:{defaults:input.mode==="permission"?["private"]:["tone"],variantValues:["tone"],compoundVariants:true,slotStyles:["root"]}}
    return input.mode==="null"?Object.assign(Object.create(null),value):value
  }
  const token=theme.createThemeTokenReference("--crumbs-expanded-padding"), snapshot={contract:{},tokens:{"--crumbs-expanded-padding":input.scalar},values:{}}
  const component=(trace:string[])=>({$$type:"crumbs.css.component-recipe",version:3,slots:{root:"view",label:"text"},base:{root:{padding:token},label:{opacity:0.8}},variants:{tone:{on:{root:{opacity:1}},off:{}},status:{ready:{},loading:{}}},defaultVariants:{tone:"on",status:"ready"},stateVariants:{status:{ready:{tone:input.mode==="state"?["private"]:["on"]},loading:{tone:["off"]}}},compoundVariants:[],contract:contract(trace)})
  const extension={$$type:"crumbs.css.component-recipe-extension",version:1,identity:{owner:"@fixture/expanded",name:`Extension${input.id}`,version:1},componentIdentity:identity,defaultVariants:{},variants:{tone:{brand:{root:{padding:input.scalar}}}},compoundVariants:[] as any[],slotOverrides:{root:{opacity:0.7}} as any}
  if(input.mode==="cycle"){const cyclic:any={};cyclic.self=cyclic;extension.slotOverrides.root=cyclic}
  if(input.mode==="sparse")extension.compoundVariants=new Array(1)
  record(`${input.id}:theme`,trace=>{const value=component(trace),first=theme.resolveThemeTokens(value,snapshot),again=theme.resolveThemeTokens(value,snapshot),next=theme.resolveThemeTokens(value,{...snapshot,tokens:{"--crumbs-expanded-padding":input.scalar+1}});return [first,again,next]})
  record(`${input.id}:component`,trace=>theme.resolveComponentRecipeStyles(component(trace),{}))
  record(`${input.id}:extension`,trace=>{const resolver=theme.createComponentRecipeResolver(component(trace),{extensions:[extension],cacheSize:2});return {callable:captureCallableShape(resolver),methods:shapes(resolver),first:resolver({tone:"brand"}),stats:resolver.getCacheStats()}})
  record(`${input.id}:recipe-cache`,()=>{const value=theme.createRecipeResolver(recipe,{cacheSize:2}),first=value({}),again=value({});value({tone:"off"});value.clearCache();return [first,again,value.getCacheStats()]})
  record(`${input.id}:conditions`,()=>theme.normalizeNativeConditionInput({...theme.defaultNativeConditionSnapshot,...(input.mode==="state"?{platform:"unsupported"}:{})}))
  record(`${input.id}:expression`,()=>{const d=expressions.createNativeExpressionDomain({kind:"number",unit:"unitless"}),literal=expressions.createNativeExpressionLiteral(d,input.scalar),missing=expressions.createNativeExpressionTokenReference("missing",d),tree=expressions.createNativeExpressionAdd(literal,expressions.createNativeExpressionScale(literal,2)),fallback=expressions.createNativeExpressionFallback(missing,tree),match=expressions.createNativeExpressionMatch({condition:"widthBucket",cases:[{value:"compact",expression:fallback}],fallback:missing});return [expressions.evaluateNativeExpressionWithTrace(match,{tokens:{},conditions:{...theme.defaultNativeConditionSnapshot,widthBucket:"compact"}}),expressions.foldNativeExpression(tree)]})
  record(`${input.id}:error`,()=>{const d=expressions.createNativeExpressionDomain({kind:"number",unit:"unitless"});return expressions.evaluateNativeExpression(expressions.createNativeExpressionTokenReference("missing",d))})
}
console.log(JSON.stringify({node:process.version,format,rows}))
