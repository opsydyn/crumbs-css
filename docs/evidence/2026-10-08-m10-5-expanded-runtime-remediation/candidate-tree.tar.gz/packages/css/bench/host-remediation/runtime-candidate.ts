import { readFileSync, mkdirSync, writeFileSync } from "node:fs"
import { join, resolve } from "node:path"
import { budgetRegistryCodec, compareRecordedMetrics, compareRuntimeGraphMetrics } from "../budget-contract"
import { scanRuntimeGraphEvidence } from "../runtime-graph-budget"
import { measureRuntimeInitialization } from "../runtime-initialization"
import { runBuiltRuntimeParity } from "./built-runtime-parity"

const repositoryRoot=resolve(import.meta.dir,"../../../.."),packageRoot=join(repositoryRoot,"packages/css")
const startupIds=["runtime-initialization-node22-esm","runtime-initialization-node22-cjs","runtime-initialization-current-esm","runtime-initialization-current-cjs"]
const caps={"theme-core":{esm:39000,cjs:39000},theme:{esm:96000,cjs:99000},tokens:{esm:56013,cjs:63308}}
export function checkExpandedRuntimeEvidence(evidence:{runtimeGraph:ReturnType<typeof scanRuntimeGraphEvidence>;startupRows:readonly {id:string;result:string}[];parityPassed:boolean}):readonly string[]{
  const failures:string[]=[]
  if(!evidence.parityPassed)failures.push("built API parity")
  for(const id of startupIds){const rows=evidence.startupRows.filter(row=>row.id===id);if(rows.length!==1)failures.push(`${id}: row count`);else if(rows[0]!.result!=="pass")failures.push(`${id}: ${rows[0]!.result}`)}
  if(evidence.startupRows.length!==4)failures.push("startup row set")
  for(const entry of ["theme-core","tokens","theme"] as const)for(const format of ["esm","cjs"] as const){
    const graph=evidence.runtimeGraph.currentGraphs[entry]?.[format]
    if(!graph){failures.push(`${entry}/${format}: missing graph`);continue}
    if(graph.graphBytes>caps[entry][format])failures.push(`${entry}/${format}: admission cap`)
    if(graph.nonliteralLoads!==0||graph.externals.some(name=>name!=="react"))failures.push(`${entry}/${format}: runtime loads`)
    if(!Number.isSafeInteger(graph.graphBytes)||graph.graphBytes<0||graph.samples.length!==5||graph.samples.some(bytes=>bytes!==graph.graphBytes)||graph.artifacts.length===0||new Set(graph.artifacts.map(a=>a.file)).size!==graph.artifacts.length||graph.artifacts.reduce((sum,a)=>sum+a.bytes,0)!==graph.graphBytes)failures.push(`${entry}/${format}: graph inventory`)
  }
  return failures
}
export async function assessExpandedRuntimeCandidate(options:{controlPackageRoot:string;candidatePackageRoot:string;floorNode:string;outputRoot:string}):Promise<{eligible:boolean;failures:readonly string[]}>{
  if(resolve(options.candidatePackageRoot)!==packageRoot)throw Error("Candidate must be the current owned package")
  mkdirSync(options.outputRoot,{recursive:true})
  const node=Bun.spawnSync(["node","-p","process.execPath"]).stdout.toString().trim()
  const parity=await runBuiltRuntimeParity({...options,nodeExecutables:[options.floorNode,node],outputRoot:join(options.outputRoot,"parity")})
  const runtimeGraph=scanRuntimeGraphEvidence(packageRoot,5)
  const decoded=budgetRegistryCodec.decodeJson(readFileSync(join(packageRoot,"bench/budgets.json"),"utf8"));if(!decoded.ok)throw Error("Invalid active registry")
  const registry=decoded.value
  const oldGraphs=compareRuntimeGraphMetrics(registry,repositoryRoot,runtimeGraph)
  let runtimeInit:ReturnType<typeof measureRuntimeInitialization>|undefined, startupRows:Array<{id:string;result:string}>=[]
  if(parity.passed){runtimeInit=measureRuntimeInitialization(options.floorNode,15);const scoped={...registry,metrics:registry.metrics.filter(m=>startupIds.includes(m.id))};startupRows=compareRecordedMetrics(scoped,repositoryRoot,{effect:{},runtimeGraph,runtimeInit,benchmark:{},incremental:{},editor:{}}).metrics}
  const failures=[...checkExpandedRuntimeEvidence({runtimeGraph,startupRows,parityPassed:parity.passed}),...oldGraphs.metrics.filter(row=>row.id.startsWith("runtime-tokens-")&&row.result!=="pass").map(row=>`${row.id}: ${row.result}`)]
  const report={eligible:failures.length===0,failures,runtimeGraph,runtimeInit:runtimeInit??null,startupRows,oldGraphs,parity}
  writeFileSync(join(options.outputRoot,"runtime-candidate.json"),JSON.stringify(report,null,2)+"\n")
  return {eligible:report.eligible,failures}
}
