from pathlib import Path
repo=Path('/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css');p=repo/'packages/css/test/host-remediation-built-parity.test.ts';s=p.read_text().replace('mkdtempSync, rmSync, writeFileSync','mkdtempSync, mkdirSync, rmSync, writeFileSync').replace('/unknown revision|ambiguous argument|not a valid object name/','"crumbs-m105-nonexistent-revision"');s+='''
const entries = ["theme","theme-core","theme-conditions","theme-expressions","theme-recipes","theme-sprinkles","theme-token"]
async function builtHarness() {
  const module = await import("../bench/host-remediation/built-runtime-parity").catch(() => ({}))
  const run = (module as {runBuiltRuntimeParity?: (options:any)=>Promise<any>}).runBuiltRuntimeParity
  expect(typeof run).toBe("function")
  return run!
}
function builtFixture(root:string, body:string) {
  mkdirSync(join(root,"dist"),{recursive:true})
  for (const entry of entries) {
    writeFileSync(join(root,"dist",entry+".mjs"),body)
    writeFileSync(join(root,"dist",entry+".cjs"),body.replace("export function ","exports.createThemeDependencyResolver = function "))
  }
}
it("detects a built returned-method arity change in both formats", async () => {
  const run=await builtHarness(), root=mkdtempSync(join(tmpdir(),"crumbs-built-parity-"))
  try {
    const control=join(root,"control"),candidate=join(root,"candidate")
    builtFixture(control,"export function createThemeDependencyResolver(){return {resolve(theme){return theme}}}")
    builtFixture(candidate,"export function createThemeDependencyResolver(){return {resolve(){return undefined}}}")
    const report=await run({controlPackageRoot:control,candidatePackageRoot:candidate,nodeExecutables:[process.env.CRUMBS_AUDIT_NODE_FLOOR || "/Users/alancurrie/.local/share/fnm/node-versions/v22.0.0/installation/bin/node"],outputRoot:join(root,"out")})
    expect(report.passed).toBe(false)
    expect(report.failures.some((s:string)=>s.includes("esm"))).toBe(true)
    expect(report.failures.some((s:string)=>s.includes("cjs"))).toBe(true)
  } finally {rmSync(root,{recursive:true,force:true})}
},30_000)
it("records independent built control-versus-control equality", async () => {
  const run=await builtHarness(), root=mkdtempSync(join(tmpdir(),"crumbs-built-equality-"))
  try {
    const control=join(root,"control"),candidate=join(root,"candidate")
    const body="export function createThemeDependencyResolver(){return {resolve(theme){return theme}}}"
    builtFixture(control,body);builtFixture(candidate,body)
    const report=await run({controlPackageRoot:control,candidatePackageRoot:candidate,nodeExecutables:[process.env.CRUMBS_AUDIT_NODE_FLOOR || "/Users/alancurrie/.local/share/fnm/node-versions/v22.0.0/installation/bin/node"],outputRoot:join(root,"out")})
    expect(report.passed).toBe(true);expect(report.failures).toEqual([])
  } finally {rmSync(root,{recursive:true,force:true})}
},30_000)
''';p.write_text(s)
