import {join} from 'node:path';
const root='/private/tmp/crumbs-m10-5-expanded',candidate='/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css/packages/css',control=join(root,'control/packages/css');
const runtimes=[['floor','/Users/alancurrie/.local/share/fnm/node-versions/v22.0.0/installation/bin/node'],['current',Bun.spawnSync(['node','-p','process.execPath']).stdout.toString().trim()]] as const;
const cells=[];
for(const[runtime,node]of runtimes)for(const format of ['esm','cjs']){
 const cell:any={runtime,format,control:{warmup:null,samples:[]},candidate:{warmup:null,samples:[]}};
 for(let sample=-1;sample<5;sample++)for(const [label,packageRoot] of [['control',control],['candidate',candidate]]){
  const command=[node,'--expose-gc',join(root,'first-use-probe.mjs'),join(packageRoot!,'dist/theme.'+(format==='esm'?'mjs':'cjs')),format];
  const r=Bun.spawnSync(command,{stdout:'pipe',stderr:'pipe'});if(r.exitCode!==0)throw Error(r.stderr.toString());
  const measurement=JSON.parse(r.stdout.toString());if(sample===-1)cell[label!].warmup={excluded:true,...measurement};else cell[label!].samples.push(measurement);
 }
 cells.push(cell);
}
await Bun.write(join(root,'first-use.json'),JSON.stringify({qualification:'diagnostic-only',protocol:'Alternating independent control/candidate processes; one excluded warmup then five samples per runtime/format; module import followed by first recipe/condition/dependency use; process startup excluded',cells},null,2)+'\n');
console.log('Retained import-plus-first-use diagnostics: 40 samples, 8 excluded warmups');
