import {readFileSync,writeFileSync} from 'node:fs';import {join} from 'node:path';import {createHash}from'node:crypto';
import{captureGuaranteesSourceIdentity}from'/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css/scripts/guarantees-matrix/source-identity.ts';
import{captureControlInventory}from'/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css/packages/css/bench/host-remediation/control.ts';
const root='/private/tmp/crumbs-m10-5-expanded',repo='/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css';
const candidate=captureGuaranteesSourceIdentity(repo),inventory=captureControlInventory(join(repo,'packages/css'),'82facc31d54bf1d6280baf4a9b17db63fa85fbbe');
writeFileSync(join(root,'candidate-source-identity.json'),JSON.stringify(candidate,null,2)+'\n');writeFileSync(join(root,'candidate-inventory.json'),JSON.stringify(inventory,null,2)+'\n');
const control=captureGuaranteesSourceIdentity(repo,JSON.parse(readFileSync(join(root,'tracked-paths.json'),'utf8')));
console.log(JSON.stringify({candidate:candidate.sha256,files:candidate.files.length}));
// Bundle the unchanged comparator once, so the offline evidence verifier needs no installed Effect packages.
const compiled=await Bun.build({entrypoints:[join(repo,'packages/css/bench/budget-contract.ts')],target:'node',format:'esm'});
if(!compiled.success)throw Error(compiled.logs.join('\n'));writeFileSync(join(root,'budget-comparator.mjs'),await compiled.outputs[0]!.text());
const originals=['packages/css/tsdown.config.ts','packages/css/bench/host-remediation/control.ts','packages/css/bench/host-remediation/receipts.ts'];
writeFileSync(join(root,'candidate.patch'),Bun.spawnSync(['git','diff','--binary','HEAD'],{cwd:repo}).stdout);
const baselineFiles=[...new Set(JSON.parse(readFileSync(join(repo,'packages/css/bench/budgets.json'),'utf8')).metrics.filter((m:any)=>m.baseline.status==='recorded').map((m:any)=>m.baseline.evidence))] as string[];
writeFileSync(join(root,'baseline-files.json'),JSON.stringify(baselineFiles.map(path=>({path,sha256:createHash('sha256').update(readFileSync(join(repo,path))).digest('hex')})),null,2)+'\n');
