from pathlib import Path
repo=Path('/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css')
(repo/'packages/css/bench/host-remediation/built-runtime-worker.ts').write_text('''import { readFileSync } from "node:fs"
import { createRequire } from "node:module"
import { join } from "node:path"
import { pathToFileURL } from "node:url"
import { captureCallableShape, captureRuntimeOutcome } from "./receipts"

const [root, format] = process.argv.slice(2)
const require = createRequire(import.meta.url)
const entries = ["theme","theme-core","theme-conditions","theme-expressions","theme-recipes","theme-sprinkles","theme-token"]
const namespaces: Record<string,any> = {}, rows: Array<{label:string;outcome:ReturnType<typeof captureRuntimeOutcome>}> = []
const record = (label:string, run:(trace:string[])=>unknown) => rows.push({label,outcome:captureRuntimeOutcome(run)})
const contexts = ["crumbs.css.theme-store-context.v1","crumbs.css.token-theme-context.v2"]
let priorContexts: unknown[] | undefined
for (const entry of entries) {
  const file=join(root!,"dist",entry+(format==="esm"?".mjs":".cjs"))
  const namespace=format==="esm"?await import(pathToFileURL(file).href):require(file)
  namespaces[entry]=namespace
  record(`exports:${entry}`,()=>Object.keys(namespace).sort())
  for (const name of Object.keys(namespace).sort()) {
    if(typeof namespace[name]==="function") record(`callable:${entry}:${name}`,()=>captureCallableShape(namespace[name]))
    else record(`value:${entry}:${name}`,()=>namespace[name])
  }
  const current=contexts.map(key=>Object.getOwnPropertyDescriptor(globalThis,Symbol.for(key))?.value)
  record(`contexts:${entry}`,()=>({present:current.map(x=>x!==undefined),same:priorContexts?.map((x,i)=>x===current[i])??null}))
  priorContexts=current
}
const theme=namespaces.theme, expressions=namespaces["theme-expressions"]
for (const entry of ["theme-conditions","theme-recipes","theme-sprinkles"]) {
  for(const name of Object.keys(namespaces[entry]).sort()) {
    if(name in theme) record(`binding:${entry}:${name}`,()=>theme[name]===namespaces[entry][name])
  }
}
const shapes=(value:any)=>Object.fromEntries(Reflect.ownKeys(value).filter((key):key is string=>typeof key==="string").filter(key=>typeof Object.getOwnPropertyDescriptor(value,key)?.value==="function").map(key=>[key,captureCallableShape(Object.getOwnPropertyDescriptor(value,key)!.value)]))
if(typeof theme.createThemeDependencyResolver==="function") record("returned:dependency",()=>shapes(theme.createThemeDependencyResolver({},{$$type:"crumbs.css.theme-dependency-plan",version:1,entries:[]})))
if(typeof theme.createNativeConditionStore==="function") record("returned:condition-store",()=>shapes(theme.createNativeConditionStore()))
if(typeof theme.createNativeConditionResolver==="function") record("returned:condition-resolver",()=>captureCallableShape(theme.createNativeConditionResolver([],1)))
const recipe={$$type:"crumbs.css.recipe",version:1,base:{opacity:0.8},variants:{tone:{on:{opacity:1},off:{opacity:0.4}}},defaultVariants:{tone:"on"},compoundVariants:[]}
if(typeof theme.createRecipeResolver==="function") record("returned:recipe",()=>{const value=theme.createRecipeResolver(recipe);return {callable:captureCallableShape(value),methods:shapes(value)}})
const lookup={$$type:"crumbs.css.sprinkles-lookup-plan",version:1,primitives:{space:{sm:4}},properties:{padding:{sm:{padding:4}}},shorthands:{p:["padding"]}}
if(typeof theme.createSprinklesResolver==="function") record("returned:sprinkles",()=>{const value=theme.createSprinklesResolver(lookup);return {callable:captureCallableShape(value),methods:shapes(value)}})
if(typeof expressions.createNativeExpressionProgram==="function") record("returned:expression",()=>shapes(expressions.createNativeExpressionRuntime(expressions.createNativeExpressionProgram(expressions.createNativeExpressionLiteral(expressions.createNativeExpressionDomain({kind:"number",unit:"unitless"}),1)))))
const cases=JSON.parse(readFileSync(0,"utf8")) as Array<{id:number;scalar:number;mode:string}>
for(const input of cases) {
  if(typeof theme.resolveThemeTokens!=="function") continue
  const identity={owner:"@fixture/expanded",name:`Component${input.id}`,version:1}
  const contract=(trace:string[])=>{
    let slots:any=["root"]
    if(input.mode==="sparse")slots=new Array(1)
    if(input.mode==="symbol")Object.defineProperty(slots,Symbol("x"),{value:true})
    if(input.mode==="accessor"){slots=new Array(1);Object.defineProperty(slots,"0",{enumerable:true,get(){trace.push("getter");return "root"}})}
    if(input.mode==="proxy")slots=new Proxy(["root"],{ownKeys(target){trace.push("ownKeys");return Reflect.ownKeys(target)},getOwnPropertyDescriptor(target,key){trace.push("descriptor:"+String(key));return Reflect.getOwnPropertyDescriptor(target,key)}})
    if(input.mode==="changing-proxy"){let reads=0;slots=new Proxy(["root"],{ownKeys(target){trace.push("keys:"+(++reads));return Reflect.ownKeys(target)},getOwnPropertyDescriptor(target,key){trace.push("descriptor:"+String(key));if(key==="0"&&reads>1)throw new TypeError("fixture changing descriptor");return Reflect.getOwnPropertyDescriptor(target,key)}})}
    if(input.mode==="length-trap")slots=new Proxy(["root"],{getOwnPropertyDescriptor(target,key){trace.push("descriptor:"+String(key));if(key==="length")throw new TypeError("fixture length descriptor");return Reflect.getOwnPropertyDescriptor(target,key)}})
    const value={identity,public:{slots,variants:{tone:["on","off"],status:["ready","loading"]}},extensionPoints:{defaults:input.mode==="permission"?["private"]:["tone"],variantValues:["tone"],compoundVariants:true,slotStyles:["root"]}}
    return input.mode==="null"?Object.assign(Object.create(null),value):value
  }
  const token=theme.createThemeTokenReference("--crumbs-expanded-padding"), snapshot={contract:{},tokens:{"--crumbs-expanded-padding":input.scalar},values:{}}
  const component=(trace:string[])=>({$$type:"crumbs.css.component-recipe",version:3,slots:{root:"view",label:"text"},base:{root:{padding:token},label:{opacity:0.8}},variants:{tone:{on:{root:{opacity:1}},off:{}},status:{ready:{},loading:{}}},defaultVariants:{tone:"on",status:"ready"},stateVariants:{status:{ready:{tone:input.mode==="state"?["private"]:["on"]},loading:{tone:["off"]}}},compoundVariants:[],contract:contract(trace)})
  const extension={$$type:"crumbs.css.component-recipe-extension",version:1,identity:{owner:"@fixture/expanded",name:`Extension${input.id}`,version:1},componentIdentity:identity,defaultVariants:{},variants:{tone:{brand:{root:{padding:input.scalar}}}},compoundVariants:[] as any[],slotOverrides:{root:{opacity:0.7}} as any}
  if(input.mode==="cycle"){const cyclic:any={};cyclic.self=cyclic;extension.slotOverrides.root=cyclic}
  if(input.mode==="sparse")extension.compoundVariants=new Array(1)
  record(`${input.id}:theme`,trace=>{const value=component(trace),first=theme.resolveThemeTokens(value,snapshot),again=theme.resolveThemeTokens(value,snapshot),next=theme.resolveThemeTokens(value,{...snapshot,tokens:{"--crumbs-expanded-padding":input.scalar+1}});return [first,again,next]})
  record(`${input.id}:component`,trace=>theme.resolveComponentRecipeStyles(component(trace),{}))
  record(`${input.id}:extension`,trace=>{const resolver=theme.createComponentRecipeResolver(component(trace),{extensions:[extension],cacheSize:2});return {methods:shapes(resolver),first:resolver({tone:"brand"}),stats:resolver.getCacheStats()}})
  record(`${input.id}:recipe-cache`,()=>{const value=theme.createRecipeResolver(recipe,{cacheSize:2}),first=value({}),again=value({});value({tone:"off"});value.clearCache();return [first,again,value.getCacheStats()]})
  record(`${input.id}:conditions`,()=>theme.normalizeNativeConditionInput({...theme.defaultNativeConditionSnapshot,...(input.mode==="state"?{platform:"unsupported"}:{})}))
  record(`${input.id}:expression`,()=>{const d=expressions.createNativeExpressionDomain({kind:"number",unit:"unitless"}),literal=expressions.createNativeExpressionLiteral(d,input.scalar),missing=expressions.createNativeExpressionTokenReference("missing",d),tree=expressions.createNativeExpressionAdd(literal,expressions.createNativeExpressionScale(literal,2)),fallback=expressions.createNativeExpressionFallback(missing,tree),match=expressions.createNativeExpressionMatch({condition:"widthBucket",cases:[{value:"compact",expression:fallback}],fallback:missing});return [expressions.evaluateNativeExpressionWithTrace(match,{tokens:{},conditions:{...theme.defaultNativeConditionSnapshot,widthBucket:"compact"}}),expressions.foldNativeExpression(tree)]})
  record(`${input.id}:error`,()=>{const d=expressions.createNativeExpressionDomain({kind:"number",unit:"unitless"});return expressions.evaluateNativeExpression(expressions.createNativeExpressionTokenReference("missing",d))})
}
console.log(JSON.stringify({node:process.version,format,rows}))
''')
(repo/'packages/css/bench/host-remediation/built-runtime-parity.ts').write_text('''import { mkdirSync, writeFileSync } from "node:fs"
import { join, resolve } from "node:path"
import { compareRuntimeOutcomes, type RuntimeOutcome } from "./receipts"

type BuiltRow={label:string;outcome:RuntimeOutcome}
type Cohort={node:string;format:string;rows:BuiltRow[]}
export async function runBuiltRuntimeParity(options:{controlPackageRoot:string;candidatePackageRoot:string;nodeExecutables:readonly string[];outputRoot:string}) {
  mkdirSync(options.outputRoot,{recursive:true})
  const worker=join(options.outputRoot,"built-runtime-worker.mjs")
  const result=await Bun.build({entrypoints:[join(import.meta.dir,"built-runtime-worker.ts")],target:"node",format:"esm",packages:"external"})
  if(!result.success)throw new Error("Built parity worker failed to bundle: "+result.logs.join("\\n"))
  writeFileSync(worker,await result.outputs[0]!.text())
  const modes=["none","permission","state","sparse","symbol","accessor","proxy","cycle","null","changing-proxy","length-trap"]
  const cases=Array.from({length:110},(_,id)=>({id,scalar:(id*37)%201-100,mode:modes[id%modes.length]!}))
  const cohorts:Array<{node:string;format:string;control:Cohort;candidate:Cohort}>=[], failures:string[]=[]
  async function run(node:string,root:string,format:string):Promise<Cohort>{
    const child=Bun.spawn([node,worker,resolve(root),format],{cwd:root,stdin:"pipe",stdout:"pipe",stderr:"pipe"})
    child.stdin.write(JSON.stringify(cases));child.stdin.end()
    const [exit,out,err]=await Promise.all([child.exited,new Response(child.stdout).text(),new Response(child.stderr).text()])
    if(exit!==0)throw new Error(`Built worker failed (${exit}): ${err}`)
    const report=JSON.parse(out) as Cohort
    if(report.format!==format||!report.node||!Array.isArray(report.rows)||report.rows.length===0||new Set(report.rows.map(row=>row.label)).size!==report.rows.length)throw new Error("Malformed built parity cohort")
    return report
  }
  for(const node of options.nodeExecutables)for(const format of ["esm","cjs"]){
    const control=await run(node,options.controlPackageRoot,format),candidate=await run(node,options.candidatePackageRoot,format)
    cohorts.push({node,format,control,candidate})
    if(control.node!==candidate.node||control.rows.length!==candidate.rows.length)failures.push(`${control.node}/${format}: cohort identity/count`)
    for(const [index,row] of control.rows.entries()){
      const other=candidate.rows[index]
      if(!other||other.label!==row.label){failures.push(`${control.node}/${format}:${row.label}: label`);continue}
      const differences=compareRuntimeOutcomes(row.outcome,other.outcome)
      if(differences.length)failures.push(`${control.node}/${format}:${row.label}: ${differences.join(",")}`)
      if(row.label.startsWith("binding:")&&JSON.stringify(row.outcome.graph).includes('"value":false'))failures.push(`${control.node}/${format}:${row.label}: noncanonical binding`)
    }
  }
  const receiptsPath=join(options.outputRoot,"built-runtime-parity.json")
  writeFileSync(receiptsPath,JSON.stringify({cases,cohorts,failures},null,2)+"\\n")
  return {passed:failures.length===0,failures,receiptsPath}
}
''')
ledger=repo/'.superpowers/sdd/2026-10-08-m10-5-expanded-runtime-remediation/progress.md'
with ledger.open('a') as f:f.write('Task 1: RED callable/control tests 9 pass/4 fail; callable inspection implemented. RED built-worker tests 4 pass/2 fail (missing harness). Baseline after temporary link repair: CSS 1565 pass/1 skip/0 fail; Storybook 23 pass/0 fail. Ruling: Add private built-runtime-worker.ts bundled into owned output for genuine Node 22, which cannot execute TypeScript; source validation fixtures remain separate and built tests exercise publicly reachable boundaries — preserves actual built artefact testing — cost if wrong: missing private-boundary coverage remains covered by source property fixtures.\n')
