import { writeFileSync, mkdirSync, readFileSync } from "node:fs"
import { createHash } from "node:crypto"
import { createRequire } from "node:module"
import { resolve, join } from "node:path"
import { captureControlInventory, verifyControlInventory, prepareHostRemediationControl } from "/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css/packages/css/bench/host-remediation/control.ts"
import { runBuiltRuntimeParity } from "/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css/packages/css/bench/host-remediation/built-runtime-parity.ts"
import { runHostRuntimeParity } from "/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css/packages/css/bench/host-remediation/runtime-parity.ts"
const root="/private/tmp/crumbs-m10-5-expanded",control=join(root,"control/packages/css"),candidate="/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css/packages/css"
const start=JSON.parse(readFileSync(join(root,"start.json"),"utf8"))
const inventory=captureControlInventory(control,start.revision),require=createRequire(join(control,"package.json"))
const tools=["react","effect","tsdown","@vanilla-extract/css","@vanilla-extract/integration","fast-check","typescript"].map(name=>{const path=require.resolve(name+"/package.json"),bytes=readFileSync(path);return {name,path,version:JSON.parse(bytes.toString()).version,sha256:createHash("sha256").update(bytes).digest("hex")}})
writeFileSync(join(root,"control-inventory.json"),JSON.stringify({inventory,tools,failures:verifyControlInventory(control,inventory,start.revision)},null,2)+"\n")
const floor="/Users/alancurrie/.local/share/fnm/node-versions/v22.0.0/installation/bin/node",current=Bun.spawnSync(["node","-p","process.execPath"]).stdout.toString().trim()
const report=await runBuiltRuntimeParity({controlPackageRoot:control,candidatePackageRoot:control,nodeExecutables:[floor,current],outputRoot:join(root,"control-built-parity")})
console.log(JSON.stringify(report))
if(!report.passed)throw Error("Shipping built control is not self-consistent")
const sourceCases=Array.from({length:180},(_,id)=>({id,scalar:(id*37)%201-100,mode:(["none","permission","state","sparse","symbol","accessor","proxy","cycle","null"] as const)[id%9]!}))
const source=await runHostRuntimeParity(control,candidate,sourceCases)
writeFileSync(join(root,"shipping-source-parity.json"),JSON.stringify({cases:sourceCases,...source},null,2)+"\n")
if(source.mismatches.length)throw Error("Shipping source differs from frozen control")
const actual=await runBuiltRuntimeParity({controlPackageRoot:control,candidatePackageRoot:candidate,nodeExecutables:[floor,current],outputRoot:join(root,"shipping-built-parity")})
console.log(JSON.stringify(actual))
if(!actual.passed)throw Error("Shipping built artefacts differ from frozen control")
