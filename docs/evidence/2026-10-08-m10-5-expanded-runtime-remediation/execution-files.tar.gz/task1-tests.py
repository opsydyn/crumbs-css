from pathlib import Path
repo=Path('/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css')
p=repo/'packages/css/test/host-remediation-built-parity.test.ts'
p.write_text('''import { expect, it } from "bun:test"
import { mkdtempSync, rmSync, writeFileSync } from "node:fs"
import { tmpdir } from "node:os"
import { join } from "node:path"
import * as receipts from "../bench/host-remediation/receipts"
import { prepareHostRemediationControl } from "../bench/host-remediation/control"

it("records returned callable constructibility without invoking its body", () => {
  const capture = (receipts as unknown as {captureCallableShape?: (value: Function) => unknown}).captureCallableShape
  expect(typeof capture).toBe("function")
  let calls = 0
  function resolve(value: unknown) { calls++; return value }
  const method = { resolve(value: unknown) { calls++; return value } }.resolve
  expect(capture!(resolve)).toMatchObject({ name:"resolve", length:1, hasOwnPrototype:true, constructible:true })
  expect(capture!(method)).toMatchObject({ name:"resolve", length:1, hasOwnPrototype:false, constructible:false })
  expect(calls).toBe(0)
})

it("distinguishes callable arity, name and descriptor changes", () => {
  const capture = (receipts as unknown as {captureCallableShape?: (value: Function) => unknown}).captureCallableShape
  expect(typeof capture).toBe("function")
  const a = { resolve(x: unknown) { return x } }.resolve
  const b = { resolve() { return undefined } }.resolve
  const c = { other(x: unknown) { return x } }.other
  expect(capture!(a)).not.toEqual(capture!(b))
  expect(capture!(a)).not.toEqual(capture!(c))
  const original = capture!(a)
  Object.defineProperty(a,"diagnostic",{value:1,enumerable:true})
  expect(capture!(a)).not.toEqual(original)
})

it("does not invoke callable property getters during inspection", () => {
  const capture = (receipts as unknown as {captureCallableShape?: (value: Function) => unknown}).captureCallableShape
  expect(typeof capture).toBe("function")
  let calls = 0
  const method = { resolve() {} }.resolve
  Object.defineProperty(method,"diagnostic",{get(){calls++; return 1}})
  capture!(method)
  expect(calls).toBe(0)
})

it("honours an explicit control revision instead of silently building the legacy default", async () => {
  const parent = mkdtempSync(join(tmpdir(),"crumbs-explicit-control-"))
  try {
    await expect(prepareHostRemediationControl(join(parent,"control"),"crumbs-m105-nonexistent-revision")).rejects.toThrow(/unknown revision|ambiguous argument|not a valid object name/)
  } finally { rmSync(parent,{recursive:true,force:true}) }
},30_000)
''')
