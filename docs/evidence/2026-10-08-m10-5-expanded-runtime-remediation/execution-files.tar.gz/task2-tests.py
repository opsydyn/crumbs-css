from pathlib import Path
repo=Path('/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css')
(repo/'packages/css/test/host-remediation-runtime-candidate.test.ts').write_text('''import {expect,it} from "bun:test"
import {readFileSync} from "node:fs"
const ids=["runtime-initialization-node22-esm","runtime-initialization-node22-cjs","runtime-initialization-current-esm","runtime-initialization-current-cjs"]
function fixture(){
  const report=JSON.parse(readFileSync("/private/tmp/crumbs-m10-5-expanded/shipping-runtime-graph.json","utf8"))
  for(const entry of ["theme-core","tokens","theme"])for(const format of ["esm","cjs"]){const graph=report.currentGraphs[entry][format];graph.graphBytes=100;graph.samples=[100,100,100,100,100];graph.artifacts=[{file:graph.entry,bytes:100,sha256:"a".repeat(64)}]}
  return {runtimeGraph:report,startupRows:ids.map(id=>({id,result:"pass"})),parityPassed:true}
}
async function assessor(){const m=await import("../bench/host-remediation/runtime-candidate").catch(()=>({}));const f=(m as {checkExpandedRuntimeEvidence?: (e:any)=>readonly string[]}).checkExpandedRuntimeEvidence;expect(typeof f).toBe("function");return f!}
it("rejects a single unchanged startup failure despite eligible new byte sizes",async()=>{const f=await assessor(),e=fixture();expect(f(e)).toEqual([]);e.startupRows[2]!.result="fail";expect(f(e)).toContain("runtime-initialization-current-esm: fail")})
it("admits the initial cap and rejects one byte above it",async()=>{const f=await assessor(),e=fixture(),g=e.runtimeGraph.currentGraphs["theme-core"].esm;g.graphBytes=39000;g.samples=Array(5).fill(39000);g.artifacts[0].bytes=39000;expect(f(e)).toEqual([]);g.graphBytes++;g.samples=Array(5).fill(39001);g.artifacts[0].bytes++;expect(f(e)).toContain("theme-core/esm: admission cap")})
it("rejects missing or duplicated timing rows",async()=>{const f=await assessor(),e=fixture();e.startupRows.pop();expect(f(e).length).toBeGreaterThan(0);e.startupRows.push(e.startupRows[0]!);expect(f(e).length).toBeGreaterThan(0)})
it("rejects cost shifting and malformed graph scans",async()=>{const f=await assessor(),e=fixture(),g=e.runtimeGraph.currentGraphs.theme.cjs;g.externals.push("effect");expect(f(e)).toContain("theme/cjs: runtime loads");g.externals=["react"];g.nonliteralLoads=1;expect(f(e)).toContain("theme/cjs: runtime loads");g.nonliteralLoads=0;g.samples[0]=101;expect(f(e)).toContain("theme/cjs: graph inventory")})
it("rejects method/binding/evaluation parity failure even under every cap",async()=>{const f=await assessor(),e=fixture();e.parityPassed=false;expect(f(e)).toContain("built API parity")})
''')
