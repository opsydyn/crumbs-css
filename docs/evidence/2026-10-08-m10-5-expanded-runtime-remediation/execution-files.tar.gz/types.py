from pathlib import Path
import json,subprocess
root=Path('/private/tmp/crumbs-m10-5-expanded');results=[]
for label,package in [('control',root/'control/packages/css'),('shipping',Path('/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css/packages/css'))]:
 folder=root/(label+'-types');folder.mkdir(exist_ok=True);(folder/'node_modules/@opsydyn').mkdir(parents=True,exist_ok=True); link=folder/'node_modules/@opsydyn/crumbs-css'; link.unlink(missing_ok=True); link.symlink_to(package,target_is_directory=True)
 (folder/'package.json').write_text('{"name":"@fixture/crumbs-consumer","type":"module"}')
 (folder/'consumer.ts').write_text('''import {createThemeTokenReference,resolveThemeStyles} from "@opsydyn/crumbs-css/theme/core";
import {createRecipeResolver,createThemeDependencyResolver} from "@opsydyn/crumbs-css/theme";
const token=createThemeTokenReference("--crumbs-consumer");
const style={padding:4};
const inheritedToken:ReturnType<typeof createThemeTokenReference>=token;
const resolver=createRecipeResolver<{tone:{on:{padding:number}}}>({$$type:"crumbs.css.recipe",base:style,compoundVariants:[],variants:{tone:{on:style}},defaultVariants:{tone:"on"}});
resolver({tone:"on"});resolver.clearCache();resolver.getCacheStats();
createThemeDependencyResolver({},{$$type:"crumbs.css.theme-dependency-plan",version:1,entries:[]});
void resolveThemeStyles;
// @ts-expect-error Unknown variant value must stay rejected.
resolver({tone:"unrecognised"});
''')
 (folder/'tsconfig.json').write_text(json.dumps({'compilerOptions':{'module':'NodeNext','moduleResolution':'NodeNext','target':'ES2022','strict':True,'exactOptionalPropertyTypes':True,'skipLibCheck':True,'noEmit':True},'files':['consumer.ts']}))
 command=['/Users/alancurrie/.local/share/fnm/node-versions/v24.15.0/installation/bin/node','/private/tmp/crumbs-css-m105-clean/node_modules/typescript/bin/tsc','--project',str(folder/'tsconfig.json')]
 # The consumer fixture is an independent declared-type check; record actual compiler, not approved-host qualification.
 r=subprocess.run(command,capture_output=True,text=True);(root/(label+'-types.log')).write_text(r.stdout+r.stderr);results.append({'label':label,'command':command,'exitCode':r.returncode})
print(json.dumps(results,indent=2));(root/'types-results.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['exitCode']==0 for r in results)
