import copy,gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
repo=Path('/Users/alancurrie/.codex/worktrees/crumbs-main-merge/crumbs-css');root=Path('/private/tmp/crumbs-m10-5-expanded');folder=repo/'docs/evidence/2026-10-08-m10-5-expanded-runtime-remediation';folder.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
candidate=json.loads((root/'candidate-source-identity.json').read_text());tracked=set(json.loads((root/'tracked-paths.json').read_text()));control=copy.deepcopy(candidate)
control['files']=[f for f in control['files'] if f['path'] in tracked]
for f in control['files']:f['sha256']=sha((root/'control'/f['path']).read_bytes())
control['sha256']=sha(json.dumps(control['files'],ensure_ascii=False,separators=(',',':')).encode())
assert control['sha256']=='8fe7d6c28c26c9d4214549790d504c62f87c24f6886d7da40e031dd7e9fb4a76',control['sha256']
(root/'control-source-identity.json').write_text(json.dumps(control,indent=2)+'\n')
def archive(name,base,records):
 buf=io.BytesIO()
 with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as tar:
  for path,executable in sorted(records):
   data=(base/path).read_bytes();info=tarfile.TarInfo(path);info.size=len(data);info.mode=0o755 if executable else 0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
 (folder/name).write_bytes(gzip.compress(buf.getvalue(),mtime=0))
ci=json.loads((root/'control-inventory.json').read_text());ni=json.loads((root/'candidate-inventory.json').read_text())
for label,base,identity,inventory in [('control',root/'control',control,ci['inventory']),('candidate',repo,candidate,ni)]:
 records=[(f['path'],f['executable']) for f in identity['files']]+[('packages/css/'+f['path'],False) for f in inventory['artifacts']]
 archive(label+'-tree.tar.gz',base,records)
approval_packet=json.loads((repo/'docs/evidence/2026-10-08-m10-5-expanded-runtime-plan/packet.json').read_text())
archive('approval-documents.tar.gz',repo,[(p,False) for p in approval_packet['documents']])
archive('baseline-evidence.tar.gz',repo,[(f['path'],False) for f in json.loads((root/'baseline-files.json').read_text())])
log_names=[p.name for p in root.iterdir() if p.is_file() and (p.suffix in ['.log','.ts','.mjs','.py'] or p.name in ['types-results.json','dependency-links.json','start.json','explicit-control-result.json'])]
archive('execution-files.tar.gz',root,[(p,False) for p in log_names])
for name in ['candidate.patch','budget-comparator.mjs']:(folder/name).write_bytes((root/name).read_bytes())
report=json.loads((root/'fused-candidate/runtime-candidate.json').read_text())
raw={'controlSource':control,'candidateSource':candidate,'control':ci,'candidate':ni,'registry':json.loads((repo/'packages/css/bench/budgets.json').read_text()),'baselineFiles':json.loads((root/'baseline-files.json').read_text()),'runtime':report,'controlBuiltParity':json.loads((root/'control-built-parity/built-runtime-parity.json').read_text()),'shippingBuiltParity':json.loads((root/'shipping-built-parity/built-runtime-parity.json').read_text()),'minifiedBuiltParity':json.loads((root/'minified-parity/built-runtime-parity.json').read_text()),'candidateBuiltParity':json.loads(Path(report['parity']['receiptsPath']).read_text()),'sourceParity':json.loads((root/'shipping-source-parity.json').read_text()),'firstUse':json.loads((root/'first-use.json').read_text()),'types':json.loads((root/'types-results.json').read_text())}
(folder/'raw.json.gz').write_bytes(gzip.compress(json.dumps(raw,separators=(',',':')).encode(),mtime=0))
print('Archived candidate and original source',len(candidate['files']),len(control['files']))
