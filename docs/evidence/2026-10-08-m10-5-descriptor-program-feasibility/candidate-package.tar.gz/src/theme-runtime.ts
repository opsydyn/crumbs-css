import {runProgram,freezeProgram} from './runtime/descriptor-program'
const __program_resolveThemeStyles=/* @__PURE__ */ freezeProgram([["styles","theme","cached","getCachedResolution","hit","value","resolved","changed","key","style","Object","entries","next","resolveStyleExport","=","!==","result","setCachedResolution"],[20,[[21,[[[0,2],[3,[1,3],[[1,1],[1,0],[0,0,0]],false]]]],[25,[2,[1,2],[0,0,4],false],[23,[2,[1,2],[0,0,5],false]],null],[21,[[[0,6],[9,[]]]]],[21,[[[0,7],[0,1,false]]]],[26,[1,[[[0,8],null,false],[[0,9],null,false]]],[3,[2,[1,10],[0,0,11],false],[[1,0]],false],[20,[[21,[[[0,12],[3,[1,13],[[1,9],[1,1]],false]]]],[22,[5,14,[2,[1,6],[1,8],false],[1,12]]],[25,[5,15,[1,12],[1,9]],[22,[5,14,[1,7],[0,1,true]]],null]]]],[21,[[[0,16],[7,[1,7],[1,6],[1,0]]]]],[22,[3,[1,17],[[1,1],[1,0],[0,0,0],[1,16]],false]],[23,[1,16]]]]])
const __program_createThemeDependencyResolver=/* @__PURE__ */ freezeProgram([["styles","plan","||","!==","$$type","crumbs.css.theme-dependency-plan","version","TypeError","Unsupported theme dependency plan version","canonicalPlan","createThemeDependencyPlan","entries","byToken","Map","entry","token","tokens","dependants","get","===","undefined","set","push","planTokens","keys","sort","left","right","localeCompare","previousTheme","previousValue","hasPrevious","resolve","theme","&&","value","metrics","recomputations","notifications","changedTokens","contractChanged","contract","!","filter","themeTokenChanged","affected","uniquePlanEntries","flatMap","??","nextValue","source","readThemeDependencyPath","path","previous","next","resolveThemeTokens","equivalentResolvedValue","=","setThemeDependencyPath","+=","length","Object","freeze"],[20,[[25,[5,2,[5,3,[2,[1,1],[0,0,4],false],[0,0,5]],[5,3,[2,[1,1],[0,0,6],false],[0,1,1]]],[20,[[24,[4,[1,7],[[0,0,8]]]]]],null],[21,[[[0,9],[3,[1,10],[[2,[1,1],[0,0,11],false]],false]]]],[21,[[[0,12],[4,[1,13],[]]]]],[26,[0,14],[2,[1,9],[0,0,11],false],[20,[[26,[0,15],[2,[1,14],[0,0,16],false],[20,[[21,[[[0,17],[3,[2,[1,12],[0,0,18],false],[[1,15]],false]]]],[25,[5,19,[1,17],[1,20]],[22,[3,[2,[1,12],[0,0,21],false],[[1,15],[8,[[1,14]]]],false]],[22,[3,[2,[1,17],[0,0,22],false],[[1,14]],false]]]]]]]]],[21,[[[0,23],[3,[2,[8,[[11,[3,[2,[1,12],[0,0,24],false],[],false]]]],[0,0,25],false],[[10,[[[0,26],null,false],[[0,27],null,false]],[23,[3,[2,[1,26],[0,0,28],false],[[1,27]],false]],true]],false]]]],[21,[[[0,29],null]]],[21,[[[0,30],null]]],[21,[[[0,31],[0,1,false]]]],[23,[9,[[0,[0,0,32],[10,[[[0,33],null,false]],[20,[[25,[5,34,[1,31],[5,19,[1,33],[1,29]]],[20,[[23,[9,[[0,[0,0,35],[1,30]],[0,[0,0,36],[9,[[0,[0,0,37],[0,1,0]],[0,[0,0,38],[0,1,0]],[0,[0,0,39],[8,[]]]]]]]]]]],null],[21,[[[0,40],[5,34,[1,31],[5,3,[2,[1,29],[0,0,41],false],[2,[1,33],[0,0,41],false]]]]]],[21,[[[0,39],[7,[5,34,[1,31],[6,42,[1,40]]],[3,[2,[1,23],[0,0,43],false],[[10,[[[0,15],null,false]],[23,[3,[1,44],[[1,29],[1,33],[1,15]],false]],true]],false],[1,23]]]]],[21,[[[0,45],[7,[1,31],[3,[1,46],[[3,[2,[1,39],[0,0,47],false],[[10,[[[0,15],null,false]],[23,[5,48,[3,[2,[1,12],[0,0,18],false],[[1,15]],false],[8,[]]]],true]],false]],false],[2,[1,9],[0,0,11],false]]]]],[21,[[[0,49],[7,[1,31],[1,30],[1,0]]]]],[21,[[[0,38],[0,1,0]]]],[26,[0,14],[1,45],[20,[[21,[[[0,50],[3,[1,51],[[1,0],[2,[1,14],[0,0,52],false]],false]]]],[21,[[[0,53],[7,[1,31],[2,[3,[1,51],[[1,30],[2,[1,14],[0,0,52],false]],false],[0,0,35],false],[1,20]]]]],[21,[[[0,54],[3,[1,55],[[2,[1,50],[0,0,35],false],[1,33]],false]]]],[25,[5,34,[1,31],[3,[1,56],[[1,53],[1,54]],false]],[28],null],[22,[5,57,[1,49],[3,[1,58],[[1,49],[2,[1,14],[0,0,52],false],[1,54]],false]]],[25,[1,31],[22,[5,59,[1,38],[0,1,1]]],null]]]],[22,[5,57,[1,29],[1,33]]],[22,[5,57,[1,30],[1,49]]],[22,[5,57,[1,31],[0,1,true]]],[23,[9,[[0,[0,0,35],[1,49]],[0,[0,0,36],[9,[[0,[0,0,37],[2,[1,45],[0,0,60],false]],[0,[0,0,38],[1,38]],[0,[0,0,39],[3,[2,[1,61],[0,0,62],false],[[8,[[11,[1,39]]]]],false]]]]]]]]]],false]]]]]]]])
const __program_themeTokenChanged=/* @__PURE__ */ freezeProgram([["previous","next","token","previousHas","Object","prototype","hasOwnProperty","call","tokens","nextHas","||","!==","!","is"],[20,[[21,[[[0,3],[3,[2,[2,[2,[1,4],[0,0,5],false],[0,0,6],false],[0,0,7],false],[[2,[1,0],[0,0,8],false],[1,2]],false]]]],[21,[[[0,9],[3,[2,[2,[2,[1,4],[0,0,5],false],[0,0,6],false],[0,0,7],false],[[2,[1,1],[0,0,8],false],[1,2]],false]]]],[23,[5,10,[5,11,[1,3],[1,9]],[6,12,[3,[2,[1,4],[0,0,13],false],[[2,[2,[1,0],[0,0,8],false],[1,2],false],[2,[2,[1,1],[0,0,8],false],[1,2],false]],false]]]]]]])
const __program_uniquePlanEntries=/* @__PURE__ */ freezeProgram([["entries","byPath","Map","entry","set","themeDependencyPathKey","path","values","sort","left","right","localeCompare"],[20,[[21,[[[0,1],[4,[1,2],[]]]]],[26,[0,3],[1,0],[22,[3,[2,[1,1],[0,0,4],false],[[3,[1,5],[[2,[1,3],[0,0,6],false]],false],[1,3]],false]]],[23,[3,[2,[8,[[11,[3,[2,[1,1],[0,0,7],false],[],false]]]],[0,0,8],false],[[10,[[[0,9],null,false],[[0,10],null,false]],[23,[3,[2,[3,[1,5],[[2,[1,9],[0,0,6],false]],false],[0,0,11],false],[[3,[1,5],[[2,[1,10],[0,0,6],false]],false]],false]],true]],false]]]]])
const __program_readThemeDependencyPath=/* @__PURE__ */ freezeProgram([["root","path","cursor","segment","||","===","!==","typeof","object","!","Object","prototype","hasOwnProperty","call","TypeError","Theme dependency plan path does not exist: ","formatThemeDependencyPath","","=","value"],[20,[[21,[[[0,2],[1,0]]]],[26,[0,3],[1,1],[20,[[25,[5,4,[5,4,[5,5,[1,2],[0,1,null]],[5,6,[6,7,[1,2]],[0,0,8]]],[6,9,[3,[2,[2,[2,[1,10],[0,0,11],false],[0,0,12],false],[0,0,13],false],[[1,2],[1,3]],false]]],[20,[[24,[4,[1,14],[[12,15,[[[3,[1,16],[[1,1]],false],17]]]]]]]],null],[22,[5,18,[1,2],[2,[1,2],[1,3],false]]]]]],[23,[9,[[0,[0,0,19],[1,2]]]]]]]])
const __program_setThemeDependencyPath=/* @__PURE__ */ freezeProgram([["root","path","value","===","length","nextRoot","cloneThemeDependencyContainer","cursor","index","<","-","+=","segment","objectCursor","child","nextChild","=","finalCursor"],[20,[[25,[5,3,[2,[1,1],[0,0,4],false],[0,1,0]],[23,[1,2]],null],[21,[[[0,5],[3,[1,6],[[1,0]],false]]]],[21,[[[0,7],[1,5]]]],[27,[21,[[[0,8],[0,1,0]]]],[5,9,[1,8],[5,10,[2,[1,1],[0,0,4],false],[0,1,1]]],[5,11,[1,8],[0,1,1]],[20,[[21,[[[0,12],[2,[1,1],[1,8],false]]]],[21,[[[0,13],[1,7]]]],[21,[[[0,14],[2,[1,13],[1,12],false]]]],[21,[[[0,15],[3,[1,6],[[1,14]],false]]]],[22,[5,16,[2,[1,13],[1,12],false],[1,15]]],[22,[5,16,[1,7],[1,15]]]]]],[21,[[[0,17],[1,7]]]],[22,[5,16,[2,[1,17],[2,[1,1],[5,10,[2,[1,1],[0,0,4],false],[0,1,1]],false],false],[1,2]]],[23,[1,5]]]]])
const __program_cloneThemeDependencyContainer=/* @__PURE__ */ freezeProgram([["value","Array","isArray","&&","!==","===","typeof","object","Object","assign","create","getPrototypeOf","TypeError","Theme dependency plan path traverses a non-container value"],[20,[[25,[3,[2,[1,1],[0,0,2],false],[[1,0]],false],[23,[8,[[11,[1,0]]]]],null],[25,[5,3,[5,4,[1,0],[0,1,null]],[5,5,[6,6,[1,0]],[0,0,7]]],[20,[[23,[3,[2,[1,8],[0,0,9],false],[[3,[2,[1,8],[0,0,10],false],[[3,[2,[1,8],[0,0,11],false],[[1,0]],false]],false],[1,0]],false]]]],null],[24,[4,[1,12],[[0,0,13]]]]]]])
const __program_equivalentResolvedValue=/* @__PURE__ */ freezeProgram([["left","right","Object","is","||","Array","isArray","&&","===","length","every","entry","index","!==","typeof","object","leftKeys","Reflect","ownKeys","rightKeys","key","prototype","hasOwnProperty","call"],[20,[[25,[3,[2,[1,2],[0,0,3],false],[[1,0],[1,1]],false],[23,[0,1,true]],null],[25,[5,4,[3,[2,[1,5],[0,0,6],false],[[1,0]],false],[3,[2,[1,5],[0,0,6],false],[[1,1]],false]],[20,[[23,[5,7,[5,7,[5,7,[3,[2,[1,5],[0,0,6],false],[[1,0]],false],[3,[2,[1,5],[0,0,6],false],[[1,1]],false]],[5,8,[2,[1,0],[0,0,9],false],[2,[1,1],[0,0,9],false]]],[3,[2,[1,0],[0,0,10],false],[[10,[[[0,11],null,false],[[0,12],null,false]],[23,[3,[2,[1,2],[0,0,3],false],[[1,11],[2,[1,1],[1,12],false]],false]],true]],false]]]]],null],[25,[5,4,[5,4,[5,4,[5,8,[1,0],[0,1,null]],[5,8,[1,1],[0,1,null]]],[5,13,[6,14,[1,0]],[0,0,15]]],[5,13,[6,14,[1,1]],[0,0,15]]],[23,[0,1,false]],null],[21,[[[0,16],[3,[2,[1,17],[0,0,18],false],[[1,0]],false]]]],[21,[[[0,19],[3,[2,[1,17],[0,0,18],false],[[1,1]],false]]]],[23,[5,7,[5,8,[2,[1,16],[0,0,9],false],[2,[1,19],[0,0,9],false]],[3,[2,[1,16],[0,0,10],false],[[10,[[[0,20],null,false]],[23,[5,7,[3,[2,[2,[2,[1,2],[0,0,21],false],[0,0,22],false],[0,0,23],false],[[1,1],[1,20]],false],[3,[2,[1,2],[0,0,3],false],[[2,[1,0],[1,20],false],[2,[1,1],[1,20],false]],false]]],true]],false]]]]]])
const __program_formatThemeDependencyPath=/* @__PURE__ */ freezeProgram([["path","map","segment","===","typeof","number","[","]","join","."],[20,[[23,[3,[2,[3,[2,[1,0],[0,0,1],false],[[10,[[[0,2],null,false]],[23,[7,[5,3,[6,4,[1,2]],[0,0,5]],[12,6,[[[1,2],7]]],[1,2]]],true]],false],[0,0,8],false],[[0,0,9]],false]]]]])
const __program_resolveThemeTokens=/* @__PURE__ */ freezeProgram([["style","theme","cached","getCachedResolution","tokens","hit","value","isNativeComponentRecipe","resolved","resolveComponentRecipeThemeTokens","setCachedResolution","isNativeComponentRecipeExtension","resolveComponentRecipeExtensionThemeTokens","flattened","flattenStyle","===","undefined","entries","Object","changed","Array","isArray","index","entry","key","isThemeTokenReferenceCandidate","assertThemeTokenReference","=","previousKey","previousValue","slice","resolveTokenValue","varName","!==","result","??"],[20,[[21,[[[0,2],[3,[1,3],[[1,1],[1,0],[0,0,4]],false]]]],[25,[2,[1,2],[0,0,5],false],[23,[2,[1,2],[0,0,6],false]],null],[25,[3,[1,7],[[1,0]],false],[20,[[21,[[[0,8],[3,[1,9],[[1,0],[1,1]],false]]]],[22,[3,[1,10],[[1,1],[1,0],[0,0,4],[1,8]],false]],[23,[1,8]]]],null],[25,[3,[1,11],[[1,0]],false],[20,[[21,[[[0,8],[3,[1,12],[[1,0],[1,1]],false]]]],[22,[3,[1,10],[[1,1],[1,0],[0,0,4],[1,8]],false]],[23,[1,8]]]],null],[21,[[[0,13],[3,[1,14],[[1,0]],false]]]],[25,[5,15,[1,13],[1,16]],[20,[[22,[3,[1,10],[[1,1],[1,0],[0,0,4],[1,16]],false]],[23,[1,16]]]],null],[21,[[[0,17],[3,[2,[1,18],[0,0,17],false],[[1,13]],false]]]],[21,[[[0,19],[3,[2,[1,20],[0,0,21],false],[[1,0]],false]]]],[21,[[[0,8],[7,[3,[2,[1,20],[0,0,21],false],[[1,0]],false],[9,[]],[1,16]]]]],[26,[1,[[[0,22],null,false],[[0,23],null,false]]],[3,[2,[1,17],[0,0,17],false],[],false],[20,[[21,[[[1,[[[0,24],null,false],[[0,6],null,false]]],[1,23]]]],[25,[3,[1,25],[[1,6]],false],[20,[[22,[3,[1,26],[[1,6],[1,24]],false]],[25,[5,15,[1,8],[1,16]],[20,[[22,[5,27,[1,8],[9,[]]]],[26,[1,[[[0,28],null,false],[[0,29],null,false]]],[3,[2,[1,17],[0,0,30],false],[[0,1,0],[1,22]],false],[20,[[22,[5,27,[2,[1,8],[1,28],false],[1,29]]]]]]]],null],[22,[5,27,[2,[1,8],[1,24],false],[3,[1,31],[[2,[1,6],[0,0,32],false],[1,1]],false]]],[22,[5,27,[1,19],[0,1,true]]]]],[25,[5,33,[1,8],[1,16]],[22,[5,27,[2,[1,8],[1,24],false],[1,6]]],null]]]]],[21,[[[0,34],[7,[1,19],[5,35,[1,8],[9,[]]],[1,0]]]]],[22,[3,[1,10],[[1,1],[1,0],[0,0,4],[1,34]],false]],[23,[1,34]]]]])
const __program_flattenStyle=/* @__PURE__ */ freezeProgram([["style","||","===","undefined","Array","isArray","flattened","flatMap","item","resolved","flattenStyle","length","Object","assign","typeof","object"],[20,[[25,[5,1,[5,1,[5,2,[1,0],[0,1,null]],[5,2,[1,0],[1,3]]],[5,2,[1,0],[0,1,false]]],[23,[1,3]],null],[25,[3,[2,[1,4],[0,0,5],false],[[1,0]],false],[20,[[21,[[[0,6],[3,[2,[1,0],[0,0,7],false],[[10,[[[0,8],null,false]],[20,[[21,[[[0,9],[3,[1,10],[[1,8]],false]]]],[23,[7,[5,2,[1,9],[1,3]],[8,[]],[8,[[1,9]]]]]]],true]],false]]]],[25,[5,2,[2,[1,6],[0,0,11],false],[0,1,0]],[23,[1,3]],null],[23,[3,[2,[1,12],[0,0,13],false],[[9,[]],[11,[1,6]]],false]]]],null],[25,[5,2,[6,14,[1,0]],[0,0,15]],[23,[1,0]],null],[23,[1,3]]]]])
const __program_resolveStyleExport=/* @__PURE__ */ freezeProgram([["style","theme","isNativeComponentRecipe","resolveComponentRecipeThemeTokens","isNativeRecipe","resolveRecipeThemeTokens","isNativeSprinklesLookupPlan","resolveSprinklesThemeTokens","isNestedStyleMap","resolved","changed","key","value","Object","entries","next","resolveThemeTokens","=","!==","!","isNativeStyleMap","markNativeStyleMap"],[20,[[25,[3,[1,2],[[1,0]],false],[23,[3,[1,3],[[1,0],[1,1]],false]],null],[25,[3,[1,4],[[1,0]],false],[23,[3,[1,5],[[1,0],[1,1]],false]],null],[25,[3,[1,6],[[1,0]],false],[23,[3,[1,7],[[1,0],[1,1]],false]],null],[25,[3,[1,8],[[1,0]],false],[20,[[21,[[[0,9],[9,[]]]]],[21,[[[0,10],[0,1,false]]]],[26,[1,[[[0,11],null,false],[[0,12],null,false]]],[3,[2,[1,13],[0,0,14],false],[[1,0]],false],[20,[[21,[[[0,15],[3,[1,16],[[1,12],[1,1]],false]]]],[22,[5,17,[2,[1,9],[1,11],false],[1,15]]],[25,[5,18,[1,15],[1,12]],[22,[5,17,[1,10],[0,1,true]]],null]]]],[25,[6,19,[1,10]],[23,[1,0]],null],[23,[7,[3,[1,20],[[1,0]],false],[3,[1,21],[[1,9]],false],[1,9]]]]],null],[23,[3,[1,16],[[1,0],[1,1]],false]]]]])
const __program_resolveSprinklesThemeTokens=/* @__PURE__ */ freezeProgram([["plan","theme","changed","properties","property","scale","Object","entries","resolvedScale","scaleName","style","next","&&","===","typeof","object","!==","??","resolveThemeTokens","=","!","freeze","fromEntries","map"],[20,[[21,[[[0,2],[0,1,false]]]],[21,[[[0,3],[9,[]]]]],[26,[1,[[[0,4],null,false],[[0,5],null,false]]],[3,[2,[1,6],[0,0,7],false],[[2,[1,0],[0,0,3],false]],false],[20,[[21,[[[0,8],[9,[]]]]],[26,[1,[[[0,9],null,false],[[0,10],null,false]]],[3,[2,[1,6],[0,0,7],false],[[1,5]],false],[20,[[21,[[[0,11],[7,[5,12,[5,13,[6,14,[1,10]],[0,0,15]],[5,16,[1,10],[0,1,null]]],[5,17,[3,[1,18],[[1,10],[1,1]],false],[1,10]],[1,10]]]]],[22,[5,19,[2,[1,8],[1,9],false],[1,11]]],[25,[5,16,[1,11],[1,10]],[22,[5,19,[1,2],[0,1,true]]],null]]]],[22,[5,19,[2,[1,3],[1,4],false],[1,8]]]]]],[25,[6,20,[1,2]],[23,[1,0]],null],[23,[3,[2,[1,6],[0,0,21],false],[[9,[[1,[1,0]],[0,[0,0,3],[3,[2,[1,6],[0,0,21],false],[[3,[2,[1,6],[0,0,22],false],[[3,[2,[3,[2,[1,6],[0,0,7],false],[[1,3]],false],[0,0,23],false],[[10,[[[1,[[[0,4],null,false],[[0,5],null,false]]],null,false]],[23,[8,[[1,4],[3,[2,[1,6],[0,0,21],false],[[1,5]],false]]]],true]],false]],false]],false]]]]],false]]]]])
const __program_resolveRecipeThemeTokens=/* @__PURE__ */ freezeProgram([["recipe","theme","cached","getCachedResolution","hit","value","variants","changed","||","===","undefined","defaultVariants","compoundVariants","variantName","variantValues","Object","entries","??","resolvedValues","valueName","style","next","resolveThemeTokens","=","!==","base","map","compoundVariant","!","setCachedResolution","resolved","$$type","NativeRecipeType","$$debugName"],[20,[[21,[[[0,2],[3,[1,3],[[1,1],[1,0],[0,0,0]],false]]]],[25,[2,[1,2],[0,0,4],false],[23,[2,[1,2],[0,0,5],false]],null],[21,[[[0,6],[9,[]]]]],[21,[[[0,7],[5,8,[5,8,[5,9,[2,[1,0],[0,0,6],false],[1,10]],[5,9,[2,[1,0],[0,0,11],false],[1,10]]],[5,9,[2,[1,0],[0,0,12],false],[1,10]]]]]],[26,[1,[[[0,13],null,false],[[0,14],null,false]]],[3,[2,[1,15],[0,0,16],false],[[5,17,[2,[1,0],[0,0,6],false],[9,[]]]],false],[20,[[21,[[[0,18],[9,[]]]]],[26,[1,[[[0,19],null,false],[[0,20],null,false]]],[3,[2,[1,15],[0,0,16],false],[[1,14]],false],[20,[[21,[[[0,21],[3,[1,22],[[1,20],[1,1]],false]]]],[22,[5,23,[2,[1,18],[1,19],false],[1,21]]],[25,[5,24,[1,21],[1,20]],[22,[5,23,[1,7],[0,1,true]]],null]]]],[22,[5,23,[2,[1,6],[1,13],false],[1,18]]]]]],[21,[[[0,25],[7,[5,9,[2,[1,0],[0,0,25],false],[1,10]],[1,10],[3,[1,22],[[2,[1,0],[0,0,25],false],[1,1]],false]]]]],[25,[5,24,[1,25],[2,[1,0],[0,0,25],false]],[22,[5,23,[1,7],[0,1,true]]],null],[21,[[[0,12],[3,[2,[5,17,[2,[1,0],[0,0,12],false],[8,[]]],[0,0,26],false],[[10,[[[0,27],null,false]],[20,[[21,[[[0,20],[3,[1,22],[[2,[1,27],[0,0,20],false],[1,1]],false]]]],[25,[5,24,[1,20],[2,[1,27],[0,0,20],false]],[22,[5,23,[1,7],[0,1,true]]],null],[23,[9,[[0,[0,0,20],[1,20]],[0,[0,0,6],[2,[1,27],[0,0,6],false]]]]]]],true]],false]]]],[25,[6,28,[1,7]],[20,[[22,[3,[1,29],[[1,1],[1,0],[0,0,0],[1,0]],false]],[23,[1,0]]]],null],[21,[[[0,30],[9,[[0,[0,0,31],[1,32]],[1,[7,[5,9,[2,[1,0],[0,0,33],false],[1,10]],[9,[]],[9,[[0,[0,0,33],[2,[1,0],[0,0,33],false]]]]]],[1,[7,[5,9,[1,25],[1,10]],[9,[]],[9,[[0,[0,0,25],[1,25]]]]]],[0,[0,0,12],[1,12]],[0,[0,0,11],[5,17,[2,[1,0],[0,0,11],false],[9,[]]]],[0,[0,0,6],[1,6]]]]]]],[22,[3,[1,29],[[1,1],[1,0],[0,0,0],[1,30]],false]],[23,[1,30]]]]])
const __program_resolveComponentRecipeThemeTokens=/* @__PURE__ */ freezeProgram([["recipe","theme","cached","getCachedResolution","component-recipe","hit","value","&&","!==","version","NativeComponentRecipeLegacyVersion","NativeComponentRecipeVersion","NativeComponentRecipeContractVersion","TypeError","Unsupported component recipe version ","String","","===","contract","undefined","Version 3 component recipes require contract metadata","variantSurface","Object","fromEntries","entries","??","variants","map","axis","values","keys","validateNativeComponentContract","slots","stateVariants","Component contract metadata requires component recipe version 3","changed","||","defaultVariants","compoundVariants","base","resolveComponentSlotStyles","=","variantName","variantValues","resolvedValues","valueName","styles","variant ","JSON","stringify"," value ","freeze","compound","index","compound variant ","!","setCachedResolution","frozenVariants","freezeComponentSlotStyles","frozenCompounds","cloneAndFreezeComponentStyle","resolved","$$type","NativeComponentRecipeType","$$debugName"],[20,[[21,[[[0,2],[3,[1,3],[[1,1],[1,0],[0,0,4]],false]]]],[25,[2,[1,2],[0,0,5],false],[23,[2,[1,2],[0,0,6],false]],null],[25,[5,7,[5,7,[5,8,[2,[1,0],[0,0,9],false],[1,10]],[5,8,[2,[1,0],[0,0,9],false],[1,11]]],[5,8,[2,[1,0],[0,0,9],false],[1,12]]],[20,[[24,[4,[1,13],[[12,14,[[[3,[1,15],[[2,[1,0],[0,0,9],false]],false],16]]]]]]]],null],[25,[5,17,[2,[1,0],[0,0,9],false],[1,12]],[20,[[25,[5,17,[2,[1,0],[0,0,18],false],[1,19]],[20,[[24,[4,[1,13],[[0,0,20]]]]]],null],[21,[[[0,21],[3,[2,[1,22],[0,0,23],false],[[3,[2,[3,[2,[1,22],[0,0,24],false],[[5,25,[2,[1,0],[0,0,26],false],[9,[]]]],false],[0,0,27],false],[[10,[[[1,[[[0,28],null,false],[[0,29],null,false]]],null,false]],[23,[8,[[1,28],[3,[2,[1,22],[0,0,23],false],[[3,[2,[3,[2,[1,22],[0,0,30],false],[[1,29]],false],[0,0,27],false],[[10,[[[0,6],null,false]],[23,[8,[[1,6],[0,1,true]]]],true]],false]],false]]]],true]],false]],false]]]],[22,[3,[1,31],[[2,[1,0],[0,0,18],false],[9,[[0,[0,0,32],[2,[1,0],[0,0,32],false]],[0,[0,0,26],[1,21]]]],[2,[1,0],[0,0,33],false]],false]]]],[25,[5,8,[2,[1,0],[0,0,18],false],[1,19]],[20,[[24,[4,[1,13],[[0,0,34]]]]]],null]],[21,[[[0,35],[5,36,[5,36,[5,17,[2,[1,0],[0,0,26],false],[1,19]],[5,17,[2,[1,0],[0,0,37],false],[1,19]]],[5,17,[2,[1,0],[0,0,38],false],[1,19]]]]]],[21,[[[0,39],[7,[5,17,[2,[1,0],[0,0,39],false],[1,19]],[1,19],[3,[1,40],[[2,[1,0],[0,0,39],false],[1,1],[0,0,39],[10,[],[20,[[22,[5,41,[1,35],[0,1,true]]]]],true]],false]]]]],[21,[[[0,26],[9,[]]]]],[26,[1,[[[0,42],null,false],[[0,43],null,false]]],[3,[2,[1,22],[0,0,24],false],[[5,25,[2,[1,0],[0,0,26],false],[9,[]]]],false],[20,[[21,[[[0,44],[9,[]]]]],[26,[1,[[[0,45],null,false],[[0,46],null,false]]],[3,[2,[1,22],[0,0,24],false],[[1,43]],false],[20,[[22,[5,41,[2,[1,44],[1,45],false],[3,[1,40],[[1,46],[1,1],[12,47,[[[3,[2,[1,48],[0,0,49],false],[[1,42]],false],50],[[3,[2,[1,48],[0,0,49],false],[[1,45]],false],16]]],[10,[],[20,[[22,[5,41,[1,35],[0,1,true]]]]],true]],false]]]]]],[22,[5,41,[2,[1,26],[1,42],false],[3,[2,[1,22],[0,0,51],false],[[1,44]],false]]]]]],[21,[[[0,38],[3,[2,[5,25,[2,[1,0],[0,0,38],false],[8,[]]],[0,0,27],false],[[10,[[[0,52],null,false],[[0,53],null,false]],[23,[3,[2,[1,22],[0,0,51],false],[[9,[[0,[0,0,26],[3,[2,[1,22],[0,0,51],false],[[9,[[1,[2,[1,52],[0,0,26],false]]]]],false]],[0,[0,0,46],[3,[1,40],[[2,[1,52],[0,0,46],false],[1,1],[12,54,[[[1,53],16]]],[10,[],[20,[[22,[5,41,[1,35],[0,1,true]]]]],true]],false]]]]],false]],true]],false]]]],[25,[6,55,[1,35]],[20,[[22,[3,[1,56],[[1,1],[1,0],[0,0,4],[1,0]],false]],[23,[1,0]]]],null],[21,[[[0,57],[3,[2,[1,22],[0,0,51],false],[[3,[2,[1,22],[0,0,23],false],[[3,[2,[3,[2,[1,22],[0,0,24],false],[[1,26]],false],[0,0,27],false],[[10,[[[1,[[[0,42],null,false],[[0,29],null,false]]],null,false]],[23,[8,[[1,42],[3,[2,[1,22],[0,0,51],false],[[3,[2,[1,22],[0,0,23],false],[[3,[2,[3,[2,[1,22],[0,0,24],false],[[1,29]],false],[0,0,27],false],[[10,[[[1,[[[0,45],null,false],[[0,46],null,false]]],null,false]],[23,[8,[[1,45],[3,[1,58],[[1,46]],false]]]],true]],false]],false]],false]]]],true]],false]],false]],false]]]],[21,[[[0,59],[3,[2,[1,22],[0,0,51],false],[[3,[2,[1,38],[0,0,27],false],[[10,[[[0,52],null,false]],[23,[3,[2,[1,22],[0,0,51],false],[[9,[[0,[0,0,26],[2,[1,52],[0,0,26],false]],[0,[0,0,46],[3,[1,58],[[2,[1,52],[0,0,46],false]],false]]]]],false]],true]],false]],false]]]],[21,[[[0,33],[7,[5,17,[2,[1,0],[0,0,33],false],[1,19]],[1,19],[3,[1,60],[[2,[1,0],[0,0,33],false]],false]]]]],[21,[[[0,61],[3,[2,[1,22],[0,0,51],false],[[9,[[0,[0,0,62],[1,63]],[0,[0,0,9],[2,[1,0],[0,0,9],false]],[1,[7,[5,17,[2,[1,0],[0,0,64],false],[1,19]],[9,[]],[9,[[0,[0,0,64],[2,[1,0],[0,0,64],false]]]]]],[0,[0,0,32],[3,[2,[1,22],[0,0,51],false],[[9,[[1,[2,[1,0],[0,0,32],false]]]]],false]],[1,[7,[5,17,[2,[1,0],[0,0,18],false],[1,19]],[9,[]],[9,[[0,[0,0,18],[2,[1,0],[0,0,18],false]]]]]],[1,[7,[5,17,[1,39],[1,19]],[9,[]],[9,[[0,[0,0,39],[3,[1,58],[[1,39]],false]]]]]],[0,[0,0,26],[1,57]],[0,[0,0,37],[3,[2,[1,22],[0,0,51],false],[[9,[[1,[2,[1,0],[0,0,37],false]]]]],false]],[1,[7,[5,17,[1,33],[1,19]],[9,[]],[9,[[0,[0,0,33],[1,33]]]]]],[0,[0,0,38],[1,59]]]]],false]]]],[22,[3,[1,56],[[1,1],[1,0],[0,0,4],[1,61]],false]],[23,[1,61]]]]])
const __program_resolveComponentRecipeExtensionThemeTokens=/* @__PURE__ */ freezeProgram([["extension","theme","cached","getCachedResolution","component-recipe-extension","hit","value","!==","version","NativeComponentRecipeExtensionVersion","TypeError","Unsupported component recipe extension version ","String","","normalized","validateNativeComponentRecipeExtensionDescriptor","changed","variants","Object","fromEntries","entries","map","axis","values","styles","resolveComponentSlotStyles","extension variant ","JSON","stringify"," value ","=","compoundVariants","compound","index","freeze","extension compound variant ","slotOverrides","extension slot overrides","!","setCachedResolution","resolved","defaultVariants","cloneAndFreezeComponentStyle","freezeComponentSlotStyles"],[20,[[21,[[[0,2],[3,[1,3],[[1,1],[1,0],[0,0,4]],false]]]],[25,[2,[1,2],[0,0,5],false],[23,[2,[1,2],[0,0,6],false]],null],[25,[5,7,[2,[1,0],[0,0,8],false],[1,9]],[20,[[24,[4,[1,10],[[12,11,[[[3,[1,12],[[2,[1,0],[0,0,8],false]],false],13]]]]]]]],null],[21,[[[0,14],[3,[1,15],[[1,0]],false]]]],[21,[[[0,16],[0,1,false]]]],[21,[[[0,17],[3,[2,[1,18],[0,0,19],false],[[3,[2,[3,[2,[1,18],[0,0,20],false],[[2,[1,14],[0,0,17],false]],false],[0,0,21],false],[[10,[[[1,[[[0,22],null,false],[[0,23],null,false]]],null,false]],[23,[8,[[1,22],[3,[2,[1,18],[0,0,19],false],[[3,[2,[3,[2,[1,18],[0,0,20],false],[[1,23]],false],[0,0,21],false],[[10,[[[1,[[[0,6],null,false],[[0,24],null,false]]],null,false]],[23,[8,[[1,6],[3,[1,25],[[1,24],[1,1],[12,26,[[[3,[2,[1,27],[0,0,28],false],[[1,22]],false],29],[[3,[2,[1,27],[0,0,28],false],[[1,6]],false],13]]],[10,[],[20,[[22,[5,30,[1,16],[0,1,true]]]]],true]],false]]]],true]],false]],false]]]],true]],false]],false]]]],[21,[[[0,31],[3,[2,[2,[1,14],[0,0,31],false],[0,0,21],false],[[10,[[[0,32],null,false],[[0,33],null,false]],[23,[3,[2,[1,18],[0,0,34],false],[[9,[[0,[0,0,17],[2,[1,32],[0,0,17],false]],[0,[0,0,24],[3,[1,25],[[2,[1,32],[0,0,24],false],[1,1],[12,35,[[[1,33],13]]],[10,[],[20,[[22,[5,30,[1,16],[0,1,true]]]]],true]],false]]]]],false]],true]],false]]]],[21,[[[0,36],[3,[1,25],[[2,[1,14],[0,0,36],false],[1,1],[0,0,37],[10,[],[20,[[22,[5,30,[1,16],[0,1,true]]]]],true]],false]]]],[25,[6,38,[1,16]],[20,[[22,[3,[1,39],[[1,1],[1,0],[0,0,4],[1,0]],false]],[23,[1,0]]]],null],[21,[[[0,40],[3,[2,[1,18],[0,0,34],false],[[9,[[1,[1,14]],[0,[0,0,41],[3,[1,42],[[2,[1,14],[0,0,41],false]],false]],[0,[0,0,17],[3,[2,[1,18],[0,0,34],false],[[3,[2,[1,18],[0,0,19],false],[[3,[2,[3,[2,[1,18],[0,0,20],false],[[1,17]],false],[0,0,21],false],[[10,[[[1,[[[0,22],null,false],[[0,23],null,false]]],null,false]],[23,[8,[[1,22],[3,[2,[1,18],[0,0,34],false],[[3,[2,[1,18],[0,0,19],false],[[3,[2,[3,[2,[1,18],[0,0,20],false],[[1,23]],false],[0,0,21],false],[[10,[[[1,[[[0,6],null,false],[[0,24],null,false]]],null,false]],[23,[8,[[1,6],[3,[1,43],[[1,24]],false]]]],true]],false]],false]],false]]]],true]],false]],false]],false]],[0,[0,0,31],[3,[2,[1,18],[0,0,34],false],[[3,[2,[1,31],[0,0,21],false],[[10,[[[0,32],null,false]],[23,[3,[2,[1,18],[0,0,34],false],[[9,[[0,[0,0,17],[3,[1,42],[[2,[1,32],[0,0,17],false]],false]],[0,[0,0,24],[3,[1,43],[[2,[1,32],[0,0,24],false]],false]]]]],false]],true]],false]],false]],[0,[0,0,36],[3,[1,43],[[1,36]],false]]]]],false]]]],[22,[3,[1,39],[[1,1],[1,0],[0,0,4],[1,40]],false]],[23,[1,40]]]]])
const __program_resolveComponentSlotStyles=/* @__PURE__ */ freezeProgram([["styles","theme","context","markChanged","entries","assertComponentThemeRecord","Component recipe "," slot styles","slot","style","Object","next","resolveThemeTokens","!==","push","??","freeze","fromEntries"],[20,[[21,[[[0,4],[8,[]]]]],[22,[3,[1,5],[[1,0],[12,6,[[[1,2],7]]]],false]],[26,[1,[[[0,8],null,false],[[0,9],null,false]]],[3,[2,[1,10],[0,0,4],false],[[1,0]],false],[20,[[21,[[[0,11],[3,[1,12],[[1,9],[1,1]],false]]]],[25,[5,13,[1,11],[1,9]],[22,[3,[1,3],[],false]],null],[22,[3,[2,[1,4],[0,0,14],false],[[8,[[1,8],[5,15,[1,11],[1,9]]]]],false]]]]],[23,[3,[2,[1,10],[0,0,16],false],[[3,[2,[1,10],[0,0,17],false],[[1,4]],false]],false]]]]])
const __program_assertComponentThemeRecord=/* @__PURE__ */ freezeProgram([["value","context","||","===","!==","typeof","object","Array","isArray","TypeError",""," must be a record","prototype","Object","getPrototypeOf","&&"," must be a plain record","descriptor","values","getOwnPropertyDescriptors","!","in","enumerable"," must contain enumerable data properties"],[20,[[25,[5,2,[5,2,[5,3,[1,0],[0,1,null]],[5,4,[6,5,[1,0]],[0,0,6]]],[3,[2,[1,7],[0,0,8],false],[[1,0]],false]],[20,[[24,[4,[1,9],[[12,10,[[[1,1],11]]]]]]]],null],[21,[[[0,12],[3,[2,[1,13],[0,0,14],false],[[1,0]],false]]]],[25,[5,15,[5,4,[1,12],[2,[1,13],[0,0,12],false]],[5,4,[1,12],[0,1,null]]],[20,[[24,[4,[1,9],[[12,10,[[[1,1],16]]]]]]]],null],[26,[0,17],[3,[2,[1,13],[0,0,18],false],[[3,[2,[1,13],[0,0,19],false],[[1,0]],false]],false],[20,[[25,[5,2,[6,20,[5,21,[0,0,0],[1,17]]],[6,20,[2,[1,17],[0,0,22],false]]],[20,[[24,[4,[1,9],[[12,10,[[[1,1],23]]]]]]]],null]]]]]]])
const __program_freezeComponentSlotStyles=/* @__PURE__ */ freezeProgram([["styles","Object","freeze","fromEntries","entries","map","slot","style","cloneAndFreezeComponentStyle"],[20,[[23,[3,[2,[1,1],[0,0,2],false],[[3,[2,[1,1],[0,0,3],false],[[3,[2,[3,[2,[1,1],[0,0,4],false],[[1,0]],false],[0,0,5],false],[[10,[[[1,[[[0,6],null,false],[[0,7],null,false]]],null,false]],[23,[8,[[1,6],[3,[1,8],[[1,7]],false]]]],true]],false]],false]],false]]]]])
const __program_cloneAndFreezeComponentStyle=/* @__PURE__ */ freezeProgram([["value","Array","isArray","Object","freeze","map","entry","cloneAndFreezeComponentStyle","||","===","!==","typeof","object","&&","in","$$type","NativeRecipeClassType","className","string","isFrozen","clone","create","getPrototypeOf","key","Reflect","ownKeys","descriptor","getOwnPropertyDescriptor","undefined","!","TypeError","Component recipe style values must be plain data records","defineProperty"],[20,[[25,[3,[2,[1,1],[0,0,2],false],[[1,0]],false],[20,[[23,[3,[2,[1,3],[0,0,4],false],[[3,[2,[1,0],[0,0,5],false],[[10,[[[0,6],null,false]],[23,[3,[1,7],[[1,6]],false]],true]],false]],false]]]],null],[25,[5,8,[5,9,[1,0],[0,1,null]],[5,10,[6,11,[1,0]],[0,0,12]]],[23,[1,0]],null],[25,[5,13,[5,13,[5,13,[5,13,[5,14,[0,0,15],[1,0]],[5,9,[2,[1,0],[0,0,15],false],[1,16]]],[5,14,[0,0,17],[1,0]]],[5,9,[6,11,[2,[1,0],[0,0,17],false]],[0,0,18]]],[3,[2,[1,3],[0,0,19],false],[[1,0]],false]],[20,[[23,[1,0]]]],null],[21,[[[0,20],[3,[2,[1,3],[0,0,21],false],[[3,[2,[1,3],[0,0,22],false],[[1,0]],false]],false]]]],[26,[0,23],[3,[2,[1,24],[0,0,25],false],[[1,0]],false],[20,[[21,[[[0,26],[3,[2,[1,3],[0,0,27],false],[[1,0],[1,23]],false]]]],[25,[5,9,[1,26],[1,28]],[28],null],[25,[6,29,[5,14,[0,0,0],[1,26]]],[20,[[24,[4,[1,30],[[0,0,31]]]]]],null],[22,[3,[2,[1,3],[0,0,32],false],[[1,20],[1,23],[9,[[1,[1,26]],[0,[0,0,0],[3,[1,7],[[2,[1,26],[0,0,0],false]],false]]]]],false]]]]],[23,[3,[2,[1,3],[0,0,4],false],[[1,20]],false]]]]])
const __program_isNativeRecipe=/* @__PURE__ */ freezeProgram([["value","&&","===","typeof","object","!==","in","$$type","NativeRecipeType"],[20,[[23,[5,1,[5,1,[5,1,[5,2,[6,3,[1,0]],[0,0,4]],[5,5,[1,0],[0,1,null]]],[5,6,[0,0,7],[1,0]]],[5,2,[2,[1,0],[0,0,7],false],[1,8]]]]]]])
const __program_isNativeComponentRecipeExtension=/* @__PURE__ */ freezeProgram([["value","&&","===","typeof","object","!==","in","$$type","NativeComponentRecipeExtensionType"],[20,[[23,[5,1,[5,1,[5,1,[5,2,[6,3,[1,0]],[0,0,4]],[5,5,[1,0],[0,1,null]]],[5,6,[0,0,7],[1,0]]],[5,2,[2,[1,0],[0,0,7],false],[1,8]]]]]]])
const __program_isNativeComponentRecipe=/* @__PURE__ */ freezeProgram([["value","&&","===","typeof","object","!==","in","$$type","NativeComponentRecipeType"],[20,[[23,[5,1,[5,1,[5,1,[5,2,[6,3,[1,0]],[0,0,4]],[5,5,[1,0],[0,1,null]]],[5,6,[0,0,7],[1,0]]],[5,2,[2,[1,0],[0,0,7],false],[1,8]]]]]]])
const __program_isNativeSprinklesLookupPlan=/* @__PURE__ */ freezeProgram([["value","&&","===","typeof","object","!==","in","$$type","NativeSprinklesLookupPlanType"],[20,[[23,[5,1,[5,1,[5,1,[5,2,[6,3,[1,0]],[0,0,4]],[5,5,[1,0],[0,1,null]]],[5,6,[0,0,7],[1,0]]],[5,2,[2,[1,0],[0,0,7],false],[1,8]]]]]]])
const __program_isNestedStyleMap=/* @__PURE__ */ freezeProgram([["value","||","!==","typeof","object","===","Array","isArray","isNativeStyleMap","entries","Object","&&",">","length","every","key","entry","isStructuredNativeValue","undefined","!","isThemeTokenReferenceCandidate"],[20,[[25,[5,1,[5,1,[5,2,[6,3,[1,0]],[0,0,4]],[5,5,[1,0],[0,1,null]]],[3,[2,[1,6],[0,0,7],false],[[1,0]],false]],[23,[0,1,false]],null],[25,[3,[1,8],[[1,0]],false],[23,[0,1,true]],null],[21,[[[0,9],[3,[2,[1,10],[0,0,9],false],[[1,0]],false]]]],[23,[5,11,[5,12,[2,[1,9],[0,0,13],false],[0,1,0]],[3,[2,[1,9],[0,0,14],false],[[10,[[[1,[[[0,15],null,false],[[0,16],null,false]]],null,false]],[20,[[25,[3,[1,17],[[1,15],[1,16]],false],[23,[0,1,false]],null],[23,[5,1,[5,1,[5,1,[5,5,[1,16],[1,18]],[5,5,[1,16],[0,1,null]]],[5,5,[1,16],[0,1,false]]],[5,11,[5,5,[6,3,[1,16]],[0,0,4]],[6,19,[3,[1,20],[[1,16]],false]]]]]]],true]],false]]]]]])
const __program_isStructuredNativeValue=/* @__PURE__ */ freezeProgram([["key","value","Array","isArray","NATIVE_ARRAY_VALUE_PROPS","has","||","!==","typeof","object","===","isThemeTokenReferenceCandidate","color","endsWith","Color","&&","shadowOffset","textShadowOffset","in","width","height","__getValue","function"],[20,[[25,[3,[2,[1,2],[0,0,3],false],[[1,1]],false],[23,[3,[2,[1,4],[0,0,5],false],[[1,0]],false]],null],[25,[5,6,[5,6,[5,7,[6,8,[1,1]],[0,0,9]],[5,10,[1,1],[0,1,null]]],[3,[1,11],[[1,1]],false]],[23,[0,1,false]],null],[25,[5,6,[5,10,[1,0],[0,0,12]],[3,[2,[1,0],[0,0,13],false],[[0,0,14]],false]],[23,[0,1,true]],null],[25,[5,15,[5,15,[5,6,[5,10,[1,0],[0,0,16]],[5,10,[1,0],[0,0,17]]],[5,18,[0,0,19],[1,1]]],[5,18,[0,0,20],[1,1]]],[23,[0,1,true]],null],[23,[5,15,[5,18,[0,0,21],[1,1]],[5,10,[6,8,[2,[1,1],[0,0,21],false]],[0,0,22]]]]]]])
const __program_resolveTokenValue=/* @__PURE__ */ freezeProgram([["varName","theme","token","var(",")","&&","isThemeTokenContract","contract","!","isThemeTokenOwnedByContract","Error","formatNativeStylesDiagnostic","NativeStylesDiagnosticCode","TokenThemeTokenContractMismatch","Theme token \"","\" does not belong to the active domain contract. Use the token reference exported by that contract or keep the legacy reference on a legacy ThemeProvider.","Object","prototype","hasOwnProperty","call","tokens","MissingThemeToken","\" is missing from the active native theme"],[20,[[21,[[[0,2],[12,3,[[[1,0],4]]]]]],[25,[5,5,[3,[1,6],[[2,[1,1],[0,0,7],false]],false],[6,8,[3,[1,9],[[2,[1,1],[0,0,7],false],[1,2]],false]]],[20,[[24,[4,[1,10],[[3,[1,11],[[2,[1,12],[0,0,13],false],[12,14,[[[1,0],15]]]],false]]]]]],null],[25,[6,8,[3,[2,[2,[2,[1,16],[0,0,17],false],[0,0,18],false],[0,0,19],false],[[2,[1,1],[0,0,20],false],[1,0]],false]],[20,[[24,[4,[1,10],[[3,[1,11],[[2,[1,12],[0,0,21],false],[12,14,[[[1,0],22]]]],false]]]]]],null],[23,[2,[2,[1,1],[0,0,20],false],[1,0],false]]]]])
const __program_materializeTokenThemeScope=/* @__PURE__ */ freezeProgram([["contract","baseTheme","layers","tokens","context","TOKEN_THEME_SCOPE_PRECEDENCE","layer","get","!==","undefined","applyTokenThemeLayer","resolving","Set","resolvePath","path","reference","getThemeTokenAtPath","!","isRegisteredThemeVar","Error","formatNativeStylesDiagnostic","NativeStylesDiagnosticCode","TokenThemeScopeInvalid","Token theme scope target \"","join",".","\" is not a registered token.","metadata","getThemeTokenMetadata","alias","getThemeTokenAliasForContract","===","value","varName","Complete token theme snapshot is missing \"","\".","key","pathKey","has","TokenAliasCycle","Token alias cycle detected while resolving scoped snapshot at \"","add","targetReference","targetPath","target","fallback","Complete token theme snapshot is missing alias target \"","\" for \"","delete","=","values","collectTokenThemeSnapshot"],[20,[[21,[[[0,3],[9,[[1,[2,[1,1],[0,0,3],false]]]]]]],[26,[0,4],[1,5],[20,[[21,[[[0,6],[3,[2,[1,2],[0,0,7],false],[[1,4]],false]]]],[25,[5,8,[1,6],[1,9]],[22,[3,[1,10],[[1,0],[1,0],[1,6],[8,[]],[1,4],[1,3]],false]],null]]]],[21,[[[0,11],[4,[1,12],[]]]]],[21,[[[0,13],[10,[[[0,14],null,false]],[20,[[21,[[[0,15],[3,[1,16],[[1,0],[1,14]],false]]]],[25,[6,17,[3,[1,18],[[1,15]],false]],[20,[[24,[4,[1,19],[[3,[1,20],[[2,[1,21],[0,0,22],false],[12,23,[[[3,[2,[1,14],[0,0,24],false],[[0,0,25]],false],26]]]],false]]]]]],null],[21,[[[0,27],[3,[1,28],[[1,15]],false]]]],[21,[[[0,29],[3,[1,30],[[1,0],[1,15]],false]]]],[25,[5,31,[1,29],[1,9]],[20,[[21,[[[0,32],[2,[1,3],[2,[1,27],[0,0,33],false],false]]]],[25,[5,31,[1,32],[1,9]],[20,[[24,[4,[1,19],[[3,[1,20],[[2,[1,21],[0,0,22],false],[12,34,[[[3,[2,[1,14],[0,0,24],false],[[0,0,25]],false],35]]]],false]]]]]],null],[23,[1,32]]]],null],[21,[[[0,36],[3,[1,37],[[1,14]],false]]]],[25,[3,[2,[1,11],[0,0,38],false],[[1,36]],false],[20,[[24,[4,[1,19],[[3,[1,20],[[2,[1,21],[0,0,39],false],[12,40,[[[3,[2,[1,14],[0,0,24],false],[[0,0,25]],false],35]]]],false]]]]]],null],[22,[3,[2,[1,11],[0,0,41],false],[[1,36]],false]],[21,[[[0,42],[3,[1,16],[[1,0],[2,[1,29],[0,0,43],false]],false]]]],[21,[[[0,44],[7,[3,[1,18],[[1,42]],false],[3,[1,13],[[2,[1,29],[0,0,43],false]],false],[2,[1,29],[0,0,45],false]]]]],[25,[5,31,[1,44],[1,9]],[20,[[24,[4,[1,19],[[3,[1,20],[[2,[1,21],[0,0,22],false],[12,46,[[[3,[2,[2,[1,29],[0,0,43],false],[0,0,24],false],[[0,0,25]],false],47],[[3,[2,[1,14],[0,0,24],false],[[0,0,25]],false],35]]]],false]]]]]],null],[22,[3,[2,[1,11],[0,0,48],false],[[1,36]],false]],[22,[5,49,[2,[1,3],[2,[1,27],[0,0,33],false],false],[1,44]]],[23,[1,44]]]],true]]]],[21,[[[0,50],[9,[]]]]],[22,[3,[1,51],[[1,0],[1,0],[8,[]],[1,50],[1,13]],false]],[23,[9,[[0,[0,0,0],[1,0]],[0,[0,0,3],[1,3]],[0,[0,0,50],[1,50]]]]]]]])
const __program_applyTokenThemeLayer=/* @__PURE__ */ freezeProgram([["rootContract","contract","layer","path","context","tokens","!","isRecord","Error","formatNativeStylesDiagnostic","NativeStylesDiagnosticCode","TokenThemeScopeInvalid","Token theme "," scope at \"","||","join",".","<root>","\" must be a nested record.","key","Object","keys","contractValue","nextPath","===","undefined","Unknown token theme "," scope value \"","\".","value","isRegisteredThemeVar","alias","getThemeTokenAliasForContract","!==","TokenAliasOverride","\" is derived from an alias and cannot be overridden.","&&","typeof","string","number","\" must be a string or number.","domain","getThemeTokenDomainForContract","isValidScopedTokenValue","\" does not satisfy the ","kind"," token domain.","=","getThemeTokenMetadata","varName","applyTokenThemeLayer","Invalid token contract at \""],[20,[[25,[6,6,[3,[1,7],[[1,2]],false]],[20,[[24,[4,[1,8],[[3,[1,9],[[2,[1,10],[0,0,11],false],[12,12,[[[1,4],13],[[5,14,[3,[2,[1,3],[0,0,15],false],[[0,0,16]],false],[0,0,17]],18]]]],false]]]]]],null],[26,[0,19],[3,[2,[1,20],[0,0,21],false],[[1,2]],false],[20,[[21,[[[0,22],[2,[1,1],[1,19],false]]]],[21,[[[0,23],[8,[[11,[1,3]],[1,19]]]]]],[25,[5,24,[1,22],[1,25]],[20,[[24,[4,[1,8],[[3,[1,9],[[2,[1,10],[0,0,11],false],[12,26,[[[1,4],27],[[3,[2,[1,23],[0,0,15],false],[[0,0,16]],false],28]]]],false]]]]]],null],[21,[[[0,29],[2,[1,2],[1,19],false]]]],[25,[3,[1,30],[[1,22]],false],[20,[[21,[[[0,31],[3,[1,32],[[1,0],[1,22]],false]]]],[25,[5,33,[1,31],[1,25]],[20,[[24,[4,[1,8],[[3,[1,9],[[2,[1,10],[0,0,34],false],[12,12,[[[1,4],27],[[3,[2,[1,23],[0,0,15],false],[[0,0,16]],false],35]]]],false]]]]]],null],[25,[5,36,[5,33,[6,37,[1,29]],[0,0,38]],[5,33,[6,37,[1,29]],[0,0,39]]],[20,[[24,[4,[1,8],[[3,[1,9],[[2,[1,10],[0,0,11],false],[12,12,[[[1,4],27],[[3,[2,[1,23],[0,0,15],false],[[0,0,16]],false],40]]]],false]]]]]],null],[21,[[[0,41],[3,[1,42],[[1,0],[1,22]],false]]]],[25,[5,36,[5,33,[1,41],[1,25]],[6,6,[3,[1,43],[[1,41],[1,29]],false]]],[20,[[24,[4,[1,8],[[3,[1,9],[[2,[1,10],[0,0,11],false],[12,12,[[[1,4],27],[[3,[2,[1,23],[0,0,15],false],[[0,0,16]],false],44],[[2,[1,41],[0,0,45],false],46]]]],false]]]]]],null],[22,[5,47,[2,[1,5],[2,[3,[1,48],[[1,22]],false],[0,0,49],false],false],[1,29]]]]],[25,[3,[1,7],[[1,22]],false],[20,[[22,[3,[1,50],[[1,0],[1,22],[1,29],[1,23],[1,4],[1,5]],false]]]],[20,[[24,[4,[1,8],[[3,[1,9],[[2,[1,10],[0,0,11],false],[12,51,[[[3,[2,[1,23],[0,0,15],false],[[0,0,16]],false],28]]]],false]]]]]]]]]]]]]])
const __program_collectTokenThemeSnapshot=/* @__PURE__ */ freezeProgram([["rootContract","contract","path","output","resolvePath","key","contractValue","Object","entries","nextPath","isRegisteredThemeVar","=","isRecord","nested","collectTokenThemeSnapshot"],[20,[[26,[1,[[[0,5],null,false],[[0,6],null,false]]],[3,[2,[1,7],[0,0,8],false],[[1,1]],false],[20,[[21,[[[0,9],[8,[[11,[1,2]],[1,5]]]]]],[25,[3,[1,10],[[1,6]],false],[20,[[22,[5,11,[2,[1,3],[1,5],false],[3,[1,4],[[1,9]],false]]]]],[25,[3,[1,12],[[1,6]],false],[20,[[21,[[[0,13],[9,[]]]]],[22,[5,11,[2,[1,3],[1,5],false],[1,13]]],[22,[3,[1,14],[[1,0],[1,6],[1,9],[1,13],[1,4]],false]]]],null]]]]]]]])
const __program_getThemeTokenAtPath=/* @__PURE__ */ freezeProgram([["root","path","cursor","segment","||","!","isRecord","Object","prototype","hasOwnProperty","call","undefined","="],[20,[[21,[[[0,2],[1,0]]]],[26,[0,3],[1,1],[20,[[25,[5,4,[6,5,[3,[1,6],[[1,2]],false]],[6,5,[3,[2,[2,[2,[1,7],[0,0,8],false],[0,0,9],false],[0,0,10],false],[[1,2],[1,3]],false]]],[23,[1,11]],null],[22,[5,12,[1,2],[2,[1,2],[1,3],false]]]]]],[23,[1,2]]]]])
const __program_pathKey=/* @__PURE__ */ freezeProgram([["path","map","segment","","length",":","join","/"],[20,[[23,[3,[2,[3,[2,[1,0],[0,0,1],false],[[10,[[[0,2],null,false]],[23,[12,3,[[[2,[1,2],[0,0,4],false],5],[[1,2],3]]]],true]],false],[0,0,6],false],[[0,0,7]],false]]]]])
const __program_isRecord=/* @__PURE__ */ freezeProgram([["value","&&","===","typeof","object","!==","!","Array","isArray"],[20,[[23,[5,1,[5,1,[5,2,[6,3,[1,0]],[0,0,4]],[5,5,[1,0],[0,1,null]]],[6,6,[3,[2,[1,7],[0,0,8],false],[[1,0]],false]]]]]]])
const __program_isValidScopedTokenValue=/* @__PURE__ */ freezeProgram([["domain","value","kind","color","&&","===","typeof","string",">","length","allowNegative","auto","number","Number","isFinite","||",">=","pattern","RegExp","^","[+-]?","\\+?","(?:\\d+(?:\\.\\d*)?|\\.\\d+)%$","test","parseFloat","duration","opacity","<=","enum","Array","isArray","values","includes"],[20,[[31,[2,[1,0],[0,0,2],false],[[[0,0,3],[[23,[5,4,[5,5,[6,6,[1,1]],[0,0,7]],[5,8,[2,[1,1],[0,0,9],false],[0,1,0]]]]]],[[0,0,9],[[20,[[21,[[[0,10],[5,5,[2,[1,0],[0,0,10],false],[0,1,true]]]]],[25,[5,5,[1,1],[0,0,11]],[23,[0,1,true]],null],[25,[5,5,[6,6,[1,1]],[0,0,12]],[23,[5,4,[3,[2,[1,13],[0,0,14],false],[[1,1]],false],[5,15,[1,10],[5,16,[1,1],[0,1,0]]]]],null],[21,[[[0,17],[4,[1,18],[[12,19,[[[7,[1,10],[0,0,20],[0,0,21]],22]]]]]]]],[23,[5,4,[3,[2,[1,17],[0,0,23],false],[[1,1]],false],[3,[2,[1,13],[0,0,14],false],[[3,[2,[1,13],[0,0,24],false],[[1,1]],false]],false]]]]]]],[[0,0,25],[[23,[5,4,[5,4,[5,5,[6,6,[1,1]],[0,0,12]],[3,[2,[1,13],[0,0,14],false],[[1,1]],false]],[5,16,[1,1],[0,1,0]]]]]],[[0,0,26],[[23,[5,4,[5,4,[5,4,[5,5,[6,6,[1,1]],[0,0,12]],[3,[2,[1,13],[0,0,14],false],[[1,1]],false]],[5,16,[1,1],[0,1,0]]],[5,27,[1,1],[0,1,1]]]]]],[[0,0,28],[[23,[5,4,[5,4,[5,5,[6,6,[1,1]],[0,0,7]],[3,[2,[1,29],[0,0,30],false],[[2,[1,0],[0,0,31],false]],false]],[3,[2,[2,[1,0],[0,0,31],false],[0,0,32],false],[[1,1]],false]]]]],[null,[[23,[0,1,false]]]]]]]]])
const __program_requireTokenContractKey=/* @__PURE__ */ freezeProgram([["contract","key","getThemeContractIdentityKey","===","undefined","Error","formatNativeStylesDiagnostic","NativeStylesDiagnosticCode","TokenThemeProviderMismatch","TokenThemeProvider and useTokenTheme require a contract created with an explicit stable identity. Use the legacy ThemeProvider for unscoped contracts."],[20,[[21,[[[0,1],[3,[1,2],[[1,0]],false]]]],[25,[5,3,[1,1],[1,4]],[20,[[24,[4,[1,5],[[3,[1,6],[[2,[1,7],[0,0,8],false],[0,0,9]],false]]]]]],null],[23,[1,1]]]]])
const __program_assertTokenThemeCompatibility=/* @__PURE__ */ freezeProgram([["contract","theme","isTokenThemeCompatible","expected","??","getThemeContractIdentityKey","<unidentified>","actual","Error","formatNativeStylesDiagnostic","NativeStylesDiagnosticCode","TokenThemeProviderMismatch","Theme contract ","JSON","stringify"," is incompatible with requested contract ",". Use the theme created from the same stable contract identity and shape."],[20,[[25,[3,[1,2],[[1,0],[1,1]],false],[23,null],null],[21,[[[0,3],[5,4,[3,[1,5],[[1,0]],false],[0,0,6]]]]],[21,[[[0,7],[5,4,[3,[1,5],[[2,[1,1],[0,0,0],false]],false],[0,0,6]]]]],[24,[4,[1,8],[[3,[1,9],[[2,[1,10],[0,0,11],false],[12,12,[[[3,[2,[1,13],[0,0,14],false],[[1,7]],false],15],[[3,[2,[1,13],[0,0,14],false],[[1,3]],false],16]]]],false]]]]]]])
const __program_getCachedResolution=/* @__PURE__ */ freezeProgram([["theme","input","kind","!","isCacheableObject","hit","byInput","themeResolutionCache","get","entries","entry","===","undefined","value"],[20,[[25,[6,3,[3,[1,4],[[1,1]],false]],[23,[9,[[0,[0,0,5],[0,1,false]]]]],null],[21,[[[0,6],[3,[2,[1,7],[0,0,8],false],[[1,0]],false]]]],[21,[[[0,9],[3,[2,[1,6],[0,0,8],true],[[1,1]],false]]]],[21,[[[0,10],[3,[2,[1,9],[0,0,8],true],[[1,2]],false]]]],[23,[7,[5,11,[1,10],[1,12]],[9,[[0,[0,0,5],[0,1,false]]]],[9,[[0,[0,0,5],[0,1,true]],[0,[0,0,13],[2,[1,10],[0,0,13],false]]]]]]]]])
const __program_setCachedResolution=/* @__PURE__ */ freezeProgram([["theme","input","kind","value","!","isCacheableObject","byInput","themeResolutionCache","get","===","undefined","=","WeakMap","set","entries","Map"],[20,[[25,[6,4,[3,[1,5],[[1,1]],false]],[23,null],null],[21,[[[0,6],[3,[2,[1,7],[0,0,8],false],[[1,0]],false]]]],[25,[5,9,[1,6],[1,10]],[20,[[22,[5,11,[1,6],[4,[1,12],[]]]],[22,[3,[2,[1,7],[0,0,13],false],[[1,0],[1,6]],false]]]],null],[21,[[[0,14],[3,[2,[1,6],[0,0,8],false],[[1,1]],false]]]],[25,[5,9,[1,14],[1,10]],[20,[[22,[5,11,[1,14],[4,[1,15],[]]]],[22,[3,[2,[1,6],[0,0,13],false],[[1,1],[1,14]],false]]]],null],[22,[3,[2,[1,14],[0,0,13],false],[[1,2],[9,[[0,[0,0,3],[1,3]]]]],false]]]]])
const __program_isCacheableObject=/* @__PURE__ */ freezeProgram([["value","&&","===","typeof","object","!=="],[20,[[23,[5,1,[5,2,[6,3,[1,0]],[0,0,4]],[5,5,[1,0],[0,1,null]]]]]]])
const __program_sharedRegistry=/* @__PURE__ */ freezeProgram([["key","create","root","globalThis","descriptor","Object","getOwnPropertyDescriptor","&&","!==","undefined","in","value","defineProperty","enumerable","configurable","writable"],[20,[[21,[[[0,2],[1,3]]]],[21,[[[0,4],[3,[2,[1,5],[0,0,6],false],[[1,2],[1,0]],false]]]],[25,[5,7,[5,8,[1,4],[1,9]],[5,10,[0,0,11],[1,4]]],[23,[2,[1,4],[0,0,11],false]],null],[21,[[[0,11],[3,[1,1],[],false]]]],[22,[3,[2,[1,5],[0,0,12],false],[[1,2],[1,0],[9,[[0,[0,0,11],[1,11]],[0,[0,0,13],[0,1,false]],[0,[0,0,14],[0,1,false]],[0,[0,0,15],[0,1,false]]]]],false]],[23,[1,11]]]]])
import {
  createContext,
  createElement,
  type Context,
  type ReactElement,
  type ReactNode,
  use,
  useCallback,
  useLayoutEffect,
  useMemo,
  useState,
  useSyncExternalStore,
} from "react"
import { formatNativeStylesDiagnostic, NativeStylesDiagnosticCode } from "./diagnostics"
import type { ImageStyle, TextStyle, ViewStyle } from "react-native"
import type {
  NativeRecipe,
  NativeRecipeVariantsConfig,
  NativeSprinklesLookupPlan,
  NativeStyle,
  NativeTheme,
} from "./native-style"
import type {NativeComponentRecipeDescriptor} from "./components"
import {
  validateNativeComponentRecipeExtensionDescriptor,
  type NativeComponentRecipeExtensionDescriptor,
} from "./components/extension-contract"
import {validateNativeComponentContract} from "./components/contracts"
import type { NativePrimitiveDomain } from "./compiler/native-capture"
import {
  NativeComponentRecipeContractVersion,
  NativeComponentRecipeExtensionType,
  NativeComponentRecipeExtensionVersion,
  NativeComponentRecipeType,
  NativeComponentRecipeLegacyVersion,
  NativeComponentRecipeVersion,
  NativeRecipeClassType,
  NativeRecipeType,
  NativeSprinklesLookupPlanType,
} from "./native-tags"
import { isNativeStyleMap, markNativeStyleMap } from "./native-style-map"
import {
  getThemeContractIdentityKey,
  getThemeContractShapeSignature,
  getThemeTokenAliasForContract,
  getThemeTokenDomainForContract,
  getThemeTokenMetadata,
  type NativeThemeTokenReference,
  type ThemeVar,
  assertThemeTokenReference,
  isThemeTokenContract,
  isThemeTokenOwnedByContract,
  isRegisteredThemeVar,
  isThemeTokenReferenceCandidate,
} from "./theme-token"
import type {
  TokenThemeContextName,
  TokenThemeLayer,
} from "./tokens/domains"
import {
  createThemeDependencyPlan,
  themeDependencyPathKey,
  type ThemeDependencyPlan,
  type ThemeDependencyPlanEntry,
  type ThemeDependencyPathSegment,
} from "./runtime/theme-dependency-plan"
import {
  createThemeSelectorStore,
  createThemeStore,
  type ThemeSelectorStore,
  type ThemeStore,
} from "./runtime/theme-store"

export {
  resolveRecipeStyle,
  createRecipeResolver,
  resolveComponentRecipeStyles,
  createComponentRecipeResolver,
} from "./runtime/theme-recipe-resolvers"
export type {
  NativeRecipeResolver,
  RecipeResolverOptions,
  RecipeResolverControls,
  BoundedNativeRecipeResolver,
  NativeComponentRecipeResolver,
  ComponentRecipeResolverOptions,
  ComponentRecipeResolverControls,
  BoundedNativeComponentRecipeResolver,
} from "./runtime/theme-recipe-resolvers"
export { createSprinklesResolver } from "./runtime/theme-sprinkles-resolver"
export type {
  NativeSprinklesResolver,
  SprinklesResolverOptions,
  SprinklesResolverControls,
  BoundedNativeSprinklesResolver,
} from "./runtime/theme-sprinkles-resolver"

export type { NativeThemeTokenReference } from "./theme-token"
export type {
  NativeSprinklesLookupPlan,
  NativeSprinklesSelection,
} from "./native-style"
export type {
  ThemeDependencyPlan,
  ThemeDependencyPlanEntry,
  ThemeDependencyPathSegment,
} from "./runtime/theme-dependency-plan"
export { createThemeDependencyPlan } from "./runtime/theme-dependency-plan"
export type {
  RecipeCompoundMatcher,
  RecipeResolutionInput,
  RecipeResolutionPlan,
  RecipeResolutionVariant,
  RecipeResolverCacheStats,
} from "./runtime/recipe-resolution-plan"
export {
  createComponentRecipeResolutionPlan,
  resolveComponentRecipeResolutionPlan,
} from "./runtime/component-recipe-resolution-plan"
export type {
  ComponentRecipeCompoundMatcher,
  ComponentRecipeInvalidVariantReporter,
  ComponentRecipeResolutionPlan,
  ComponentRecipeResolutionVariant,
} from "./runtime/component-recipe-resolution-plan"
export type {
  NativeSprinklesResolutionPlan,
  NativeSprinklesResolutionSelection,
} from "./runtime/sprinkles-resolution-plan"
export {
  createNativeMapValueFn,
  createNativeNormalizeValueFn,
  createNativeConditionResolver,
  createNativeConditionStore,
  defaultNativeConditionSnapshot,
  mapNativeConditionValueToBranches,
  nativeConditionSnapshotKey,
  NATIVE_CONDITION_BREAKPOINTS,
  NATIVE_RESPONSIVE_CONDITION_MATCHERS,
  NATIVE_RESPONSIVE_CONDITION_NAMES,
  normalizeNativeConditionInput,
  useNativeConditionSnapshot,
} from "./conditions"
export {
  NativeExpressionEvaluationError,
  createNativeExpressionRuntime,
  evaluateNativeExpression,
  foldNativeExpression,
} from "./expressions"
export type {
  NativeExpressionEvaluationErrorCode,
  NativeExpressionEvaluationState,
  NativeExpressionRuntime,
  NativeExpressionRuntimeStats,
} from "./expressions"
export type {
  NativeConditionDefinitions,
  NativeConditionBranch,
  NativeConditionInput,
  NativeConditionMatcher,
  NativeConditionNameList,
  NativeConditionSnapshot,
  NativeConditionSource,
  NativeConditionStore,
  NativeConditionStoreOptions,
  NativeConditionStoreStats,
  NativeConditionValueMapper,
  NativeContrastPreference,
  NativeConditionalRecord,
  NativeConditionalTuple,
  NativeConditionalValue,
  NativeMapValueFn,
  NativeNormalizedConditionalValue,
  NativeNormalizeValueFn,
  NativeDirection,
  NativeFontScaleBucket,
  NativeHeightBucket,
  NativeMotionPreference,
  NativeOrientation,
  NativePlatform,
  NativeWidthBucket,
} from "./conditions"
export {
  createThemeTokenReference,
  isThemeTokenReference,
  NativeThemeTokenReferenceType,
} from "./theme-token"

type NativeThemeContextValue = NativeTheme<Record<string, unknown>>
type NativeThemeStore = ThemeStore<NativeThemeContextValue>
type ThemeProviderProps<TContract extends Record<string, unknown>> = {
  readonly children?: ReactNode
  readonly theme: NativeTheme<TContract>
}
type TokenThemeScopeState = {
  readonly baseTheme: NativeTheme<Record<string, unknown>>
  readonly layers: ReadonlyMap<TokenThemeContextName, unknown>
  readonly theme: NativeTheme<Record<string, unknown>>
  readonly store: NativeThemeStore
}
type TokenThemeContextValue = ReadonlyMap<string, TokenThemeScopeState>
const ThemeStoreContext: Context<NativeThemeStore | null> = sharedRegistry(
  Symbol.for("crumbs.css.theme-store-context.v1"),
  () => createContext<NativeThemeStore | null>(null),
)
const TokenThemeContext: Context<TokenThemeContextValue | null> = sharedRegistry(
  Symbol.for("crumbs.css.token-theme-context.v2"),
  () => createContext<TokenThemeContextValue | null>(null),
)
type ThemeResolutionCacheKind = "tokens" | "styles" | "recipe" | "component-recipe" | "component-recipe-extension"
type ThemeResolutionCacheEntry = {
  readonly value: unknown
}
type ThemeResolutionCacheByInput = Map<ThemeResolutionCacheKind, ThemeResolutionCacheEntry>
const themeResolutionCache = sharedRegistry(
  Symbol.for("crumbs.css.theme-resolution-cache.v1"),
  () => new WeakMap<object, WeakMap<object, ThemeResolutionCacheByInput>>(),
)

function useThemeStore(theme: NativeThemeContextValue): NativeThemeStore {
  const [store] = useState(() => createThemeStore(theme))
  useLayoutEffect(() => {
    store.setSnapshot(theme)
  }, [store, theme])
  return store
}

function useThemeStoreSelector<TSelected>(
  store: NativeThemeStore,
  selector: (theme: NativeThemeContextValue) => TSelected,
): TSelected {
  const selectedStore = useMemo<ThemeSelectorStore<TSelected>>(
    () => createThemeSelectorStore(store, selector),
    [selector, store],
  )
  return useSyncExternalStore(
    selectedStore.subscribe,
    selectedStore.getSnapshot,
    selectedStore.getSnapshot,
  )
}

const identityThemeSelector = (theme: NativeThemeContextValue): NativeThemeContextValue => theme

export function ThemeProvider<TContract extends Record<string, unknown>>({
  children,
  theme,
}: ThemeProviderProps<TContract>): ReactElement {
  const store = useThemeStore(theme as NativeThemeContextValue)
  return createElement(
    ThemeStoreContext.Provider,
    {value: store},
    children,
  )
}

export function useTheme<TContract extends Record<string, unknown>>(): NativeTheme<TContract> {
  const store = use(ThemeStoreContext)
  if (store === null) {
    throw new Error("useTheme must be used within a ThemeProvider from @opsydyn/crumbs-css/theme")
  }
  return useThemeStoreSelector(store, identityThemeSelector) as NativeTheme<TContract>
}

export function useThemeSelector<TSelected>(
  selector: (theme: NativeTheme<Record<string, unknown>>) => TSelected,
): TSelected {
  const store = use(ThemeStoreContext)
  if (store === null) {
    throw new Error("useThemeSelector must be used within a ThemeProvider from @opsydyn/crumbs-css/theme")
  }
  return useThemeStoreSelector(store, selector)
}

export type TokenThemeProviderProps<TContract extends Record<string, unknown>> = {
  readonly children?: ReactNode
  readonly contract: TContract
  readonly theme: NativeTheme<TContract>
}

/**
 * A provider keyed by the contract's stable public identity. The context map
 * is shared through a global symbol so duplicate package copies in one app
 * observe the same provider rather than creating isolated React contexts.
 */
export function TokenThemeProvider<TContract extends Record<string, unknown>>({
  children,
  contract,
  theme,
}: TokenThemeProviderProps<TContract>): ReactElement {
  const key = requireTokenContractKey(contract)
  assertTokenThemeCompatibility(contract, theme)
  const store = useThemeStore(theme as NativeThemeContextValue)
  const parent = use(TokenThemeContext)
  const value = useMemo(() => {
    const next = new Map(parent ?? [])
    const baseTheme = theme as NativeTheme<Record<string, unknown>>
    next.set(key, {baseTheme, layers: new Map(), store, theme: baseTheme})
    return next
  }, [key, parent, store, theme])
  return createElement(
    ThemeStoreContext.Provider,
    {value: store},
    createElement(TokenThemeContext.Provider, {value}, children),
  )
}

/** Read a theme only when its contract identity and shape are both compatible. */
export function useTokenTheme<TContract extends Record<string, unknown>>(
  contract: TContract,
): NativeTheme<TContract> {
  const key = requireTokenContractKey(contract)
  const themes = use(TokenThemeContext)
  const state = themes?.get(key)
  if (state === undefined) {
    throw new Error(formatNativeStylesDiagnostic(
      NativeStylesDiagnosticCode.TokenThemeProviderMismatch,
      `No TokenThemeProvider is active for contract ${JSON.stringify(key)}. Mount TokenThemeProvider with the same identified contract before calling useTokenTheme.`,
    ))
  }
  const theme = useThemeStoreSelector(state.store, identityThemeSelector)
  assertTokenThemeCompatibility(contract, theme)
  return theme as NativeTheme<TContract>
}

export type TokenThemeScopeProviderProps<TContract extends Record<string, unknown>> = {
  readonly children?: ReactNode
  readonly contract: TContract
  readonly context: TokenThemeContextName
  readonly values: TokenThemeLayer<TContract>
}

/**
 * Add one independent brand, mode, or density layer to the nearest complete
 * token theme. Layers compose by fixed axis precedence, so provider nesting
 * order cannot change which axis wins when the same token is overridden.
 */
export function TokenThemeScopeProvider<TContract extends Record<string, unknown>>({
  children,
  contract,
  context,
  values,
}: TokenThemeScopeProviderProps<TContract>): ReactElement {
  const key = requireTokenContractKey(contract)
  if (!(TOKEN_THEME_SCOPE_PRECEDENCE as ReadonlyArray<string>).includes(context)) {
    throw new Error(formatNativeStylesDiagnostic(
      NativeStylesDiagnosticCode.TokenThemeScopeInvalid,
      `Unknown token theme context "${String(context)}". Supported contexts: ${TOKEN_THEME_SCOPE_PRECEDENCE.join(", ")}.`,
    ))
  }
  const parent = use(TokenThemeContext)
  const parentState = parent?.get(key)
  if (parentState === undefined) {
    throw new Error(formatNativeStylesDiagnostic(
      NativeStylesDiagnosticCode.TokenThemeScopeProviderMismatch,
      `No TokenThemeProvider is active for contract ${JSON.stringify(key)}. Mount a complete TokenThemeProvider before adding a ${context} scope.`,
    ))
  }
  assertTokenThemeCompatibility(contract, parentState.theme)
  const scopedTheme = useMemo(() => {
    const layers = new Map(parentState.layers)
    layers.set(context, values)
    return materializeTokenThemeScope(
      contract as Record<string, unknown>,
      parentState.baseTheme,
      layers,
    )
  }, [context, contract, parentState, values])
  const store = useThemeStore(scopedTheme)
  const state = useMemo(() => {
    const layers = new Map(parentState.layers)
    layers.set(context, values)
    return {
      baseTheme: parentState.baseTheme,
      layers,
      store,
      theme: scopedTheme,
    } satisfies TokenThemeScopeState
  }, [context, parentState, scopedTheme, store, values])
  const nextContext = useMemo(() => {
    const next = new Map(parent ?? [])
    next.set(key, state)
    return next
  }, [key, parent, state])
  return createElement(
    ThemeStoreContext.Provider,
    {value: store},
    createElement(TokenThemeContext.Provider, {value: nextContext}, children),
  )
}

export function isTokenThemeCompatible<TContract extends object>(
  contract: TContract,
  theme: NativeTheme<Record<string, unknown>>,
): boolean {
  const contractKey = getThemeContractIdentityKey(contract)
  const themeKey = getThemeContractIdentityKey(theme.contract)
  const contractSignature = getThemeContractShapeSignature(contract)
  const themeSignature = getThemeContractShapeSignature(theme.contract)
  return contractKey !== undefined && contractKey === themeKey &&
    contractSignature !== undefined && contractSignature === themeSignature
}

type NativePrimitiveStyle = ImageStyle | TextStyle | ViewStyle
type TokenizedNativeStyle<TStyle> = {
  readonly [K in keyof TStyle]?: TStyle[K] | NativeThemeTokenReference
}
type TokenizedNativePrimitiveStyle = TokenizedNativeStyle<ImageStyle> |
  TokenizedNativeStyle<TextStyle> | TokenizedNativeStyle<ViewStyle>
type RecursiveStyleLeaf<TInput> = [Extract<TInput, NativePrimitiveStyle>] extends [never]
  ? NativeStyle : Extract<TInput, NativePrimitiveStyle>
type ResolvedNativeStyleInput<TInput, TSeen = never> = TInput extends false | null | undefined
  ? undefined
  : TInput extends NativeComponentRecipeDescriptor | NativeComponentRecipeExtensionDescriptor
    ? TInput
  : TInput extends NativePrimitiveStyle
    ? TInput
    : TInput extends ReadonlyArray<infer TEntry>
      ? TInput extends TSeen
        ? RecursiveStyleLeaf<TEntry>
        : ResolvedNativeStyleInput<TEntry, TSeen | TInput>
      : NativeStyle

export function useThemedStyle<TInput>(style: TInput): ResolvedNativeStyleInput<TInput> | undefined {
  const selector = useCallback(
    (theme: NativeTheme<Record<string, unknown>>) => resolveThemeTokens(style, theme),
    [style],
  )
  return useThemeSelector(selector)
}

export type ResolvedThemeStyles<TStyles extends Readonly<Record<string, unknown>>> = {
  readonly [K in keyof TStyles]: TStyles[K] extends NativeComponentRecipeDescriptor | NativeComponentRecipeExtensionDescriptor
    ? TStyles[K]
    : TStyles[K] extends NativeRecipe<infer TVariants>
    ? NativeRecipe<TVariants>
    : TStyles[K] extends NativeSprinklesLookupPlan<
      infer TPrimitives extends NativePrimitiveDomain,
      infer TProperties extends object,
      infer TShorthands extends Readonly<Record<string, readonly string[]>>
    >
      ? NativeSprinklesLookupPlan<TPrimitives, TProperties, TShorthands>
    : TStyles[K] extends NativePrimitiveStyle
      ? TStyles[K] | undefined
      : TStyles[K] extends TokenizedNativePrimitiveStyle
        ? NativeStyle | undefined
        : TStyles[K] extends Readonly<Record<string, unknown>>
          ? { readonly [V in keyof TStyles[K]]: ResolvedNativeStyleInput<TStyles[K][V]> | undefined }
          : ResolvedNativeStyleInput<TStyles[K]> | undefined
}

export function useThemedStyles<TStyles extends Readonly<Record<string, unknown>>>(
  styles: TStyles,
): ResolvedThemeStyles<TStyles> {
  const selector = useCallback(
    (theme: NativeTheme<Record<string, unknown>>) => resolveThemeStyles(styles, theme),
    [styles],
  )
  return useThemeSelector(selector)
}

export function resolveThemeStyles<TStyles extends Readonly<Record<string, unknown>>>(
  styles: TStyles,
  theme: NativeTheme<Record<string, unknown>>,
): ResolvedThemeStyles<TStyles> {return runProgram(__program_resolveThemeStyles,{"styles":styles,"theme":theme},name=>{switch(name){case "getCachedResolution":return getCachedResolution;case "Object":return Object;case "resolveStyleExport":return resolveStyleExport;case "setCachedResolution":return setCachedResolution}throw new ReferenceError(name+' is not defined')}) as any}

export type ThemeDependencyResolutionMetrics = {
  readonly recomputations: number
  readonly notifications: number
  readonly changedTokens: ReadonlyArray<string>
}

export type ThemeDependencyResolution<TStyles extends Readonly<Record<string, unknown>>> = {
  readonly value: ResolvedThemeStyles<TStyles>
  readonly metrics: ThemeDependencyResolutionMetrics
}

export type ThemeDependencyResolver<TStyles extends Readonly<Record<string, unknown>>> = {
  readonly resolve: (
    theme: NativeTheme<Record<string, unknown>>,
  ) => ThemeDependencyResolution<TStyles>
}

/**
 * Resolves only the exported paths named by a compiler dependency plan. The
 * receipt's notification count is the number of output paths whose resolved
 * value changed; it is an invalidation signal for a future subscription layer,
 * not a claim about React renders.
 */
export function createThemeDependencyResolver<TStyles extends Readonly<Record<string, unknown>>>(
  styles: TStyles,
  plan: ThemeDependencyPlan,
): ThemeDependencyResolver<TStyles> {return runProgram(__program_createThemeDependencyResolver,{"styles":styles,"plan":plan},name=>{switch(name){case "TypeError":return TypeError;case "createThemeDependencyPlan":return createThemeDependencyPlan;case "Map":return Map;case "undefined":return undefined;case "themeTokenChanged":return themeTokenChanged;case "uniquePlanEntries":return uniquePlanEntries;case "readThemeDependencyPath":return readThemeDependencyPath;case "resolveThemeTokens":return resolveThemeTokens;case "equivalentResolvedValue":return equivalentResolvedValue;case "setThemeDependencyPath":return setThemeDependencyPath;case "Object":return Object}throw new ReferenceError(name+' is not defined')}) as any}

function themeTokenChanged(
  previous: NativeTheme<Record<string, unknown>>,
  next: NativeTheme<Record<string, unknown>>,
  token: string,
): boolean {return runProgram(__program_themeTokenChanged,{"previous":previous,"next":next,"token":token},name=>{switch(name){case "Object":return Object}throw new ReferenceError(name+' is not defined')}) as any}

function uniquePlanEntries(entries: ReadonlyArray<ThemeDependencyPlanEntry>): ReadonlyArray<ThemeDependencyPlanEntry> {return runProgram(__program_uniquePlanEntries,{"entries":entries},name=>{switch(name){case "Map":return Map;case "themeDependencyPathKey":return themeDependencyPathKey}throw new ReferenceError(name+' is not defined')}) as any}

function readThemeDependencyPath(
  root: unknown,
  path: ReadonlyArray<ThemeDependencyPathSegment>,
): {readonly value: unknown} {return runProgram(__program_readThemeDependencyPath,{"root":root,"path":path},name=>{switch(name){case "Object":return Object;case "TypeError":return TypeError;case "formatThemeDependencyPath":return formatThemeDependencyPath}throw new ReferenceError(name+' is not defined')}) as any}

function setThemeDependencyPath<T>(
  root: T,
  path: ReadonlyArray<ThemeDependencyPathSegment>,
  value: unknown,
): T {return runProgram(__program_setThemeDependencyPath,{"root":root,"path":path,"value":value},name=>{switch(name){case "cloneThemeDependencyContainer":return cloneThemeDependencyContainer}throw new ReferenceError(name+' is not defined')}) as any}

function cloneThemeDependencyContainer(value: unknown): Record<PropertyKey, unknown> | unknown[] {return runProgram(__program_cloneThemeDependencyContainer,{"value":value},name=>{switch(name){case "Array":return Array;case "Object":return Object;case "TypeError":return TypeError}throw new ReferenceError(name+' is not defined')}) as any}

function equivalentResolvedValue(left: unknown, right: unknown): boolean {return runProgram(__program_equivalentResolvedValue,{"left":left,"right":right},name=>{switch(name){case "Object":return Object;case "Array":return Array;case "Reflect":return Reflect}throw new ReferenceError(name+' is not defined')}) as any}

function formatThemeDependencyPath(path: ReadonlyArray<ThemeDependencyPathSegment>): string {return runProgram(__program_formatThemeDependencyPath,{"path":path},name=>{switch(name){}throw new ReferenceError(name+' is not defined')}) as any}

export function resolveThemeTokens<TInput>(
  style: TInput,
  theme: NativeTheme<Record<string, unknown>>,
): ResolvedNativeStyleInput<TInput> | undefined {return runProgram(__program_resolveThemeTokens,{"style":style,"theme":theme},name=>{switch(name){case "getCachedResolution":return getCachedResolution;case "isNativeComponentRecipe":return isNativeComponentRecipe;case "resolveComponentRecipeThemeTokens":return resolveComponentRecipeThemeTokens;case "setCachedResolution":return setCachedResolution;case "isNativeComponentRecipeExtension":return isNativeComponentRecipeExtension;case "resolveComponentRecipeExtensionThemeTokens":return resolveComponentRecipeExtensionThemeTokens;case "flattenStyle":return flattenStyle;case "undefined":return undefined;case "Object":return Object;case "Array":return Array;case "isThemeTokenReferenceCandidate":return isThemeTokenReferenceCandidate;case "assertThemeTokenReference":return assertThemeTokenReference;case "resolveTokenValue":return resolveTokenValue}throw new ReferenceError(name+' is not defined')}) as any}

function flattenStyle(style: unknown): Record<string, unknown> | undefined {return runProgram(__program_flattenStyle,{"style":style},name=>{switch(name){case "undefined":return undefined;case "Array":return Array;case "flattenStyle":return flattenStyle;case "Object":return Object}throw new ReferenceError(name+' is not defined')}) as any}

function resolveStyleExport(
  style: unknown,
  theme: NativeTheme<Record<string, unknown>>,
):
  | NativeRecipe<NativeRecipeVariantsConfig>
  | NativeComponentRecipeDescriptor
  | NativeSprinklesLookupPlan
  | NativeStyle
  | Readonly<Record<string, NativeStyle | undefined>>
  | undefined {return runProgram(__program_resolveStyleExport,{"style":style,"theme":theme},name=>{switch(name){case "isNativeComponentRecipe":return isNativeComponentRecipe;case "resolveComponentRecipeThemeTokens":return resolveComponentRecipeThemeTokens;case "isNativeRecipe":return isNativeRecipe;case "resolveRecipeThemeTokens":return resolveRecipeThemeTokens;case "isNativeSprinklesLookupPlan":return isNativeSprinklesLookupPlan;case "resolveSprinklesThemeTokens":return resolveSprinklesThemeTokens;case "isNestedStyleMap":return isNestedStyleMap;case "Object":return Object;case "resolveThemeTokens":return resolveThemeTokens;case "isNativeStyleMap":return isNativeStyleMap;case "markNativeStyleMap":return markNativeStyleMap}throw new ReferenceError(name+' is not defined')}) as any}

function resolveSprinklesThemeTokens(
  plan: NativeSprinklesLookupPlan,
  theme: NativeTheme<Record<string, unknown>>,
): NativeSprinklesLookupPlan {return runProgram(__program_resolveSprinklesThemeTokens,{"plan":plan,"theme":theme},name=>{switch(name){case "Object":return Object;case "resolveThemeTokens":return resolveThemeTokens}throw new ReferenceError(name+' is not defined')}) as any}

function resolveRecipeThemeTokens<TVariants extends NativeRecipeVariantsConfig>(
  recipe: NativeRecipe<TVariants>,
  theme: NativeTheme<Record<string, unknown>>,
): NativeRecipe<TVariants> {return runProgram(__program_resolveRecipeThemeTokens,{"recipe":recipe,"theme":theme},name=>{switch(name){case "getCachedResolution":return getCachedResolution;case "undefined":return undefined;case "Object":return Object;case "resolveThemeTokens":return resolveThemeTokens;case "setCachedResolution":return setCachedResolution;case "NativeRecipeType":return NativeRecipeType}throw new ReferenceError(name+' is not defined')}) as any}

function resolveComponentRecipeThemeTokens<TRecipe extends NativeComponentRecipeDescriptor>(
  recipe: TRecipe,
  theme: NativeTheme<Record<string, unknown>>,
): TRecipe {return runProgram(__program_resolveComponentRecipeThemeTokens,{"recipe":recipe,"theme":theme},name=>{switch(name){case "getCachedResolution":return getCachedResolution;case "NativeComponentRecipeLegacyVersion":return NativeComponentRecipeLegacyVersion;case "NativeComponentRecipeVersion":return NativeComponentRecipeVersion;case "NativeComponentRecipeContractVersion":return NativeComponentRecipeContractVersion;case "TypeError":return TypeError;case "String":return String;case "undefined":return undefined;case "Object":return Object;case "validateNativeComponentContract":return validateNativeComponentContract;case "resolveComponentSlotStyles":return resolveComponentSlotStyles;case "JSON":return JSON;case "setCachedResolution":return setCachedResolution;case "freezeComponentSlotStyles":return freezeComponentSlotStyles;case "cloneAndFreezeComponentStyle":return cloneAndFreezeComponentStyle;case "NativeComponentRecipeType":return NativeComponentRecipeType}throw new ReferenceError(name+' is not defined')}) as any}

function resolveComponentRecipeExtensionThemeTokens<TExtension extends NativeComponentRecipeExtensionDescriptor>(
  extension: TExtension,
  theme: NativeTheme<Record<string, unknown>>,
): TExtension {return runProgram(__program_resolveComponentRecipeExtensionThemeTokens,{"extension":extension,"theme":theme},name=>{switch(name){case "getCachedResolution":return getCachedResolution;case "NativeComponentRecipeExtensionVersion":return NativeComponentRecipeExtensionVersion;case "TypeError":return TypeError;case "String":return String;case "validateNativeComponentRecipeExtensionDescriptor":return validateNativeComponentRecipeExtensionDescriptor;case "Object":return Object;case "resolveComponentSlotStyles":return resolveComponentSlotStyles;case "JSON":return JSON;case "setCachedResolution":return setCachedResolution;case "cloneAndFreezeComponentStyle":return cloneAndFreezeComponentStyle;case "freezeComponentSlotStyles":return freezeComponentSlotStyles}throw new ReferenceError(name+' is not defined')}) as any}

function resolveComponentSlotStyles(
  styles: unknown,
  theme: NativeTheme<Record<string, unknown>>,
  context: string,
  markChanged: () => void,
): Readonly<Record<string, unknown>> {return runProgram(__program_resolveComponentSlotStyles,{"styles":styles,"theme":theme,"context":context,"markChanged":markChanged},name=>{switch(name){case "assertComponentThemeRecord":return assertComponentThemeRecord;case "Object":return Object;case "resolveThemeTokens":return resolveThemeTokens}throw new ReferenceError(name+' is not defined')}) as any}

function assertComponentThemeRecord(
  value: unknown,
  context: string,
): asserts value is Readonly<Record<string, unknown>> {return runProgram(__program_assertComponentThemeRecord,{"value":value,"context":context},name=>{switch(name){case "Array":return Array;case "TypeError":return TypeError;case "Object":return Object}throw new ReferenceError(name+' is not defined')}) as any}

function freezeComponentSlotStyles(
  styles: Readonly<Record<string, unknown>>,
): Readonly<Record<string, unknown>> {return runProgram(__program_freezeComponentSlotStyles,{"styles":styles},name=>{switch(name){case "Object":return Object;case "cloneAndFreezeComponentStyle":return cloneAndFreezeComponentStyle}throw new ReferenceError(name+' is not defined')}) as any}

function cloneAndFreezeComponentStyle(value: unknown): unknown {return runProgram(__program_cloneAndFreezeComponentStyle,{"value":value},name=>{switch(name){case "Array":return Array;case "Object":return Object;case "cloneAndFreezeComponentStyle":return cloneAndFreezeComponentStyle;case "NativeRecipeClassType":return NativeRecipeClassType;case "Reflect":return Reflect;case "undefined":return undefined;case "TypeError":return TypeError}throw new ReferenceError(name+' is not defined')}) as any}

function isNativeRecipe(value: unknown): value is NativeRecipe<NativeRecipeVariantsConfig> {return runProgram(__program_isNativeRecipe,{"value":value},name=>{switch(name){case "NativeRecipeType":return NativeRecipeType}throw new ReferenceError(name+' is not defined')}) as any}

function isNativeComponentRecipeExtension(value: unknown): value is NativeComponentRecipeExtensionDescriptor {return runProgram(__program_isNativeComponentRecipeExtension,{"value":value},name=>{switch(name){case "NativeComponentRecipeExtensionType":return NativeComponentRecipeExtensionType}throw new ReferenceError(name+' is not defined')}) as any}

function isNativeComponentRecipe(value: unknown): value is NativeComponentRecipeDescriptor {return runProgram(__program_isNativeComponentRecipe,{"value":value},name=>{switch(name){case "NativeComponentRecipeType":return NativeComponentRecipeType}throw new ReferenceError(name+' is not defined')}) as any}

function isNativeSprinklesLookupPlan(value: unknown): value is NativeSprinklesLookupPlan {return runProgram(__program_isNativeSprinklesLookupPlan,{"value":value},name=>{switch(name){case "NativeSprinklesLookupPlanType":return NativeSprinklesLookupPlanType}throw new ReferenceError(name+' is not defined')}) as any}

function isNestedStyleMap(value: unknown): value is Readonly<Record<string, unknown>> {return runProgram(__program_isNestedStyleMap,{"value":value},name=>{switch(name){case "Array":return Array;case "isNativeStyleMap":return isNativeStyleMap;case "Object":return Object;case "isStructuredNativeValue":return isStructuredNativeValue;case "undefined":return undefined;case "isThemeTokenReferenceCandidate":return isThemeTokenReferenceCandidate}throw new ReferenceError(name+' is not defined')}) as any}

const NATIVE_ARRAY_VALUE_PROPS = new Set([
  "transform", "transformOrigin", "transformMatrix", "fontVariant", "filter", "boxShadow",
  "experimental_backgroundImage", "experimental_backgroundSize",
  "experimental_backgroundPosition", "experimental_backgroundRepeat",
])

function isStructuredNativeValue(key: string, value: unknown): boolean {return runProgram(__program_isStructuredNativeValue,{"key":key,"value":value},name=>{switch(name){case "Array":return Array;case "NATIVE_ARRAY_VALUE_PROPS":return NATIVE_ARRAY_VALUE_PROPS;case "isThemeTokenReferenceCandidate":return isThemeTokenReferenceCandidate}throw new ReferenceError(name+' is not defined')}) as any}

function resolveTokenValue(varName: string, theme: NativeTheme<Record<string, unknown>>): unknown {return runProgram(__program_resolveTokenValue,{"varName":varName,"theme":theme},name=>{switch(name){case "isThemeTokenContract":return isThemeTokenContract;case "isThemeTokenOwnedByContract":return isThemeTokenOwnedByContract;case "Error":return Error;case "formatNativeStylesDiagnostic":return formatNativeStylesDiagnostic;case "NativeStylesDiagnosticCode":return NativeStylesDiagnosticCode;case "Object":return Object}throw new ReferenceError(name+' is not defined')}) as any}

const TOKEN_THEME_SCOPE_PRECEDENCE: ReadonlyArray<TokenThemeContextName> = [
  "brand",
  "mode",
  "density",
]

function materializeTokenThemeScope(
  contract: Record<string, unknown>,
  baseTheme: NativeTheme<Record<string, unknown>>,
  layers: ReadonlyMap<TokenThemeContextName, unknown>,
): NativeTheme<Record<string, unknown>> {return runProgram(__program_materializeTokenThemeScope,{"contract":contract,"baseTheme":baseTheme,"layers":layers},name=>{switch(name){case "TOKEN_THEME_SCOPE_PRECEDENCE":return TOKEN_THEME_SCOPE_PRECEDENCE;case "undefined":return undefined;case "applyTokenThemeLayer":return applyTokenThemeLayer;case "Set":return Set;case "getThemeTokenAtPath":return getThemeTokenAtPath;case "isRegisteredThemeVar":return isRegisteredThemeVar;case "Error":return Error;case "formatNativeStylesDiagnostic":return formatNativeStylesDiagnostic;case "NativeStylesDiagnosticCode":return NativeStylesDiagnosticCode;case "getThemeTokenMetadata":return getThemeTokenMetadata;case "getThemeTokenAliasForContract":return getThemeTokenAliasForContract;case "pathKey":return pathKey;case "collectTokenThemeSnapshot":return collectTokenThemeSnapshot}throw new ReferenceError(name+' is not defined')}) as any}

function applyTokenThemeLayer(
  rootContract: Record<string, unknown>,
  contract: Record<string, unknown>,
  layer: unknown,
  path: ReadonlyArray<string>,
  context: TokenThemeContextName,
  tokens: Record<string, string | number>,
): void {return runProgram(__program_applyTokenThemeLayer,{"rootContract":rootContract,"contract":contract,"layer":layer,"path":path,"context":context,"tokens":tokens},name=>{switch(name){case "isRecord":return isRecord;case "Error":return Error;case "formatNativeStylesDiagnostic":return formatNativeStylesDiagnostic;case "NativeStylesDiagnosticCode":return NativeStylesDiagnosticCode;case "Object":return Object;case "undefined":return undefined;case "isRegisteredThemeVar":return isRegisteredThemeVar;case "getThemeTokenAliasForContract":return getThemeTokenAliasForContract;case "getThemeTokenDomainForContract":return getThemeTokenDomainForContract;case "isValidScopedTokenValue":return isValidScopedTokenValue;case "getThemeTokenMetadata":return getThemeTokenMetadata;case "applyTokenThemeLayer":return applyTokenThemeLayer}throw new ReferenceError(name+' is not defined')}) as any}

function collectTokenThemeSnapshot(
  rootContract: Record<string, unknown>,
  contract: Record<string, unknown>,
  path: ReadonlyArray<string>,
  output: Record<string, unknown>,
  resolvePath: (path: ReadonlyArray<string>) => string | number,
): void {return runProgram(__program_collectTokenThemeSnapshot,{"rootContract":rootContract,"contract":contract,"path":path,"output":output,"resolvePath":resolvePath},name=>{switch(name){case "Object":return Object;case "isRegisteredThemeVar":return isRegisteredThemeVar;case "isRecord":return isRecord;case "collectTokenThemeSnapshot":return collectTokenThemeSnapshot}throw new ReferenceError(name+' is not defined')}) as any}

function getThemeTokenAtPath(root: Record<string, unknown>, path: ReadonlyArray<string>): unknown {return runProgram(__program_getThemeTokenAtPath,{"root":root,"path":path},name=>{switch(name){case "isRecord":return isRecord;case "Object":return Object;case "undefined":return undefined}throw new ReferenceError(name+' is not defined')}) as any}

function pathKey(path: ReadonlyArray<string>): string {return runProgram(__program_pathKey,{"path":path},name=>{switch(name){}throw new ReferenceError(name+' is not defined')}) as any}

function isRecord(value: unknown): value is Record<string, unknown> {return runProgram(__program_isRecord,{"value":value},name=>{switch(name){case "Array":return Array}throw new ReferenceError(name+' is not defined')}) as any}

function isValidScopedTokenValue(
  domain: { readonly kind: string; readonly [key: string]: unknown },
  value: string | number,
): boolean {return runProgram(__program_isValidScopedTokenValue,{"domain":domain,"value":value},name=>{switch(name){case "Number":return Number;case "RegExp":return RegExp;case "Array":return Array}throw new ReferenceError(name+' is not defined')}) as any}

function requireTokenContractKey(contract: object): string {return runProgram(__program_requireTokenContractKey,{"contract":contract},name=>{switch(name){case "getThemeContractIdentityKey":return getThemeContractIdentityKey;case "undefined":return undefined;case "Error":return Error;case "formatNativeStylesDiagnostic":return formatNativeStylesDiagnostic;case "NativeStylesDiagnosticCode":return NativeStylesDiagnosticCode}throw new ReferenceError(name+' is not defined')}) as any}

function assertTokenThemeCompatibility(
  contract: object,
  theme: NativeTheme<Record<string, unknown>>,
): void {return runProgram(__program_assertTokenThemeCompatibility,{"contract":contract,"theme":theme},name=>{switch(name){case "isTokenThemeCompatible":return isTokenThemeCompatible;case "getThemeContractIdentityKey":return getThemeContractIdentityKey;case "Error":return Error;case "formatNativeStylesDiagnostic":return formatNativeStylesDiagnostic;case "NativeStylesDiagnosticCode":return NativeStylesDiagnosticCode;case "JSON":return JSON}throw new ReferenceError(name+' is not defined')}) as any}

function getCachedResolution(
  theme: object,
  input: unknown,
  kind: ThemeResolutionCacheKind,
): {readonly hit: false} | {readonly hit: true; readonly value: unknown} {return runProgram(__program_getCachedResolution,{"theme":theme,"input":input,"kind":kind},name=>{switch(name){case "isCacheableObject":return isCacheableObject;case "themeResolutionCache":return themeResolutionCache;case "undefined":return undefined}throw new ReferenceError(name+' is not defined')}) as any}

function setCachedResolution(
  theme: object,
  input: unknown,
  kind: ThemeResolutionCacheKind,
  value: unknown,
): void {return runProgram(__program_setCachedResolution,{"theme":theme,"input":input,"kind":kind,"value":value},name=>{switch(name){case "isCacheableObject":return isCacheableObject;case "themeResolutionCache":return themeResolutionCache;case "undefined":return undefined;case "WeakMap":return WeakMap;case "Map":return Map}throw new ReferenceError(name+' is not defined')}) as any}

function isCacheableObject(value: unknown): value is object {return runProgram(__program_isCacheableObject,{"value":value},name=>{switch(name){}throw new ReferenceError(name+' is not defined')}) as any}

function sharedRegistry<T>(key: symbol, create: () => T): T {return runProgram(__program_sharedRegistry,{"key":key,"create":create},name=>{switch(name){case "globalThis":return globalThis;case "Object":return Object;case "undefined":return undefined}throw new ReferenceError(name+' is not defined')}) as any}
