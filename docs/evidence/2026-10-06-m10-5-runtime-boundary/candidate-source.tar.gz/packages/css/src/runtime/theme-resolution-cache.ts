// Shared state for theme token/style snapshots. Keep the symbols and weak ownership stable.

export type ThemeResolutionCacheKind = "tokens" | "styles" | "recipe" | "component-recipe" | "component-recipe-extension"

export type ThemeResolutionCacheEntry = {
  readonly value: unknown
}

export type ThemeResolutionCacheByInput = Map<ThemeResolutionCacheKind, ThemeResolutionCacheEntry>

export const themeResolutionCache = sharedRegistry(
  Symbol.for("crumbs.css.theme-resolution-cache.v1"),
  () => new WeakMap<object, WeakMap<object, ThemeResolutionCacheByInput>>(),
)

export function getCachedResolution(
  theme: object,
  input: unknown,
  kind: ThemeResolutionCacheKind,
): {readonly hit: false} | {readonly hit: true; readonly value: unknown} {
  if (!isCacheableObject(input)) return {hit: false}
  const byInput = themeResolutionCache.get(theme)
  const entries = byInput?.get(input)
  const entry = entries?.get(kind)
  return entry === undefined ? {hit: false} : {hit: true, value: entry.value}
}

export function setCachedResolution(
  theme: object,
  input: unknown,
  kind: ThemeResolutionCacheKind,
  value: unknown,
): void {
  if (!isCacheableObject(input)) return
  let byInput = themeResolutionCache.get(theme)
  if (byInput === undefined) {
    byInput = new WeakMap<object, ThemeResolutionCacheByInput>()
    themeResolutionCache.set(theme, byInput)
  }
  let entries = byInput.get(input)
  if (entries === undefined) {
    entries = new Map()
    byInput.set(input, entries)
  }
  entries.set(kind, {value})
}

export function isCacheableObject(value: unknown): value is object {
  return typeof value === "object" && value !== null
}

export function sharedRegistry<T>(key: symbol, create: () => T): T {
  const root = globalThis as unknown as Record<PropertyKey, unknown>
  const descriptor = Object.getOwnPropertyDescriptor(root, key)
  if (descriptor !== undefined && "value" in descriptor) return descriptor.value as T
  const value = create()
  Object.defineProperty(root, key, {value, enumerable: false, configurable: false, writable: false})
  return value
}
