import {createContext, createElement, type Context, type ReactElement, type ReactNode, use, useCallback, useLayoutEffect, useMemo, useState, useSyncExternalStore} from "react"
import type {NativeTheme} from "../native-style"
import {sharedRegistry} from "./theme-resolution-cache"
import {resolveThemeStyles, type ResolvedThemeStyles} from "./theme-style-resolution"
import {resolveThemeTokens, type ResolvedNativeStyleInput} from "./theme-token-resolution"
import {createThemeSelectorStore, createThemeStore, type ThemeSelectorStore, type ThemeStore} from "./theme-store"

export type NativeThemeContextValue = NativeTheme<Record<string, unknown>>

export type NativeThemeStore = ThemeStore<NativeThemeContextValue>

type ThemeProviderProps<TContract extends Record<string, unknown>> = {
  readonly children?: ReactNode
  readonly theme: NativeTheme<TContract>
}

export const ThemeStoreContext: Context<NativeThemeStore | null> = sharedRegistry(
  Symbol.for("crumbs.css.theme-store-context.v1"),
  () => createContext<NativeThemeStore | null>(null),
)

export function useThemeStore(theme: NativeThemeContextValue): NativeThemeStore {
  const [store] = useState(() => createThemeStore(theme))
  useLayoutEffect(() => {
    store.setSnapshot(theme)
  }, [store, theme])
  return store
}

export function useThemeStoreSelector<TSelected>(
  store: NativeThemeStore,
  selector: (theme: NativeThemeContextValue) => TSelected,
): TSelected {
  const selectedStore = useMemo<ThemeSelectorStore<TSelected>>(
    () => createThemeSelectorStore(store, selector),
    [selector, store],
  )
  return useSyncExternalStore(
    selectedStore.subscribe,
    selectedStore.getSnapshot,
    selectedStore.getSnapshot,
  )
}

export const identityThemeSelector = (theme: NativeThemeContextValue): NativeThemeContextValue => theme

export function ThemeProvider<TContract extends Record<string, unknown>>({
  children,
  theme,
}: ThemeProviderProps<TContract>): ReactElement {
  const store = useThemeStore(theme as NativeThemeContextValue)
  return createElement(
    ThemeStoreContext.Provider,
    {value: store},
    children,
  )
}

export function useTheme<TContract extends Record<string, unknown>>(): NativeTheme<TContract> {
  const store = use(ThemeStoreContext)
  if (store === null) {
    throw new Error("useTheme must be used within a ThemeProvider from @opsydyn/crumbs-css/theme")
  }
  return useThemeStoreSelector(store, identityThemeSelector) as NativeTheme<TContract>
}

export function useThemeSelector<TSelected>(
  selector: (theme: NativeTheme<Record<string, unknown>>) => TSelected,
): TSelected {
  const store = use(ThemeStoreContext)
  if (store === null) {
    throw new Error("useThemeSelector must be used within a ThemeProvider from @opsydyn/crumbs-css/theme")
  }
  return useThemeStoreSelector(store, selector)
}

export function useThemedStyle<TInput>(style: TInput): ResolvedNativeStyleInput<TInput> | undefined {
  const selector = useCallback(
    (theme: NativeTheme<Record<string, unknown>>) => resolveThemeTokens(style, theme),
    [style],
  )
  return useThemeSelector(selector)
}

export function useThemedStyles<TStyles extends Readonly<Record<string, unknown>>>(
  styles: TStyles,
): ResolvedThemeStyles<TStyles> {
  const selector = useCallback(
    (theme: NativeTheme<Record<string, unknown>>) => resolveThemeStyles(styles, theme),
    [styles],
  )
  return useThemeSelector(selector)
}
