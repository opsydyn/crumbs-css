import type {NativePrimitiveDomain} from "../compiler/native-capture"
import type {NativeComponentRecipeDescriptor} from "../components"
import type {NativeComponentRecipeExtensionDescriptor} from "../components/extension-contract"
import type {NativeRecipe, NativeRecipeVariantsConfig, NativeSprinklesLookupPlan, NativeStyle, NativeTheme} from "../native-style"
import {NativeRecipeType, NativeSprinklesLookupPlanType} from "../native-tags"
import {isNativeStyleMap, markNativeStyleMap} from "../native-style-map"
import {isThemeTokenReferenceCandidate} from "../theme-token"
import {getCachedResolution, setCachedResolution} from "./theme-resolution-cache"
import {resolveThemeTokens, isNativeComponentRecipe, type NativePrimitiveStyle, type TokenizedNativePrimitiveStyle, type ResolvedNativeStyleInput} from "./theme-token-resolution"
import {resolveComponentRecipeThemeTokens} from "./theme-component-tokens"

export type ResolvedThemeStyles<TStyles extends Readonly<Record<string, unknown>>> = {
  readonly [K in keyof TStyles]: TStyles[K] extends NativeComponentRecipeDescriptor | NativeComponentRecipeExtensionDescriptor
    ? TStyles[K]
    : TStyles[K] extends NativeRecipe<infer TVariants>
    ? NativeRecipe<TVariants>
    : TStyles[K] extends NativeSprinklesLookupPlan<
      infer TPrimitives extends NativePrimitiveDomain,
      infer TProperties extends object,
      infer TShorthands extends Readonly<Record<string, readonly string[]>>
    >
      ? NativeSprinklesLookupPlan<TPrimitives, TProperties, TShorthands>
    : TStyles[K] extends NativePrimitiveStyle
      ? TStyles[K] | undefined
      : TStyles[K] extends TokenizedNativePrimitiveStyle
        ? NativeStyle | undefined
        : TStyles[K] extends Readonly<Record<string, unknown>>
          ? { readonly [V in keyof TStyles[K]]: ResolvedNativeStyleInput<TStyles[K][V]> | undefined }
          : ResolvedNativeStyleInput<TStyles[K]> | undefined
}

export function resolveThemeStyles<TStyles extends Readonly<Record<string, unknown>>>(
  styles: TStyles,
  theme: NativeTheme<Record<string, unknown>>,
): ResolvedThemeStyles<TStyles> {
  const cached = getCachedResolution(theme, styles, "styles")
  if (cached.hit) return cached.value as ResolvedThemeStyles<TStyles>

  const resolved = {} as Record<keyof TStyles, unknown>
  let changed = false
  for (const [key, style] of Object.entries(styles)) {
    const next = resolveStyleExport(style, theme)
    resolved[key as keyof TStyles] = next
    if (next !== style) changed = true
  }
  const result = (changed ? resolved : styles) as ResolvedThemeStyles<TStyles>
  setCachedResolution(theme, styles, "styles", result)
  return result
}

function resolveStyleExport(
  style: unknown,
  theme: NativeTheme<Record<string, unknown>>,
):
  | NativeRecipe<NativeRecipeVariantsConfig>
  | NativeComponentRecipeDescriptor
  | NativeSprinklesLookupPlan
  | NativeStyle
  | Readonly<Record<string, NativeStyle | undefined>>
  | undefined {
  if (isNativeComponentRecipe(style)) return resolveComponentRecipeThemeTokens(style, theme, resolveThemeTokens)
  if (isNativeRecipe(style)) return resolveRecipeThemeTokens(style, theme)
  if (isNativeSprinklesLookupPlan(style)) return resolveSprinklesThemeTokens(style, theme)
  if (isNestedStyleMap(style)) {
    const resolved: Record<string, NativeStyle | undefined> = {}
    let changed = false
    for (const [key, value] of Object.entries(style)) {
      const next = resolveThemeTokens(value, theme)
      resolved[key] = next
      if (next !== value) changed = true
    }
    if (!changed) return style
    return isNativeStyleMap(style) ? markNativeStyleMap(resolved) : resolved
  }
  return resolveThemeTokens(style, theme)
}

function resolveSprinklesThemeTokens(
  plan: NativeSprinklesLookupPlan,
  theme: NativeTheme<Record<string, unknown>>,
): NativeSprinklesLookupPlan {
  let changed = false
  const properties: Record<string, Record<string, NativeStyle>> = {}
  for (const [property, scale] of Object.entries(plan.properties)) {
    const resolvedScale: Record<string, NativeStyle> = {}
    for (const [scaleName, style] of Object.entries(scale)) {
      const next = typeof style === "object" && style !== null
        ? resolveThemeTokens(style, theme) ?? style
        : style
      resolvedScale[scaleName] = next as NativeStyle
      if (next !== style) changed = true
    }
    properties[property] = resolvedScale
  }
  if (!changed) return plan
  return Object.freeze({
    ...plan,
    properties: Object.freeze(Object.fromEntries(
      Object.entries(properties).map(([property, scale]) => [property, Object.freeze(scale)]),
    )),
  }) as NativeSprinklesLookupPlan
}

function resolveRecipeThemeTokens<TVariants extends NativeRecipeVariantsConfig>(
  recipe: NativeRecipe<TVariants>,
  theme: NativeTheme<Record<string, unknown>>,
): NativeRecipe<TVariants> {
  const cached = getCachedResolution(theme, recipe, "recipe")
  if (cached.hit) return cached.value as NativeRecipe<TVariants>

  const variants: Record<string, Record<string, NativeStyle | undefined>> = {}
  let changed = recipe.variants === undefined || recipe.defaultVariants === undefined || recipe.compoundVariants === undefined
  for (const [variantName, variantValues] of Object.entries(recipe.variants ?? {})) {
    const resolvedValues: Record<string, NativeStyle | undefined> = {}
    for (const [valueName, style] of Object.entries(variantValues)) {
      const next = resolveThemeTokens(style, theme)
      resolvedValues[valueName] = next
      if (next !== style) changed = true
    }
    variants[variantName] = resolvedValues
  }

  const base = recipe.base === undefined ? undefined : resolveThemeTokens(recipe.base, theme)
  if (base !== recipe.base) changed = true
  const compoundVariants = (recipe.compoundVariants ?? []).map((compoundVariant) => {
    const style = resolveThemeTokens(compoundVariant.style, theme)
    if (style !== compoundVariant.style) changed = true
    return {style, variants: compoundVariant.variants}
  })

  if (!changed) {
    setCachedResolution(theme, recipe, "recipe", recipe)
    return recipe
  }

  const resolved = {
    $$type: NativeRecipeType,
    ...(recipe.$$debugName === undefined ? {} : { $$debugName: recipe.$$debugName }),
    ...(base === undefined ? {} : { base }),
    compoundVariants,
    defaultVariants: recipe.defaultVariants ?? {},
    variants,
  } as NativeRecipe<TVariants>
  setCachedResolution(theme, recipe, "recipe", resolved)
  return resolved
}

function isNativeRecipe(value: unknown): value is NativeRecipe<NativeRecipeVariantsConfig> {
  return (
    typeof value === "object" &&
    value !== null &&
    "$$type" in value &&
    value.$$type === NativeRecipeType
  )
}

function isNativeSprinklesLookupPlan(value: unknown): value is NativeSprinklesLookupPlan {
  return (
    typeof value === "object" &&
    value !== null &&
    "$$type" in value &&
    value.$$type === NativeSprinklesLookupPlanType
  )
}

function isNestedStyleMap(value: unknown): value is Readonly<Record<string, unknown>> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return false
  if (isNativeStyleMap(value)) return true
  const entries = Object.entries(value)
  return entries.length > 0 && entries.every(([key, entry]) => {
    if (isStructuredNativeValue(key, entry)) return false
    return entry === undefined || entry === null || entry === false ||
      (typeof entry === "object" && !isThemeTokenReferenceCandidate(entry))
  })
}

const NATIVE_ARRAY_VALUE_PROPS = new Set([
  "transform", "transformOrigin", "transformMatrix", "fontVariant", "filter", "boxShadow",
  "experimental_backgroundImage", "experimental_backgroundSize",
  "experimental_backgroundPosition", "experimental_backgroundRepeat",
])

function isStructuredNativeValue(key: string, value: unknown): boolean {
  if (Array.isArray(value)) return NATIVE_ARRAY_VALUE_PROPS.has(key)
  if (typeof value !== "object" || value === null || isThemeTokenReferenceCandidate(value)) return false
  if (key === "color" || key.endsWith("Color")) return true
  if ((key === "shadowOffset" || key === "textShadowOffset") && "width" in value && "height" in value) return true
  // Animated nodes are opaque native values; never execute them here.
  return "__getValue" in value && typeof value.__getValue === "function"
}
