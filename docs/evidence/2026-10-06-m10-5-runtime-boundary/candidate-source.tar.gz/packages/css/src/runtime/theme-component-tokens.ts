import type {NativeTheme} from "../native-style"
import type {NativeComponentRecipeDescriptor} from "../components"
import {validateNativeComponentRecipeExtensionDescriptor, type NativeComponentRecipeExtensionDescriptor} from "../components/extension-contract"
import {validateNativeComponentContract} from "../components/contracts"
import {NativeComponentRecipeContractVersion, NativeComponentRecipeExtensionVersion, NativeComponentRecipeLegacyVersion, NativeComponentRecipeType, NativeComponentRecipeVersion, NativeRecipeClassType} from "../native-tags"
import {getCachedResolution, setCachedResolution} from "./theme-resolution-cache"
import type {ResolvedNativeStyleInput} from "./theme-token-resolution"

export type ThemeTokenResolver = <TInput>(style: TInput, theme: NativeTheme<Record<string, unknown>>) => ResolvedNativeStyleInput<TInput> | undefined

export function resolveComponentRecipeThemeTokens<TRecipe extends NativeComponentRecipeDescriptor>(
  recipe: TRecipe,
  theme: NativeTheme<Record<string, unknown>>,
  resolveTokens: ThemeTokenResolver,
): TRecipe {
  const cached = getCachedResolution(theme, recipe, "component-recipe")
  if (cached.hit) return cached.value as TRecipe
  if (recipe.version !== NativeComponentRecipeLegacyVersion && recipe.version !== NativeComponentRecipeVersion &&
    recipe.version !== NativeComponentRecipeContractVersion) {
    throw new TypeError(`Unsupported component recipe version ${String(recipe.version)}`)
  }
  if (recipe.version === NativeComponentRecipeContractVersion) {
    if (recipe.contract === undefined) {
      throw new TypeError("Version 3 component recipes require contract metadata")
    }
    const variantSurface = Object.fromEntries(Object.entries(recipe.variants ?? {}).map(([axis, values]) => [
      axis,
      Object.fromEntries(Object.keys(values).map(value => [value, true])),
    ]))
    validateNativeComponentContract(recipe.contract, {slots: recipe.slots, variants: variantSurface}, recipe.stateVariants)
  } else if (recipe.contract !== undefined) {
    throw new TypeError("Component contract metadata requires component recipe version 3")
  }

  let changed = recipe.variants === undefined || recipe.defaultVariants === undefined ||
    recipe.compoundVariants === undefined
  const base = recipe.base === undefined
    ? undefined
    : resolveComponentSlotStyles(recipe.base, theme, resolveTokens, "base", () => { changed = true })
  const variants: Record<string, Record<string, Readonly<Record<string, unknown>>>> = {}
  for (const [variantName, variantValues] of Object.entries(recipe.variants ?? {})) {
    const resolvedValues: Record<string, Readonly<Record<string, unknown>>> = {}
    for (const [valueName, styles] of Object.entries(variantValues)) {
      resolvedValues[valueName] = resolveComponentSlotStyles(
        styles, theme, resolveTokens, `variant ${JSON.stringify(variantName)} value ${JSON.stringify(valueName)}`,
        () => { changed = true },
      )
    }
    variants[variantName] = Object.freeze(resolvedValues)
  }

  const compoundVariants = (recipe.compoundVariants ?? []).map((compound, index) => Object.freeze({
    variants: Object.freeze({...compound.variants}),
    styles: resolveComponentSlotStyles(
      compound.styles, theme, resolveTokens, `compound variant ${index}`,
      () => { changed = true },
    ),
  }))
  if (!changed) {
    setCachedResolution(theme, recipe, "component-recipe", recipe)
    return recipe
  }

  const frozenVariants = Object.freeze(Object.fromEntries(
    Object.entries(variants).map(([variantName, values]) => [
      variantName,
      Object.freeze(Object.fromEntries(Object.entries(values).map(([valueName, styles]) => [
        valueName,
        freezeComponentSlotStyles(styles),
      ]))),
    ]),
  ))
  const frozenCompounds = Object.freeze(compoundVariants.map((compound) => Object.freeze({
    variants: compound.variants,
    styles: freezeComponentSlotStyles(compound.styles),
  })))
  const stateVariants = recipe.stateVariants === undefined
    ? undefined
    : cloneAndFreezeComponentStyle(recipe.stateVariants)
  const resolved = Object.freeze({
    $$type: NativeComponentRecipeType,
    version: recipe.version,
    ...(recipe.$$debugName === undefined ? {} : {$$debugName: recipe.$$debugName}),
    slots: Object.freeze({...recipe.slots}),
    ...(recipe.contract === undefined ? {} : {contract: recipe.contract}),
    ...(base === undefined ? {} : {base: freezeComponentSlotStyles(base)}),
    variants: frozenVariants,
    defaultVariants: Object.freeze({...recipe.defaultVariants}),
    ...(stateVariants === undefined ? {} : {stateVariants}),
    compoundVariants: frozenCompounds,
  }) as TRecipe
  setCachedResolution(theme, recipe, "component-recipe", resolved)
  return resolved
}

export function resolveComponentRecipeExtensionThemeTokens<TExtension extends NativeComponentRecipeExtensionDescriptor>(
  extension: TExtension,
  theme: NativeTheme<Record<string, unknown>>,
  resolveTokens: ThemeTokenResolver,
): TExtension {
  const cached = getCachedResolution(theme, extension, "component-recipe-extension")
  if (cached.hit) return cached.value as TExtension
  if (extension.version !== NativeComponentRecipeExtensionVersion) {
    throw new TypeError(`Unsupported component recipe extension version ${String(extension.version)}`)
  }
  const normalized = validateNativeComponentRecipeExtensionDescriptor(extension)
  let changed = false
  const variants = Object.fromEntries(Object.entries(normalized.variants).map(([axis, values]) => [
    axis,
    Object.fromEntries(Object.entries(values).map(([value, styles]) => [
      value,
      resolveComponentSlotStyles(styles, theme, resolveTokens, `extension variant ${JSON.stringify(axis)} value ${JSON.stringify(value)}`,
        () => { changed = true }),
    ])),
  ]))
  const compoundVariants = normalized.compoundVariants.map((compound, index) => Object.freeze({
    variants: compound.variants,
    styles: resolveComponentSlotStyles(compound.styles, theme, resolveTokens, `extension compound variant ${index}`,
      () => { changed = true }),
  }))
  const slotOverrides = resolveComponentSlotStyles(normalized.slotOverrides, theme, resolveTokens, "extension slot overrides",
    () => { changed = true })
  if (!changed) {
    setCachedResolution(theme, extension, "component-recipe-extension", extension)
    return extension
  }

  const resolved = Object.freeze({
    ...normalized,
    defaultVariants: cloneAndFreezeComponentStyle(normalized.defaultVariants),
    variants: Object.freeze(Object.fromEntries(Object.entries(variants).map(([axis, values]) => [
      axis,
      Object.freeze(Object.fromEntries(Object.entries(values).map(([value, styles]) => [
        value,
        freezeComponentSlotStyles(styles as Readonly<Record<string, unknown>>),
      ]))),
    ]))),
    compoundVariants: Object.freeze(compoundVariants.map(compound => Object.freeze({
      variants: cloneAndFreezeComponentStyle(compound.variants),
      styles: freezeComponentSlotStyles(compound.styles),
    }))),
    slotOverrides: freezeComponentSlotStyles(slotOverrides),
  }) as TExtension
  setCachedResolution(theme, extension, "component-recipe-extension", resolved)
  return resolved
}

function resolveComponentSlotStyles(
  styles: unknown,
  theme: NativeTheme<Record<string, unknown>>,
  resolveTokens: ThemeTokenResolver,
  context: string,
  markChanged: () => void,
): Readonly<Record<string, unknown>> {
  const entries: Array<readonly [string, unknown]> = []
  assertComponentThemeRecord(styles, `Component recipe ${context} slot styles`)
  for (const [slot, style] of Object.entries(styles)) {
    const next = resolveTokens(style, theme)
    if (next !== style) markChanged()
    entries.push([slot, next ?? style])
  }
  return Object.freeze(Object.fromEntries(entries))
}

function assertComponentThemeRecord(
  value: unknown,
  context: string,
): asserts value is Readonly<Record<string, unknown>> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new TypeError(`${context} must be a record`)
  }
  const prototype = Object.getPrototypeOf(value)
  if (prototype !== Object.prototype && prototype !== null) {
    throw new TypeError(`${context} must be a plain record`)
  }
  for (const descriptor of Object.values(Object.getOwnPropertyDescriptors(value))) {
    if (!("value" in descriptor) || !descriptor.enumerable) {
      throw new TypeError(`${context} must contain enumerable data properties`)
    }
  }
}

function freezeComponentSlotStyles(
  styles: Readonly<Record<string, unknown>>,
): Readonly<Record<string, unknown>> {
  return Object.freeze(Object.fromEntries(Object.entries(styles).map(([slot, style]) => [
    slot,
    cloneAndFreezeComponentStyle(style),
  ])))
}

function cloneAndFreezeComponentStyle(value: unknown): unknown {
  if (Array.isArray(value)) {
    return Object.freeze(value.map((entry) => cloneAndFreezeComponentStyle(entry)))
  }
  if (value === null || typeof value !== "object") return value
  if ("$$type" in value && value.$$type === NativeRecipeClassType &&
    "className" in value && typeof value.className === "string" && Object.isFrozen(value)) {
    return value
  }
  const clone = Object.create(Object.getPrototypeOf(value)) as Record<PropertyKey, unknown>
  for (const key of Reflect.ownKeys(value)) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key)
    if (descriptor === undefined) continue
    if (!("value" in descriptor)) {
      throw new TypeError("Component recipe style values must be plain data records")
    }
    Object.defineProperty(clone, key, {
      ...descriptor,
      value: cloneAndFreezeComponentStyle(descriptor.value),
    })
  }
  return Object.freeze(clone)
}
