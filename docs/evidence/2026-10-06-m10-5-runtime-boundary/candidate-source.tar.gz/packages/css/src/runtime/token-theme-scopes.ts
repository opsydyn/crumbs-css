import {createContext, createElement, type Context, type ReactElement, type ReactNode, use, useMemo} from "react"
import {formatNativeStylesDiagnostic, NativeStylesDiagnosticCode} from "../diagnostics"
import type {NativeTheme} from "../native-style"
import {getThemeContractIdentityKey, getThemeContractShapeSignature, getThemeTokenAliasForContract, getThemeTokenDomainForContract, getThemeTokenMetadata, isRegisteredThemeVar} from "../theme-token"
import type {TokenThemeContextName, TokenThemeLayer} from "../tokens/domains"
import {sharedRegistry} from "./theme-resolution-cache"
import {ThemeStoreContext, identityThemeSelector, useThemeStore, useThemeStoreSelector, type NativeThemeContextValue, type NativeThemeStore} from "./theme-react"

type TokenThemeScopeState = {
  readonly baseTheme: NativeTheme<Record<string, unknown>>
  readonly layers: ReadonlyMap<TokenThemeContextName, unknown>
  readonly theme: NativeTheme<Record<string, unknown>>
  readonly store: NativeThemeStore
}

type TokenThemeContextValue = ReadonlyMap<string, TokenThemeScopeState>

const TokenThemeContext: Context<TokenThemeContextValue | null> = sharedRegistry(
  Symbol.for("crumbs.css.token-theme-context.v2"),
  () => createContext<TokenThemeContextValue | null>(null),
)

export type TokenThemeProviderProps<TContract extends Record<string, unknown>> = {
  readonly children?: ReactNode
  readonly contract: TContract
  readonly theme: NativeTheme<TContract>
}

/**
 * A provider keyed by the contract's stable public identity. The context map
 * is shared through a global symbol so duplicate package copies in one app
 * observe the same provider rather than creating isolated React contexts.
 */
export function TokenThemeProvider<TContract extends Record<string, unknown>>({
  children,
  contract,
  theme,
}: TokenThemeProviderProps<TContract>): ReactElement {
  const key = requireTokenContractKey(contract)
  assertTokenThemeCompatibility(contract, theme)
  const store = useThemeStore(theme as NativeThemeContextValue)
  const parent = use(TokenThemeContext)
  const value = useMemo(() => {
    const next = new Map(parent ?? [])
    const baseTheme = theme as NativeTheme<Record<string, unknown>>
    next.set(key, {baseTheme, layers: new Map(), store, theme: baseTheme})
    return next
  }, [key, parent, store, theme])
  return createElement(
    ThemeStoreContext.Provider,
    {value: store},
    createElement(TokenThemeContext.Provider, {value}, children),
  )
}

/** Read a theme only when its contract identity and shape are both compatible. */
export function useTokenTheme<TContract extends Record<string, unknown>>(
  contract: TContract,
): NativeTheme<TContract> {
  const key = requireTokenContractKey(contract)
  const themes = use(TokenThemeContext)
  const state = themes?.get(key)
  if (state === undefined) {
    throw new Error(formatNativeStylesDiagnostic(
      NativeStylesDiagnosticCode.TokenThemeProviderMismatch,
      `No TokenThemeProvider is active for contract ${JSON.stringify(key)}. Mount TokenThemeProvider with the same identified contract before calling useTokenTheme.`,
    ))
  }
  const theme = useThemeStoreSelector(state.store, identityThemeSelector)
  assertTokenThemeCompatibility(contract, theme)
  return theme as NativeTheme<TContract>
}

export type TokenThemeScopeProviderProps<TContract extends Record<string, unknown>> = {
  readonly children?: ReactNode
  readonly contract: TContract
  readonly context: TokenThemeContextName
  readonly values: TokenThemeLayer<TContract>
}

/**
 * Add one independent brand, mode, or density layer to the nearest complete
 * token theme. Layers compose by fixed axis precedence, so provider nesting
 * order cannot change which axis wins when the same token is overridden.
 */
export function TokenThemeScopeProvider<TContract extends Record<string, unknown>>({
  children,
  contract,
  context,
  values,
}: TokenThemeScopeProviderProps<TContract>): ReactElement {
  const key = requireTokenContractKey(contract)
  if (!(TOKEN_THEME_SCOPE_PRECEDENCE as ReadonlyArray<string>).includes(context)) {
    throw new Error(formatNativeStylesDiagnostic(
      NativeStylesDiagnosticCode.TokenThemeScopeInvalid,
      `Unknown token theme context "${String(context)}". Supported contexts: ${TOKEN_THEME_SCOPE_PRECEDENCE.join(", ")}.`,
    ))
  }
  const parent = use(TokenThemeContext)
  const parentState = parent?.get(key)
  if (parentState === undefined) {
    throw new Error(formatNativeStylesDiagnostic(
      NativeStylesDiagnosticCode.TokenThemeScopeProviderMismatch,
      `No TokenThemeProvider is active for contract ${JSON.stringify(key)}. Mount a complete TokenThemeProvider before adding a ${context} scope.`,
    ))
  }
  assertTokenThemeCompatibility(contract, parentState.theme)
  const scopedTheme = useMemo(() => {
    const layers = new Map(parentState.layers)
    layers.set(context, values)
    return materializeTokenThemeScope(
      contract as Record<string, unknown>,
      parentState.baseTheme,
      layers,
    )
  }, [context, contract, parentState, values])
  const store = useThemeStore(scopedTheme)
  const state = useMemo(() => {
    const layers = new Map(parentState.layers)
    layers.set(context, values)
    return {
      baseTheme: parentState.baseTheme,
      layers,
      store,
      theme: scopedTheme,
    } satisfies TokenThemeScopeState
  }, [context, parentState, scopedTheme, store, values])
  const nextContext = useMemo(() => {
    const next = new Map(parent ?? [])
    next.set(key, state)
    return next
  }, [key, parent, state])
  return createElement(
    ThemeStoreContext.Provider,
    {value: store},
    createElement(TokenThemeContext.Provider, {value: nextContext}, children),
  )
}

export function isTokenThemeCompatible<TContract extends object>(
  contract: TContract,
  theme: NativeTheme<Record<string, unknown>>,
): boolean {
  const contractKey = getThemeContractIdentityKey(contract)
  const themeKey = getThemeContractIdentityKey(theme.contract)
  const contractSignature = getThemeContractShapeSignature(contract)
  const themeSignature = getThemeContractShapeSignature(theme.contract)
  return contractKey !== undefined && contractKey === themeKey &&
    contractSignature !== undefined && contractSignature === themeSignature
}

const TOKEN_THEME_SCOPE_PRECEDENCE: ReadonlyArray<TokenThemeContextName> = [
  "brand",
  "mode",
  "density",
]

function materializeTokenThemeScope(
  contract: Record<string, unknown>,
  baseTheme: NativeTheme<Record<string, unknown>>,
  layers: ReadonlyMap<TokenThemeContextName, unknown>,
): NativeTheme<Record<string, unknown>> {
  const tokens: Record<string, string | number> = {...baseTheme.tokens}
  for (const context of TOKEN_THEME_SCOPE_PRECEDENCE) {
    const layer = layers.get(context)
    if (layer !== undefined) applyTokenThemeLayer(contract, contract, layer, [], context, tokens)
  }

  const resolving = new Set<string>()
  const resolvePath = (path: ReadonlyArray<string>): string | number => {
    const reference = getThemeTokenAtPath(contract, path)
    if (!isRegisteredThemeVar(reference)) {
      throw new Error(formatNativeStylesDiagnostic(
        NativeStylesDiagnosticCode.TokenThemeScopeInvalid,
        `Token theme scope target "${path.join(".")}" is not a registered token.`,
      ))
    }
    const metadata = getThemeTokenMetadata(reference)
    const alias = getThemeTokenAliasForContract(contract, reference)
    if (alias === undefined) {
      const value = tokens[metadata.varName]
      if (value === undefined) {
        throw new Error(formatNativeStylesDiagnostic(
          NativeStylesDiagnosticCode.TokenThemeScopeInvalid,
          `Complete token theme snapshot is missing "${path.join(".")}".`,
        ))
      }
      return value
    }
    const key = pathKey(path)
    if (resolving.has(key)) {
      throw new Error(formatNativeStylesDiagnostic(
        NativeStylesDiagnosticCode.TokenAliasCycle,
        `Token alias cycle detected while resolving scoped snapshot at "${path.join(".")}".`,
      ))
    }
    resolving.add(key)
    const targetReference = getThemeTokenAtPath(contract, alias.targetPath)
    const target = isRegisteredThemeVar(targetReference)
      ? resolvePath(alias.targetPath)
      : alias.fallback
    if (target === undefined) {
      throw new Error(formatNativeStylesDiagnostic(
        NativeStylesDiagnosticCode.TokenThemeScopeInvalid,
        `Complete token theme snapshot is missing alias target "${alias.targetPath.join(".")}" for "${path.join(".")}".`,
      ))
    }
    resolving.delete(key)
    tokens[metadata.varName] = target
    return target
  }

  const values: Record<string, unknown> = {}
  collectTokenThemeSnapshot(contract, contract, [], values, resolvePath)
  return {contract, tokens, values: values as NativeTheme<Record<string, unknown>>["values"]}
}

function applyTokenThemeLayer(
  rootContract: Record<string, unknown>,
  contract: Record<string, unknown>,
  layer: unknown,
  path: ReadonlyArray<string>,
  context: TokenThemeContextName,
  tokens: Record<string, string | number>,
): void {
  if (!isRecord(layer)) {
    throw new Error(formatNativeStylesDiagnostic(
      NativeStylesDiagnosticCode.TokenThemeScopeInvalid,
      `Token theme ${context} scope at "${path.join(".") || "<root>"}" must be a nested record.`,
    ))
  }
  for (const key of Object.keys(layer)) {
    const contractValue = contract[key]
    const nextPath = [...path, key]
    if (contractValue === undefined) {
      throw new Error(formatNativeStylesDiagnostic(
        NativeStylesDiagnosticCode.TokenThemeScopeInvalid,
        `Unknown token theme ${context} scope value "${nextPath.join(".")}".`,
      ))
    }
    const value = layer[key]
    if (isRegisteredThemeVar(contractValue)) {
      const alias = getThemeTokenAliasForContract(rootContract, contractValue)
      if (alias !== undefined) {
        throw new Error(formatNativeStylesDiagnostic(
          NativeStylesDiagnosticCode.TokenAliasOverride,
          `Token theme ${context} scope value "${nextPath.join(".")}" is derived from an alias and cannot be overridden.`,
        ))
      }
      if (typeof value !== "string" && typeof value !== "number") {
        throw new Error(formatNativeStylesDiagnostic(
          NativeStylesDiagnosticCode.TokenThemeScopeInvalid,
          `Token theme ${context} scope value "${nextPath.join(".")}" must be a string or number.`,
        ))
      }
      const domain = getThemeTokenDomainForContract(rootContract, contractValue)
      if (domain !== undefined && !isValidScopedTokenValue(domain, value)) {
        throw new Error(formatNativeStylesDiagnostic(
          NativeStylesDiagnosticCode.TokenThemeScopeInvalid,
          `Token theme ${context} scope value "${nextPath.join(".")}" does not satisfy the ${domain.kind} token domain.`,
        ))
      }
      tokens[getThemeTokenMetadata(contractValue).varName] = value
    } else if (isRecord(contractValue)) {
      applyTokenThemeLayer(rootContract, contractValue, value, nextPath, context, tokens)
    } else {
      throw new Error(formatNativeStylesDiagnostic(
        NativeStylesDiagnosticCode.TokenThemeScopeInvalid,
        `Invalid token contract at "${nextPath.join(".")}".`,
      ))
    }
  }
}

function collectTokenThemeSnapshot(
  rootContract: Record<string, unknown>,
  contract: Record<string, unknown>,
  path: ReadonlyArray<string>,
  output: Record<string, unknown>,
  resolvePath: (path: ReadonlyArray<string>) => string | number,
): void {
  for (const [key, contractValue] of Object.entries(contract)) {
    const nextPath = [...path, key]
    if (isRegisteredThemeVar(contractValue)) {
      output[key] = resolvePath(nextPath)
    } else if (isRecord(contractValue)) {
      const nested: Record<string, unknown> = {}
      output[key] = nested
      collectTokenThemeSnapshot(rootContract, contractValue, nextPath, nested, resolvePath)
    }
  }
}

function getThemeTokenAtPath(root: Record<string, unknown>, path: ReadonlyArray<string>): unknown {
  let cursor: unknown = root
  for (const segment of path) {
    if (!isRecord(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return undefined
    cursor = cursor[segment]
  }
  return cursor
}

function pathKey(path: ReadonlyArray<string>): string {
  return path.map(segment => `${segment.length}:${segment}`).join("/")
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value)
}

function isValidScopedTokenValue(
  domain: { readonly kind: string; readonly [key: string]: unknown },
  value: string | number,
): boolean {
  switch (domain.kind) {
    case "color": return typeof value === "string" && value.length > 0
    case "length": {
      const allowNegative = domain.allowNegative === true
      if (value === "auto") return true
      if (typeof value === "number") return Number.isFinite(value) && (allowNegative || value >= 0)
      const pattern = new RegExp(`^${allowNegative ? "[+-]?" : "\\+?"}(?:\\d+(?:\\.\\d*)?|\\.\\d+)%$`)
      return pattern.test(value) && Number.isFinite(Number.parseFloat(value))
    }
    case "duration": return typeof value === "number" && Number.isFinite(value) && value >= 0
    case "opacity": return typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 1
    case "enum": return typeof value === "string" && Array.isArray(domain.values) && domain.values.includes(value)
    default: return false
  }
}

function requireTokenContractKey(contract: object): string {
  const key = getThemeContractIdentityKey(contract)
  if (key === undefined) {
    throw new Error(formatNativeStylesDiagnostic(
      NativeStylesDiagnosticCode.TokenThemeProviderMismatch,
      "TokenThemeProvider and useTokenTheme require a contract created with an explicit stable identity. Use the legacy ThemeProvider for unscoped contracts.",
    ))
  }
  return key
}

function assertTokenThemeCompatibility(
  contract: object,
  theme: NativeTheme<Record<string, unknown>>,
): void {
  if (isTokenThemeCompatible(contract, theme)) return
  const expected = getThemeContractIdentityKey(contract) ?? "<unidentified>"
  const actual = getThemeContractIdentityKey(theme.contract) ?? "<unidentified>"
  throw new Error(formatNativeStylesDiagnostic(
    NativeStylesDiagnosticCode.TokenThemeProviderMismatch,
    `Theme contract ${JSON.stringify(actual)} is incompatible with requested contract ${JSON.stringify(expected)}. Use the theme created from the same stable contract identity and shape.`,
  ))
}
