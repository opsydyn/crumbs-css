import {formatNativeStylesDiagnostic, NativeStylesDiagnosticCode} from "../diagnostics"
import type {ImageStyle, TextStyle, ViewStyle} from "react-native"
import type {NativeComponentRecipeDescriptor} from "../components"
import type {NativeComponentRecipeExtensionDescriptor} from "../components/extension-contract"
import type {NativeStyle, NativeTheme} from "../native-style"
import {NativeComponentRecipeExtensionType, NativeComponentRecipeType} from "../native-tags"
import {assertThemeTokenReference, getThemeTokenMetadata, isThemeTokenContract, isThemeTokenOwnedByContract, isThemeTokenReferenceCandidate, type NativeThemeTokenReference, type ThemeVar} from "../theme-token"
import {getCachedResolution, setCachedResolution} from "./theme-resolution-cache"
import {resolveComponentRecipeExtensionThemeTokens, resolveComponentRecipeThemeTokens} from "./theme-component-tokens"

export type NativePrimitiveStyle = ImageStyle | TextStyle | ViewStyle

type TokenizedNativeStyle<TStyle> = {
  readonly [K in keyof TStyle]?: TStyle[K] | NativeThemeTokenReference
}

export type TokenizedNativePrimitiveStyle = TokenizedNativeStyle<ImageStyle> |
  TokenizedNativeStyle<TextStyle> | TokenizedNativeStyle<ViewStyle>

type RecursiveStyleLeaf<TInput> = [Extract<TInput, NativePrimitiveStyle>] extends [never]
  ? NativeStyle : Extract<TInput, NativePrimitiveStyle>

export type ResolvedNativeStyleInput<TInput, TSeen = never> = TInput extends false | null | undefined
  ? undefined
  : TInput extends NativeComponentRecipeDescriptor | NativeComponentRecipeExtensionDescriptor
    ? TInput
  : TInput extends NativePrimitiveStyle
    ? TInput
    : TInput extends ReadonlyArray<infer TEntry>
      ? TInput extends TSeen
        ? RecursiveStyleLeaf<TEntry>
        : ResolvedNativeStyleInput<TEntry, TSeen | TInput>
      : NativeStyle

export function resolveThemeTokens<TInput>(
  style: TInput,
  theme: NativeTheme<Record<string, unknown>>,
): ResolvedNativeStyleInput<TInput> | undefined {
  const cached = getCachedResolution(theme, style, "tokens")
  if (cached.hit) return cached.value as ResolvedNativeStyleInput<TInput> | undefined

  if (isNativeComponentRecipe(style)) {
    const resolved = resolveComponentRecipeThemeTokens(style, theme, resolveThemeTokens)
    setCachedResolution(theme, style, "tokens", resolved)
    return resolved as ResolvedNativeStyleInput<TInput>
  }
  if (isNativeComponentRecipeExtension(style)) {
    const resolved = resolveComponentRecipeExtensionThemeTokens(style, theme, resolveThemeTokens)
    setCachedResolution(theme, style, "tokens", resolved)
    return resolved as ResolvedNativeStyleInput<TInput>
  }

  const flattened = flattenStyle(style)
  if (flattened === undefined) {
    setCachedResolution(theme, style, "tokens", undefined)
    return undefined
  }

  const entries = Object.entries(flattened)
  let changed = Array.isArray(style)
  let resolved: Record<string, unknown> | undefined = Array.isArray(style) ? {} : undefined
  for (const [index, entry] of entries.entries()) {
    const [key, value] = entry
    if (isThemeTokenReferenceCandidate(value)) {
      assertThemeTokenReference(value, key)
      if (resolved === undefined) {
        resolved = {}
        for (const [previousKey, previousValue] of entries.slice(0, index)) {
          resolved[previousKey] = previousValue
        }
      }
      resolved[key] = resolveTokenValue(value.varName, theme)
      changed = true
    } else if (resolved !== undefined) resolved[key] = value
  }

  const result = (changed ? resolved ?? {} : style) as ResolvedNativeStyleInput<TInput>
  setCachedResolution(theme, style, "tokens", result)
  return result
}

function flattenStyle(style: unknown): Record<string, unknown> | undefined {
  if (style === null || style === undefined || style === false) return undefined
  if (Array.isArray(style)) {
    const flattened = style.flatMap((item) => {
      const resolved = flattenStyle(item)
      return resolved === undefined ? [] : [resolved]
    })
    if (flattened.length === 0) return undefined
    return Object.assign({}, ...flattened) as Record<string, unknown>
  }
  if (typeof style === "object") return style as Record<string, unknown>
  return undefined
}

function resolveTokenValue(varName: string, theme: NativeTheme<Record<string, unknown>>): unknown {
  const token = `var(${varName})` as ThemeVar
  if (isThemeTokenContract(theme.contract) && !isThemeTokenOwnedByContract(theme.contract, token)) {
    throw new Error(formatNativeStylesDiagnostic(
      NativeStylesDiagnosticCode.TokenThemeTokenContractMismatch,
      `Theme token "${varName}" does not belong to the active domain contract. Use the token reference exported by that contract or keep the legacy reference on a legacy ThemeProvider.`,
    ))
  }
  if (!Object.prototype.hasOwnProperty.call(theme.tokens, varName)) {
    throw new Error(formatNativeStylesDiagnostic(NativeStylesDiagnosticCode.MissingThemeToken,
      `Theme token "${varName}" is missing from the active native theme`))
  }
  return theme.tokens[varName]
}

function isNativeComponentRecipeExtension(value: unknown): value is NativeComponentRecipeExtensionDescriptor {
  return typeof value === "object" && value !== null &&
    "$$type" in value && value.$$type === NativeComponentRecipeExtensionType
}

export function isNativeComponentRecipe(value: unknown): value is NativeComponentRecipeDescriptor {
  return (
    typeof value === "object" &&
    value !== null &&
    "$$type" in value &&
    value.$$type === NativeComponentRecipeType
  )
}
