/**
 * Lean runtime theme surface for common component consumers.
 *
 * The compatibility `@opsydyn/crumbs-css/theme` entrypoint retains token
 * scopes, dependency plans and recipe controls. Keeping those APIs out of
 * this entrypoint lets common theme reads ship a smaller independent graph.
 */

export {createNativeMapValueFn, createNativeNormalizeValueFn, createNativeConditionResolver, createNativeConditionStore, defaultNativeConditionSnapshot, mapNativeConditionValueToBranches, nativeConditionSnapshotKey, NATIVE_CONDITION_BREAKPOINTS, NATIVE_RESPONSIVE_CONDITION_MATCHERS, NATIVE_RESPONSIVE_CONDITION_NAMES, normalizeNativeConditionInput, useNativeConditionSnapshot} from "./conditions"

export {ThemeProvider, useTheme, useThemeSelector, useThemedStyle, useThemedStyles} from "./runtime/theme-react"

export {resolveThemeStyles} from "./runtime/theme-style-resolution"

export {resolveThemeTokens} from "./runtime/theme-token-resolution"

export {createThemeTokenReference, isThemeTokenReference, NativeThemeTokenReferenceType} from "./theme-token"

export type {NativeConditionDefinitions, NativeConditionBranch, NativeConditionInput, NativeConditionMatcher, NativeConditionNameList, NativeConditionSnapshot, NativeConditionSource, NativeConditionStore, NativeConditionStoreOptions, NativeConditionStoreStats, NativeConditionValueMapper, NativeContrastPreference, NativeConditionalRecord, NativeConditionalTuple, NativeConditionalValue, NativeMapValueFn, NativeNormalizedConditionalValue, NativeNormalizeValueFn, NativeDirection, NativeFontScaleBucket, NativeHeightBucket, NativeMotionPreference, NativeOrientation, NativePlatform, NativeWidthBucket} from "./conditions"

export type {NativeThemeTokenReference} from "./theme-token"

export type {ResolvedThemeStyles} from "./runtime/theme-style-resolution"
