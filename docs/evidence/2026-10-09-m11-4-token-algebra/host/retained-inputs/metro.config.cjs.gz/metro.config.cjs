const {getDefaultConfig}=require('expo/metro-config');const {withNativeStyles}=require('@opsydyn/crumbs-css/metro-plugin');module.exports=withNativeStyles(getDefaultConfig(__dirname));
