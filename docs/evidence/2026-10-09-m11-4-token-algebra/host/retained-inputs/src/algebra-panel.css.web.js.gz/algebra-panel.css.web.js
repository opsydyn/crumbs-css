/* @crumbs-native-cache 29611e0627b19e6c753096684038ab22364d3cdda659dbf368cd7811d137d467 */
const _s = {
  "algebra-panel__1xooocy0": {"backgroundColor":"#ffffff","columnGap":6,"opacity":1,"paddingBottom":8,"paddingLeft":8,"paddingRight":8,"paddingTop":8,"rowGap":6},
  "algebra-panel__1xooocy1": {"alignItems":"center","columnGap":6,"flexDirection":"row","flexWrap":"wrap","rowGap":6},
  "algebra-panel__1xooocy2": {"backgroundColor":"#ffffff","borderBottomColor":"#64748b","borderBottomLeftRadius":4,"borderBottomRightRadius":4,"borderBottomWidth":1,"borderLeftColor":"#64748b","borderLeftWidth":1,"borderRightColor":"#64748b","borderRightWidth":1,"borderTopColor":"#64748b","borderTopLeftRadius":4,"borderTopRightRadius":4,"borderTopWidth":1,"minHeight":32,"paddingBottom":6,"paddingLeft":6,"paddingRight":6,"paddingTop":6},
  "algebra-panel__1xooocy3": {"height":40,"width":48},
  "algebra-panel__1xooocy4": {"color":"#111827","fontSize":12},
  "algebra-panel__1xooocy5": {"color":"#111827","fontSize":18,"fontWeight":"700"},
  "algebra-panel__1xooocy6": {"alignSelf":"flex-start","color":"#111827"}
};
export const __crumbsModule = Object.freeze({$$type:"crumbs.css.native-module",version:2,tokens:Object.freeze([]),dependencyPlan:Object.freeze({$$type:"crumbs.css.theme-dependency-plan",version:1,entries:Object.freeze([])}),conditions:Object.freeze([])});
export const control = _s["algebra-panel__1xooocy2"];
export const heading = _s["algebra-panel__1xooocy5"];
export const label = _s["algebra-panel__1xooocy4"];
export const panel = _s["algebra-panel__1xooocy0"];
export const row = _s["algebra-panel__1xooocy1"];
export const sample = _s["algebra-panel__1xooocy6"];
export const swatch = _s["algebra-panel__1xooocy3"];