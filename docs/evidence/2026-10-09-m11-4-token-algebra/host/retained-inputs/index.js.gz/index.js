import {registerRootComponent} from 'expo';import {AlgebraApp} from './src/AlgebraApp';registerRootComponent(AlgebraApp);
