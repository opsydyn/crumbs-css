import { describe, expect, it } from "bun:test"
import { createHash } from "node:crypto"
import { compareTransformReceipts, verifyMarker, verifyProcessReports } from "../test-support/fresh-pipeline-qualification"

const hash = (s: string) => createHash("sha256").update(s).digest("hex")
function receipt() {
  const proof = { kind: "legacy", source: "exports.height = 48", inputs: { "fixture.css.ts": { bytes: 10, imports: [] } }, resolutionIdentity: { cacheable: true, files: [], links: [] }, dependencies: [], context: { compilerKey: "control:style-explanations=0", platform: "ios", dev: true, strictDiagnostics: true, useStyleSheet: true, identOption: "debug" }, entryHash: "entry" }
  const resolutionKey = hash(JSON.stringify({ entryHash: proof.entryHash, inputs: proof.inputs, resolutionIdentity: proof.resolutionIdentity }))
  const marker = hash("crumbs-native-cache-v1\0compiler=control:style-explanations=0\0platform=ios\0dev=1\0strict=1\0styleSheet=1\0ident=debug\0resolution=" + resolutionKey + "\0")
  return { code: `/* @crumbs-native-cache ${marker} */\nexport const height = 48;`, proof, observation: { height: 48 }, maps: [[1, 0, 1, 0]], metadata: { dependencies: [] }, authoredInputs: [{ path: "fixture.css.ts", hash: "entry" }], externalVersions: { esbuild: "0.27.7" }, privateInputs: [{ path: "dist/control.cjs", hash: "a" }], privateInventoryVerified: true }
}
const inputs = { controlRepoRoot: "/control", controlPackageRoot: "/control/package", controlTarball: "/control.tgz", candidateRepoRoot: "/candidate", scratchRoot: "/scratch", floorNode: "/node22" }
describe("fresh pipeline qualification rejects unapproved differences", () => {
  it("accepts an independently checked unchanged control pair", () => {
    expect(verifyMarker(receipt())).toEqual([])
    expect(compareTransformReceipts(receipt(), receipt(), inputs)).toEqual([])
  })
  it("rejects changed native values and undeclared generated statements", () => {
    const changed = receipt(); changed.observation.height = 49
    expect(compareTransformReceipts(receipt(), changed, inputs)).toContain("observation differs")
    changed.code += "\nexport const extra = true;"
    expect(compareTransformReceipts(receipt(), changed, inputs)).toContain("code differs")
  })
  it("rejects map coordinates outside the agreed control result", () => {
    const changed = receipt(); changed.maps[0]![2] = 90
    expect(compareTransformReceipts(receipt(), changed, inputs)).toContain("maps differs")
  })
  it("requires independent marker derivation rather than deleting the line", () => {
    const changed = receipt(); changed.code = changed.code.replace(/[a-f0-9]{64}/, "f".repeat(64))
    expect(verifyMarker(changed)).toContain("cache marker does not match independent derivation")
    expect(compareTransformReceipts(receipt(), changed, inputs).length).toBeGreaterThan(0)
  })
  it("retains authored and external facts while accounting for inventoried private chunks", () => {
    const changed = receipt(); changed.privateInputs = [{ path: "dist/candidate.cjs", hash: "b" }]
    expect(compareTransformReceipts(receipt(), changed, inputs)).toEqual([])
    changed.authoredInputs[0]!.hash = "different"
    expect(compareTransformReceipts(receipt(), changed, inputs)).toContain("authoredInputs differs")
    changed.externalVersions.esbuild = "0.28.2"
    expect(compareTransformReceipts(receipt(), changed, inputs)).toContain("externalVersions differs")
    changed.privateInventoryVerified = false
    expect(compareTransformReceipts(receipt(), changed, inputs)).toContain("candidate private inventory unverified")
  })
  it("rejects missing, duplicate and truncated benchmark processes", () => {
    expect(verifyProcessReports([])).toContain("expected five independent benchmark processes")
    expect(verifyProcessReports(Array.from({ length: 5 }, () => ({ pid: 1, exitCode: 0, report: {} })) ).length).toBeGreaterThan(0)
  })
})
it("compares explicit failed-compilation receipts without treating errors as successful modules",()=>{
 const a={case:"broken",error:{name:"Error",message:"invalid source"},authoredInputs:[{path:"broken.css.ts",hash:"bad"}]}
 expect(compareTransformReceipts(a,a,inputs)).toEqual([])
 expect(compareTransformReceipts(a,{...a,error:{name:"Error",message:"different"}},inputs)).toContain("error differs")
 expect(compareTransformReceipts(a,receipt(),inputs)).toContain("success/error differs")
})
it("permits only file-fallback map coordinates inside independently verified opaque marker spans",()=>{
 const a=receipt(),b=receipt()
 a.maps=[[1,25,1,0]];b.maps=[[1,24,1,0]]
 expect(compareTransformReceipts(a,b,inputs)).toEqual([])
 b.maps=[[2,24,1,0]]
 expect(compareTransformReceipts(a,b,inputs)).toContain("maps differs")
 b.maps=[[1,24,2,0]]
 expect(compareTransformReceipts(a,b,inputs)).toContain("maps differs")
})
