import { expect,it } from "bun:test"
import fc from "fast-check"
import { createNativeIrCompilation } from "../src/compiler/native-ir-compilation"
import { captureScalarIntoNativeIr,lowerScalarBlock,normalizeScalarBlocks,type ScalarDeclarationBlock } from "../src/compiler/native-ir"
import { lowerStructuredBlock,type StructuredDeclarationBlock } from "../src/compiler/structured-ir"
import { markNativeCaptureRule } from "../src/compiler/native-capture"
import { evaluateStyle,type StyleExpression } from "./oracles/native-ir-v1"
const context={packageOwner:"@acme/owner",sourceId:"owned.css.ts",className:"case"}
const marked=(rule:Record<string,unknown>)=>markNativeCaptureRule(rule,["view"])
function error(operation:()=>unknown){try{operation();return null}catch(e){return[e instanceof Error?e.name:typeof e,e instanceof Error?e.message:String(e)]}}
it("owned lowering allocates fresh frozen outputs and preserves signed zero",()=>{
 const owner=createNativeIrCompilation(),block=owner.captureScalar(marked({width:-0}),context).block!
 const a=owner.lowerScalar(block),b=owner.lowerScalar(block)
 expect(a).not.toBe(b);expect(Object.isFrozen(a)).toBe(true);expect(Object.is(a.width,-0)).toBe(true)
 expect(Object.isFrozen(block)).toBe(true);expect(Object.isFrozen(block.declarations)).toBe(true)
 const structured=owner.captureStructured(marked({transform:[{scale:2},{translateX:4}],shadowOffset:{width:2,height:3}}),context).block!
 const first=owner.lowerStructured(structured),second=owner.lowerStructured(structured)
 expect(first).toEqual({transform:[{scale:2},{translateX:4}],shadowOffset:{width:2,height:3}})
 expect(first.transform).not.toBe(second.transform);expect(Object.isFrozen(first.transform)).toBe(true)
 owner.dispose()
})
it("foreign copied frozen and proxy blocks take generic validation with the same inspection order",()=>{
 const owner=createNativeIrCompilation(),captured=owner.captureScalar(marked({width:12}),context).block!
 for(const kind of ["copy","proxy","frozen","other-owner"]){
  const make=(events:string[])=>{
   const base=kind==="other-owner"?createNativeIrCompilation().captureScalar(marked({width:12}),context).block!:structuredClone(captured)
   if(kind==="frozen")Object.freeze(base)
   if(kind==="proxy")return new Proxy(base,{get(target,key,receiver){events.push(String(key));return Reflect.get(target,key,receiver)}})
   const descriptors=Object.getOwnPropertyDescriptors(base)
   return Object.defineProperties({}, {...descriptors,provenance:{get(){events.push("provenance");return base.provenance},enumerable:true}}) as ScalarDeclarationBlock
  }
  const expected:string[]=[],actual:string[]=[]
  expect(owner.lowerScalar(make(actual))).toEqual(lowerScalarBlock(make(expected)))
  expect(actual).toEqual(expected)
 }
 const proxy=new Proxy(captured,{get(target,key,receiver){if(key==="declarations")throw new Error("foreign inspection");return Reflect.get(target,key,receiver)}})
 expect(error(()=>owner.lowerScalar(proxy))).toEqual(error(()=>lowerScalarBlock(proxy)))
 owner.dispose()
})
it("wrong families and normalized compositions receive fresh admission",()=>{
 const owner=createNativeIrCompilation(),a=owner.captureScalar(marked({width:1}),context).block!,b=owner.captureScalar(marked({width:2}),context).block!
 expect(owner.lowerScalar(normalizeScalarBlocks([a,b]))).toEqual({width:2})
 expect(error(()=>owner.lowerStructured(a as unknown as StructuredDeclarationBlock))).toEqual(error(()=>lowerStructuredBlock(a as unknown as StructuredDeclarationBlock)))
 const foreign=Object.freeze({...a,declarations:[]}) as unknown as ScalarDeclarationBlock
 expect(error(()=>owner.lowerScalar(foreign))).toEqual(error(()=>lowerScalarBlock(foreign)))
 owner.dispose()
})
it("compatibility captures register their decoded blocks without changing output",()=>{
 const owner=createNativeIrCompilation(),value=owner.captureCompatibility({width:8,transform:[{scale:2}]},context)
 expect(owner.lowerScalar(value.scalarBlock!)).toEqual({width:8})
 expect(owner.lowerStructured(value.structuredBlock!)).toEqual({transform:[{scale:2}]})
 owner.dispose()
})
it("disposing invalidates this owner without affecting another request",()=>{
 const a=createNativeIrCompilation(),b=createNativeIrCompilation(),block=a.captureScalar(marked({width:1}),context).block!
 a.dispose();a.dispose()
 expect(()=>a.lowerScalar(block)).toThrow(new TypeError("Native IR compilation is disposed"))
 expect(()=>a.captureScalar(marked({width:1}),context)).toThrow("Native IR compilation is disposed")
 expect(b.lowerScalar(block)).toEqual({width:1});b.dispose()
})
it("owned scalar and ordered structured lowering agree with independent semantics over generated values",()=>{
 fc.assert(fc.property(fc.oneof(fc.double({noNaN:true,noDefaultInfinity:true}),fc.constant(-0)),fc.integer({min:-100,max:100}),(value,offset)=>{
  const owner=createNativeIrCompilation(),captured=owner.captureScalar(marked({width:value}),context).block!
  const provenance={sourceId:"owned.css.ts",exportPath:[],propertyPath:["width"],line:1,column:1,origin:"crumbs-native" as const}
  const expression:StyleExpression={_tag:"DeclarationBlock",primitive:"view",declarations:[{_tag:"Declaration",property:"width",value,provenance:{...provenance,originalProperty:"width"}}],provenance}
  const oracle=evaluateStyle(expression,{definitions:[],tokens:{}})
  expect(oracle).toEqual({ok:true,value:{width:value}})
  expect(owner.lowerScalar(captured)).toEqual(oracle.ok?oracle.value:{})
  const structured=owner.captureStructured(marked({transform:[{scale:2},{translateX:offset}]}),context).block!
  expect(owner.lowerStructured(structured)).toEqual({transform:[{scale:2},{translateX:offset}]})
  const token=owner.captureScalar(marked({width:"var(--crumbs-fixture-width)"}),context).block!
  expect(owner.lowerScalar(token)).toEqual(lowerScalarBlock(token))
  const normalized=normalizeScalarBlocks([captured,captureScalarIntoNativeIr(marked({width:3}),context).block!])
  expect(owner.lowerScalar(normalized)).toEqual({width:3})
  owner.dispose()
 }),{seed:1051701,numRuns:200})
})
