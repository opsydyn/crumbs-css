import { describe, expect, it } from "bun:test"
import { consumerFixtures } from "../test-support/consumer-fixtures"
import * as path from "node:path"
import { readFileSync } from "node:fs"
import { runInNewContext } from "node:vm"
import { buildStyleSheetCode, transform, transformCssTsToStyleSheet } from "../src/transformer"

const PKG_ROOT = path.resolve(__dirname, "..")
const FIXTURE = path.resolve(PKG_ROOT, "fixtures/simple.css.ts")
const EXAMPLE_BASIC = path.resolve(PKG_ROOT, "examples/basic.css.ts")
const EXAMPLE_THEMED = path.resolve(PKG_ROOT, "examples/themed.css.ts")
const EXAMPLE_PRESSABLE_VARIANTS = path.resolve(PKG_ROOT, "examples/pressable-variants.css.ts")
const EXAMPLE_TYPED_HELPERS = path.resolve(PKG_ROOT, "examples/typed-helpers.css.ts")
const EXAMPLE_RECIPE = path.resolve(PKG_ROOT, "examples/recipe.css.ts")
const FIXTURE_WITH_DEPS = path.resolve(PKG_ROOT, "fixtures/with-deps.css.ts")
const FIXTURE_COMPOSED = path.resolve(PKG_ROOT, "fixtures/composed.css.ts")
const FIXTURE_WITH_VARS = path.resolve(PKG_ROOT, "fixtures/with-vars.css.ts")
const FIXTURE_THEMED = path.resolve(PKG_ROOT, "fixtures/themed.css.ts")
const FIXTURE_VARIANTS = path.resolve(PKG_ROOT, "fixtures/variants.css.ts")
const FIXTURE_UPSTREAM_TRANSFORMER = path.resolve(PKG_ROOT, "fixtures/upstream-transformer.cjs")
const FIXTURE_UNSUPPORTED_GLOBAL = path.resolve(PKG_ROOT, "fixtures/unsupported-global.css.ts")
const FIXTURE_UNSUPPORTED_KEYFRAMES = path.resolve(
  PKG_ROOT,
  "fixtures/unsupported-keyframes.css.ts",
)
const FIXTURE_UNSUPPORTED_MEDIA = path.resolve(PKG_ROOT, "fixtures/unsupported-media.css.ts")
const FIXTURE_UNSUPPORTED_DECLARATION = path.resolve(
  PKG_ROOT,
  "fixtures/unsupported-declaration.css.ts",
)
const FIXTURE_UNSUPPORTED_SELECTORS = path.resolve(
  PKG_ROOT,
  "fixtures/unsupported-selectors.css.ts",
)
const consumer = consumerFixtures()

function evaluateNativeExports(code: string): Record<string, unknown> {
  const exports: Record<string, unknown> = {}
  runInNewContext(code.replace(/^import .*;$/gm, "").replace(/export const (\w+) =/g, "exports.$1 ="), {
    exports,
    StyleSheet: { create: (styles: unknown) => styles },
  })
  return exports
}

// ---------------------------------------------------------------------------
// Unit tests — pure JS, no VE pipeline, run in bun
// ---------------------------------------------------------------------------

describe("buildStyleSheetCode", () => {
  it("generates StyleSheet.create with the class styles", () => {
    const exportMap = new Map([["title", "title__abc123"]])
    const classStyles = new Map([["title__abc123", { fontSize: 24, color: "#c8aa6e" }]])
    const code = buildStyleSheetCode(exportMap, classStyles)
    expect(code).toContain("StyleSheet.create")
    expect(code).toContain('"title__abc123"')
    expect(code).toContain("24")
  })

  it("re-exports each name pointing at the StyleSheet entry", () => {
    const exportMap = new Map([
      ["container", "container__def456"],
      ["title", "title__abc123"],
    ])
    const classStyles = new Map([
      ["container__def456", { flex: 1 }],
      ["title__abc123", { fontSize: 24 }],
    ])
    const code = buildStyleSheetCode(exportMap, classStyles)
    expect(code).toContain("export const container")
    expect(code).toContain("export const title")
    expect(code).toContain("_s[")
  })

  it("exports undefined for classes with no styles (e.g. at-rule only)", () => {
    const exportMap = new Map([["title", "title__abc123"]])
    const classStyles = new Map<string, Record<string, unknown>>()
    const code = buildStyleSheetCode(exportMap, classStyles)
    expect(code).toContain("export const title = undefined")
  })

  it("includes react-native StyleSheet import", () => {
    const code = buildStyleSheetCode(new Map(), new Map())
    expect(code).toContain(`from "react-native"`)
    expect(code).toContain("StyleSheet")
  })

  it("emits side-effect imports for dep paths", () => {
    const code = buildStyleSheetCode(new Map(), new Map(), ["./tokens.css.ts", "./theme.css.ts"])
    expect(code).toContain(`import "./tokens.css.ts";`)
    expect(code).toContain(`import "./theme.css.ts";`)
  })

  it("emits no dep imports when deps list is empty", () => {
    const code = buildStyleSheetCode(new Map(), new Map(), [])
    expect(code).not.toContain("import ./")
    expect(code).not.toContain('import ".')
  })

  it("can emit plain style objects for React Native Web token resolution", () => {
    const exportMap = new Map([["title", "title__abc123"]])
    const classStyles = new Map([
      ["title__abc123", { fontFamily: { varName: "--crumbs-font-display" } }],
    ])
    const code = buildStyleSheetCode(exportMap, classStyles, [], { useStyleSheet: false })

    expect(code).not.toContain("StyleSheet.create")
    expect(code).not.toContain(`from "react-native"`)
    expect(code).toContain("const _s = {")
    expect(code).toContain("export const title = _s[")
  })
})

describe("Metro transformer", () => {
  it("defaults the explanation sidecar from Metro dev and honors nativeStyles overrides", async () => {
    const transformWithSetting = async (dev: boolean, includeStyleExplanations?: boolean) => {
      const result = await transform({
        upstreamTransformerPath: FIXTURE_UPSTREAM_TRANSFORMER,
        nativeStyles: includeStyleExplanations === undefined ? {} : { includeStyleExplanations },
      }, PKG_ROOT, FIXTURE, readFileSync(FIXTURE), { dev, platform: "web" }) as { readonly code: string }
      return result.code
    }
    const developmentDefault = await transformWithSetting(true)
    const developmentDisabled = await transformWithSetting(true, false)
    const productionDefault = await transformWithSetting(false)
    const productionEnabled = await transformWithSetting(false, true)

    expect(developmentDefault).toContain("export const __crumbsDev")
    expect(developmentDisabled).not.toContain("export const __crumbsDev")
    expect(productionDefault).not.toContain("export const __crumbsDev")
    expect(productionEnabled).toContain("export const __crumbsDev")
    expect(developmentDefault).not.toEqual(developmentDisabled)
  })

  it("uses direct transform dev defaults, explicit overrides, and distinct cache identities", async () => {
    const options = { useStyleSheet: false } as const
    const developmentDefault = await transformCssTsToStyleSheet(FIXTURE, PKG_ROOT, { ...options, dev: true })
    const developmentDisabled = await transformCssTsToStyleSheet(FIXTURE, PKG_ROOT, {
      ...options,
      dev: true,
      includeStyleExplanations: false,
    })
    const productionDefault = await transformCssTsToStyleSheet(FIXTURE, PKG_ROOT, { ...options, dev: false })
    const productionEnabled = await transformCssTsToStyleSheet(FIXTURE, PKG_ROOT, {
      ...options,
      dev: false,
      includeStyleExplanations: true,
    })
    const cacheIdentity = (code: string) => /@crumbs-native-cache ([a-f0-9]+)/u.exec(code)?.[1]

    expect(developmentDefault).toContain("export const __crumbsDev")
    expect(developmentDisabled).not.toContain("export const __crumbsDev")
    expect(productionDefault).not.toContain("export const __crumbsDev")
    expect(productionEnabled).toContain("export const __crumbsDev")
    expect(cacheIdentity(developmentDefault)).not.toBe(cacheIdentity(developmentDisabled))
    expect(cacheIdentity(productionDefault)).not.toBe(cacheIdentity(productionEnabled))
  })

  it("transforms native .css.ts files on web so Storybook never evaluates vanilla-extract authoring code", async () => {
    const result = (await transform(
      { upstreamTransformerPath: FIXTURE_UPSTREAM_TRANSFORMER },
      PKG_ROOT,
      FIXTURE,
      readFileSync(FIXTURE),
      { dev: true, platform: "web" },
    )) as { readonly code: string }

    expect(result.code).not.toContain("StyleSheet.create")
    expect(result.code).toContain("export const container")
    expect(result.code).not.toContain("@vanilla-extract/css")
  })

  it("keeps native platforms on StyleSheet.create output", async () => {
    const result = (await transform(
      { upstreamTransformerPath: FIXTURE_UPSTREAM_TRANSFORMER },
      PKG_ROOT,
      FIXTURE,
      readFileSync(FIXTURE),
      { dev: true, platform: "ios" },
    )) as { readonly code: string; readonly unstable_transformResultKey?: unknown }

    expect(result.code).toContain("StyleSheet.create")
    expect(result.code).toContain("export const container")
    expect(result.code).not.toContain("@vanilla-extract/css")
    expect(result.unstable_transformResultKey).toMatch(/^crumbs:crumbs:[a-f0-9]{40}$/)
  })

  it("transforms package-owned button recipes for web without React Native StyleSheet compilation", async () => {
    const result = (await transform(
      { upstreamTransformerPath: FIXTURE_UPSTREAM_TRANSFORMER },
      consumer.root,
      consumer.button,
      readFileSync(consumer.button),
      { dev: true, platform: "web" },
    )) as { readonly code: string }

    expect(result.code).not.toContain("StyleSheet.create")
    expect(result.code).not.toContain("@vanilla-extract/css")
    expect(result.code).toContain('"$$type": "crumbs.css.recipe"')
    expect(result.code).toContain('"base": _s[')
    expect(result.code).toContain("--crumbs-fixture-font-display")
  })
})

// ---------------------------------------------------------------------------
// Integration tests — call transformCssTsToStyleSheet via Node.js subprocess.
//
// The package entrypoint used by Metro is compiled CommonJS, so these tests
// exercise dist/transformer.cjs in both Node and Bun subprocesses.
// ---------------------------------------------------------------------------

function runNodeTransform(fixturePath: string): string {
  const script = `
    const { transformCssTsToStyleSheet } = require('./dist/transformer.cjs');
    transformCssTsToStyleSheet('${fixturePath}', '${PKG_ROOT}')
      .then(code => process.stdout.write(code))
      .catch(e => { process.stderr.write(e.message); process.exit(1); });
  `
  const result = Bun.spawnSync(["node", "--eval", script], {
    cwd: PKG_ROOT,
    stderr: "pipe",
  })
  if (result.exitCode !== 0) {
    throw new Error(result.stderr.toString())
  }
  return result.stdout.toString()
}

function runBunTransform(fixturePath: string, cwd = PKG_ROOT): string {
  const script = `
    const { transformCssTsToStyleSheet } = require('./dist/transformer.cjs');
    transformCssTsToStyleSheet('${fixturePath}', '${cwd}')
      .then(code => process.stdout.write(code))
      .catch(e => { process.stderr.write(e.stack || e.message); process.exit(1); });
  `
  const result = Bun.spawnSync([process.execPath, "--eval", script], {
    cwd: PKG_ROOT,
    stderr: "pipe",
  })
  if (result.exitCode !== 0) {
    throw new Error(result.stderr.toString())
  }
  return result.stdout.toString()
}

function runBunTransformStrict(fixturePath: string, cwd = PKG_ROOT): string {
  const script = `
    const { transformCssTsToStyleSheet } = require('./dist/transformer.cjs');
    transformCssTsToStyleSheet('${fixturePath}', '${cwd}', { strictDiagnostics: true })
      .then(code => process.stdout.write(code))
      .catch(e => { process.stderr.write(e.stack || e.message); process.exit(1); });
  `
  const result = Bun.spawnSync([process.execPath, "--eval", script], {
    cwd: PKG_ROOT,
    stderr: "pipe",
  })
  if (result.exitCode !== 0) {
    throw new Error(result.stderr.toString())
  }
  return result.stdout.toString()
}


describe("transformCssTsToStyleSheet via Node.js (integration)", () => {
  it("transforms simple.css.ts to StyleSheet code", () => {
    const code = runNodeTransform(FIXTURE)
    expect(code).toContain("StyleSheet.create")
    expect(code).toContain("export const container")
    expect(code).toContain("export const title")
    expect(code).toContain("export const body")
  })

  it("README basic style example compiles", () => {
    const code = runBunTransform(EXAMPLE_BASIC)
    expect(code).toContain("StyleSheet.create")
    expect(code).toContain("export const screen")
    expect(code).toContain("export const title")
  })

  it("README themed style example compiles with native theme tokens", () => {
    const code = runBunTransform(EXAMPLE_THEMED)
    expect(code).toContain("crumbs.css.theme-token")
    expect(code).toContain("--crumbs-color-canvas")
    expect(code).toContain("--crumbs-space-screen")
  })

  it("README pressable variants example compiles to a nested style map", () => {
    const code = runBunTransform(EXAMPLE_PRESSABLE_VARIANTS)
    const button = evaluateNativeExports(code).button as Record<string, { opacity?: number }>
    expect(Object.keys(button)).toEqual(["default", "pressed"])
    expect(button.pressed?.opacity).toBe(0.8)
    expect(code).toContain('"default": _s[')
    expect(code).toContain('"pressed": _s[')
    expect(code).toContain("export const buttonLabel")
  })

  it("README typed native helpers example compiles", () => {
    const code = runBunTransform(EXAMPLE_TYPED_HELPERS)
    expect(code).toContain("export const panel")
    expect(code).toContain("export const title")
    expect(code).toContain("export const crest")
    expect(code).toContain('"resizeMode":"cover"')
    expect(code).toContain("--crumbs-color-canvas")
  })

  it("README recipe example compiles to a native recipe map", () => {
    const code = runBunTransform(EXAMPLE_RECIPE)
    expect(code).toContain("export const button")
    expect(code).toContain('"$$type": "crumbs.css.recipe"')
    expect(code).toContain('"base": _s[')
    expect(code).toContain('"tone"')
    expect(code).toContain('"primary": _s[')
    expect(code).toContain('"compoundVariants"')
    expect(code).toContain('"disabled": true')
    expect(code).toContain("--crumbs-color-accent")
  })

  it("output does not reference vanilla-extract runtime", () => {
    const code = runNodeTransform(FIXTURE)
    expect(code).not.toContain("vanilla-extract")
    expect(code).not.toContain("@vanilla-extract/css")
  })

  it("includes numeric style values from the fixture", () => {
    const code = runNodeTransform(FIXTURE)
    expect(code).toContain("24") // container padding + title fontSize
    expect(code).toContain("8") // title marginBottom
  })

  it("simple.css.ts with no imports emits no dep side-effects", () => {
    const code = runNodeTransform(FIXTURE)
    // No cross-file deps — no side-effect imports should appear
    expect(code).not.toMatch(/import "\.[^"]+";/)
  })

  it("with-deps.css.ts emits tokens.css.ts as a side-effect import for hot reload", () => {
    const code = runNodeTransform(FIXTURE_WITH_DEPS)
    // Metro tracks this import → re-transforms with-deps.css.ts when tokens changes
    expect(code).toContain(`import "./tokens.css.ts"`)
  })

  it("composed.css.ts merges base + extra styles into a single StyleSheet entry", () => {
    const code = runNodeTransform(FIXTURE_COMPOSED)
    // btn composes [base, { fontWeight }] — must NOT be undefined
    expect(code).not.toContain("export const btn = undefined")
    expect(code).toContain("export const btn")
    // Merged styles: base contributes color + fontSize, btn adds fontWeight
    expect(code).toContain('"#c8aa6e"') // base color
    expect(code).toContain('"700"') // btn fontWeight
  })

  it("composed.css.ts non-composed export works normally", () => {
    const code = runNodeTransform(FIXTURE_COMPOSED)
    expect(code).not.toContain("export const title = undefined")
    expect(code).toContain('"fontSize":24')
  })

  it("with-vars.css.ts strips CSS variable values but keeps plain ones", () => {
    const code = runNodeTransform(FIXTURE_WITH_VARS)
    // fontSize: 16 should survive
    expect(code).toContain('"fontSize":16')
    // The CSS var color should NOT appear as a value
    expect(code).not.toContain("var(--")
  })

  it("with-deps.css.ts resolves token values into the StyleSheet", () => {
    const code = runNodeTransform(FIXTURE_WITH_DEPS)
    expect(code).toContain("#c8aa6e") // vars.color.gold inlined
    expect(code).toContain("#0a0a0a") // vars.color.dark inlined
  })

  it("themed.css.ts preserves native theme tokens in the StyleSheet payload", () => {
    const code = runBunTransform(FIXTURE_THEMED)
    expect(code).toContain("crumbs.css.theme-token")
    expect(code).toContain("--crumbs-color-canvas")
    expect(code).toContain("--crumbs-color-text")
    expect(code).toContain("--crumbs-space-md")
    expect(code).not.toContain("export const container = undefined")
    expect(code).not.toContain("packages/native-styles/dist")
    expect(code).not.toContain("/dist/style")
    expect(code).not.toContain("/dist/theme-token")
  })

  it("styleVariants exports a nested StyleSheet map", () => {
    const code = runBunTransform(FIXTURE_VARIANTS)
    const button = evaluateNativeExports(code).button as Record<string, { opacity?: number }>
    expect(Object.keys(button)).toEqual(["default", "pressed"])
    expect(button.default?.opacity).toBe(1)
    expect(button.pressed?.opacity).toBe(0.8)
    expect(code).toContain('"default": _s[')
    expect(code).toContain('"pressed": _s[')
    expect(code).toContain("--crumbs-color-canvas")
    expect(code).toContain("--crumbs-color-text")
  })

  it("rejects @media rules with an actionable native compatibility diagnostic", () => {
    expect(() => runNodeTransform(FIXTURE_UNSUPPORTED_MEDIA)).toThrow(
      "@opsydyn/crumbs-css does not support @media rules in React Native styles",
    )
  })

  it("rejects keyframes with an actionable native compatibility diagnostic", () => {
    expect(() => runNodeTransform(FIXTURE_UNSUPPORTED_KEYFRAMES)).toThrow(
      "@opsydyn/crumbs-css does not support @keyframes rules in React Native styles",
    )
  })

  it("rejects global selectors with an actionable native compatibility diagnostic", () => {
    expect(() => runNodeTransform(FIXTURE_UNSUPPORTED_GLOBAL)).toThrow(
      "@opsydyn/crumbs-css does not support selectors, global styles, or pseudo classes in React Native styles",
    )
  })

  it("rejects selectors with an actionable native compatibility diagnostic", () => {
    expect(() => runNodeTransform(FIXTURE_UNSUPPORTED_SELECTORS)).toThrow(
      "@opsydyn/crumbs-css does not support selectors, global styles, or pseudo classes in React Native styles",
    )
  })

  it("strict diagnostics reject dropped declarations with file and export context", () => {
    expect(() => runBunTransformStrict(FIXTURE_UNSUPPORTED_DECLARATION)).toThrow(
      '@opsydyn/crumbs-css dropped "transition: all 0.3s" while transforming export "link"',
    )
    expect(() => runBunTransformStrict(FIXTURE_UNSUPPORTED_DECLARATION)).toThrow(
      "fixtures/unsupported-declaration.css.ts",
    )
  })

  it("transforms the package-owned consumer css entry when executed by Bun", () => {
    const code = runBunTransform(consumer.shared, consumer.root)
    expect(code).toContain("StyleSheet.create")
    expect(code).toContain("export const container")
    expect(code).toContain("export const heading")
    const styles = evaluateNativeExports(code) as {
      container: { backgroundColor: unknown; paddingTop: unknown }
      heading: { fontSize: number }
      button: Record<string, { minHeight: number; opacity?: number }>
    }
    expect(styles.heading.fontSize).toBe(24)
    expect(styles.container.backgroundColor).toMatchObject({ varName: "--crumbs-fixture-color-canvas" })
    expect(styles.container.paddingTop).toMatchObject({ varName: "--crumbs-fixture-space-md" })
    expect(Object.keys(styles.button)).toEqual(["default", "pressed"])
    expect(styles.button.default?.minHeight).toBe(48)
    expect(styles.button.pressed?.opacity).toBe(0.82)
    expect(code).toContain('"default": _s[')
    expect(code).toContain('"pressed": _s[')
    expect(code).toContain("crumbs.css.theme-token")
    expect(code).toContain("--crumbs-fixture-color-canvas")
    expect(code).not.toContain("@vanilla-extract/css")
  })

  it("transforms the package-owned button recipe style entry", () => {
    const code = runBunTransform(consumer.button, consumer.root)
    const { button } = evaluateNativeExports(code) as { button: {
      $$type: string
      $$debugName: string
      base: { minHeight: number; backgroundColor: unknown }
      variants: Record<string, Record<string, unknown>>
      defaultVariants: unknown
      compoundVariants: unknown
    } }
    expect(button.$$type).toBe("crumbs.css.recipe")
    expect(button.$$debugName).toBe("fixtureButton")
    expect(button.base.minHeight).toBe(48)
    expect(button.base.backgroundColor).toMatchObject({ varName: "--crumbs-fixture-color-accent" })
    expect(Object.keys(button.variants)).toEqual(["tone", "disabled", "pressed"])
    expect(button.variants.tone?.primary).toMatchObject({ backgroundColor: { varName: "--crumbs-fixture-color-accent" } })
    expect(button.variants.disabled?.true).toEqual({ opacity: 0.64 })
    expect(button.defaultVariants).toEqual({ tone: "primary", disabled: false, pressed: false })
    expect(button.compoundVariants).toEqual([{ variants: { disabled: true, tone: "primary" }, style: { opacity: 0.5 } }])
  })

  it("accepts Metro's project-relative package-owned consumer css filename", () => {
    const code = runBunTransform("styles/shared.css.ts", consumer.root)
    expect(code).toContain("StyleSheet.create")
    expect(code).toContain("export const container")
    expect(code).toContain("export const heading")
    expect(code).not.toContain("@vanilla-extract/css")
  })

  it("keeps package-owned consumer theme dependencies local without leaking package internals", () => {
    const code = runBunTransform(consumer.reference, consumer.root)
    expect(code).toContain(`import "./theme.css.ts";`)
    expect(code).not.toContain("packages/native-styles/dist")
    expect(code).not.toContain("/dist/style")
    expect(code).not.toContain("/dist/theme-token")
  })
})

it("M10.5 emits independently derived fresh-input markers and restores edits/errors exactly",async()=>{
 const {mkdtempSync,rmSync}=await import("node:fs"),{tmpdir}=await import("node:os")
 const directory=mkdtempSync(path.join(tmpdir(),"crumbs-fresh-proof-test-")),output=path.join(directory,"receipts.json")
 try{
  const child=Bun.spawn([process.execPath,path.join(PKG_ROOT,"test-support/fresh-pipeline-qualification.ts"),"worker",path.resolve(PKG_ROOT,"../.."),output],{stdout:"pipe",stderr:"pipe"})
  const [exit,stdout,stderr]=await Promise.all([child.exited,new Response(child.stdout).text(),new Response(child.stderr).text()])
  expect({exit,details:exit===0?"":stdout+stderr}).toEqual({exit:0,details:""})
  const receipts=JSON.parse(readFileSync(output,"utf8")) as Array<{error?:unknown;proof?:{kind:string}}>
  expect(receipts).toHaveLength(17)
  expect(receipts.filter(r=>!r.error).every(r=>r.proof?.kind==="fresh")).toBe(true)
  expect(receipts.filter(r=>r.error)).toHaveLength(2)
 }finally{rmSync(directory,{recursive:true,force:true})}
})

it("M10.5 reevaluates unchanged authoring and recovers after an authoring exception",async()=>{
 const {mkdtempSync,writeFileSync,rmSync}=await import("node:fs")
 const directory=mkdtempSync(path.join(PKG_ROOT,"fixtures/.fresh-counter-")),file=path.join(directory,"case.css.ts")
 const key="CRUMBS_M105_EVALUATION_COUNTER",previous=process.env[key]
 try{
  delete process.env[key]
  const source=`import {style} from '@opsydyn/crumbs-css/style';const key='${key}';process.env[key]=String(Number(process.env[key]??0)+1);export const root=style({width:Number(process.env[key])});`
  writeFileSync(file,source)
  const first=evaluateNativeExports(await transformCssTsToStyleSheet(file,PKG_ROOT,{includeStyleExplanations:false}))
  const second=evaluateNativeExports(await transformCssTsToStyleSheet(file,PKG_ROOT,{includeStyleExplanations:false}))
  expect((first.root as {width:number}).width).toBe(1);expect((second.root as {width:number}).width).toBe(2)
  writeFileSync(file,source+"\nthrow new Error('authoring failure');")
  await expect(transformCssTsToStyleSheet(file,PKG_ROOT)).rejects.toThrow("authoring failure")
  writeFileSync(file,source)
  expect((evaluateNativeExports(await transformCssTsToStyleSheet(file,PKG_ROOT,{includeStyleExplanations:false})).root as {width:number}).width).toBe(4)
 }finally{if(previous===undefined)delete process.env[key];else process.env[key]=previous;rmSync(directory,{recursive:true,force:true})}
})
