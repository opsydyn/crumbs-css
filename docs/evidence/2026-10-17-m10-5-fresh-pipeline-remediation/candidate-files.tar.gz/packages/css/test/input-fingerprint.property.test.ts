import { expect,it } from "bun:test"
import fc from "fast-check"
import { createFreshInputFingerprint } from "../src/compiler/input-fingerprint"
import { CompilerRecordAdmissionError } from "../src/compiler/record-admission"
import { oracleInputFingerprint } from "../test-support/fresh-pipeline-qualification"
const identity={cacheable:true,files:[{sourcePath:"/app/missing.ts",sourceHash:null,canonicalPath:null}],links:[]}
const fingerprint=(inputs:Record<string,unknown>,source="same source",resolution=identity)=>createFreshInputFingerprint(source,inputs,resolution)
it("preserves complete edge multisets while ignoring record and input insertion order",()=>{
 fc.assert(fc.property(fc.array(fc.record({path:fc.string(),kind:fc.constantFrom("import-statement","require-call"),original:fc.string(),external:fc.boolean()}),{maxLength:12}),edges=>{
  const a={"b.ts":{imports:edges,bytes:12,unknown:{z:2,a:1}},"a.ts":{imports:[],bytes:10}}
  const b={"a.ts":{bytes:10,imports:[]},"b.ts":{unknown:{a:1,z:2},bytes:12,imports:[...edges].reverse()}}
  expect(fingerprint(a)).toBe(fingerprint(b))
  expect(fingerprint(a)).toBe(oracleInputFingerprint("same source",a,identity))
 }),{seed:1051702,numRuns:200})
})
it("retains multiplicity originals kinds external flags unknown fields and ordered non-import arrays",()=>{
 const edge={path:"pkg",kind:"import-statement",original:"alias",external:true}
 const a={"a.ts":{imports:[edge],bytes:10,unknown:[1,2]}}
 const variants=[{...a,"a.ts":{...a["a.ts"],imports:[edge,edge]}},...Object.entries({original:"other",kind:"require-call",external:false}).map(([key,value])=>({...a,"a.ts":{...a["a.ts"],imports:[{...edge,[key]:value}]}})),{...a,"a.ts":{...a["a.ts"],unknown:[2,1]}},{...a,"a.ts":{...a["a.ts"],extra:3}}]
 for(const b of variants)expect(fingerprint(b)).not.toBe(fingerprint(a))
 expect(fingerprint(a,"changed source")).not.toBe(fingerprint(a))
 expect(fingerprint(a,"same source",{...identity,files:[]})).not.toBe(fingerprint(a))
 expect(fingerprint({value:-0})).not.toBe(fingerprint({value:0}))
 expect(fingerprint({value:"\ud800"})).not.toBe(fingerprint({value:"\ud801"}))
})
it("rejects unsupported data and accessors without invoking them",()=>{
 let reads=0
 const getter=Object.defineProperty({},"value",{enumerable:true,get(){reads++;return 1}})
 const cycle:Record<string,unknown>={};cycle.self=cycle
 for(const value of [undefined,()=>1,Symbol("x"),NaN,Infinity,new Date(),cycle,getter,[,1],Object.assign([1],{extra:2}),{[Symbol("unknown")]:1}]){
  expect(()=>fingerprint({value})).toThrow(CompilerRecordAdmissionError)
 }
 expect(reads).toBe(0)
 const plain=Object.assign(Object.create(null),{value:"safe"})
 expect(fingerprint(plain)).toBe(fingerprint({value:"safe"}))
})
