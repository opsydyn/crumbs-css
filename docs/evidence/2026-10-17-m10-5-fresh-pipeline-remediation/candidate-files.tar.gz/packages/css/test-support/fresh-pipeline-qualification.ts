import { createHash } from "node:crypto"
import { readFileSync, readdirSync } from "node:fs"
import { join } from "node:path"

export type QualificationInputs = { controlRepoRoot:string; controlPackageRoot:string; controlTarball:string; candidateRepoRoot:string; scratchRoot:string; floorNode:string }
const hash = (value:string | Uint8Array) => createHash("sha256").update(value).digest("hex")
const record = (value:unknown):Record<string, any> => {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError("Expected qualification record")
  return value as Record<string, any>
}
// Independent evidence oracle: never imports the production fingerprint implementation.
export function oracleInputFingerprint(source:string, inputs:unknown, resolutionIdentity:unknown):string {
  function encode(value:any, at:string[] = []):string {
    if (value === null) return "n;"
    if (typeof value === "boolean") return value ? "b1;" : "b0;"
    if (typeof value === "string") { const literal=JSON.stringify(value); return `s${Buffer.byteLength(literal)}:${literal}` }
    if (typeof value === "number" && Number.isFinite(value)) return `d${Object.is(value,-0) ? "-0" : value};`
    if (Array.isArray(value)) {
      const encoded = value.map((v,i) => encode(v,[...at,String(i)]))
      if (at.length === 3 && at[0] === "inputs" && at[2] === "imports") encoded.sort()
      return `a${encoded.length}[${encoded.join("")}]`
    }
    if (value && typeof value === "object") {
      const keys = Object.keys(value).sort()
      return `o${keys.length}{${keys.map(key=>encode(key)+encode(value[key],[...at,key])).join("")}}`
    }
    throw new TypeError("Unsupported independent oracle value")
  }
  return hash("crumbs-fresh-input-v1\0" + encode({ sourceHash:hash(source), inputs, resolutionIdentity }))
}

export function verifyMarker(value:unknown):string[] {
  try {
    const r=record(value), p=record(r.proof), context=record(p.context)
    if (typeof r.code !== "string" || !Array.isArray(p.dependencies)) return ["missing marker proof"]
    const marker=r.code.match(/^\/\* @crumbs-native-cache ([a-f0-9]{64}) \*\//)
    if (!marker) return ["missing cache marker"]
    let key:string
    if (p.kind === "legacy") key=hash(JSON.stringify({entryHash:p.entryHash, inputs:p.inputs, resolutionIdentity:p.resolutionIdentity}))
    else if (p.kind === "fresh") key=oracleInputFingerprint(p.source,p.inputs,p.resolutionIdentity)
    else return ["unknown marker proof domain"]
    let material="crumbs-native-cache-v1\0"+`compiler=${context.compilerKey}\0platform=${context.platform ?? ""}\0dev=${context.dev?1:0}\0strict=${context.strictDiagnostics?1:0}\0styleSheet=${context.useStyleSheet?1:0}\0ident=${context.identOption}\0`
    for (const dependency of [...p.dependencies].sort((a,b)=>a.importPath.localeCompare(b.importPath))) material+=`${dependency.importPath}\0${dependency.sourceHash}\0`
    material+=`resolution=${key}\0`
    return hash(material) === marker[1] ? [] : ["cache marker does not match independent derivation"]
  } catch { return ["invalid marker proof"] }
}
function comparableMaps(receipt:Record<string,any>):unknown {
  if(!Array.isArray(receipt.maps))return receipt.maps
  const start="/* @crumbs-native-cache ".length,end=start+64
  return receipt.maps.map((segment:unknown)=>Array.isArray(segment)&&segment[0]===1&&typeof segment[1]==="number"&&segment[1]>=start&&segment[1]<end&&segment[2]===1&&segment[3]===0
    ? [segment[0],start,...segment.slice(2)] : segment)
}
function body(code:string):string { return code.replace(/^\/\* @crumbs-native-cache [a-f0-9]{64} \*\//,"/* independently verified cache marker */") }
export function compareTransformReceipts(control:unknown,candidate:unknown,_inputs:QualificationInputs):string[] {
  const a=record(control),b=record(candidate)
  if(a.error||b.error){
    if(!a.error||!b.error)return ["success/error differs"]
    return ["case","error","authoredInputs"].filter(key=>JSON.stringify(a[key])!==JSON.stringify(b[key])).map(key=>`${key} differs`)
  }
  const errors=[...verifyMarker(a).map(e=>`control: ${e}`),...verifyMarker(b).map(e=>`candidate: ${e}`)]
  if (body(a.code)!==body(b.code)) errors.push("code differs")
  if(JSON.stringify(comparableMaps(a))!==JSON.stringify(comparableMaps(b)))errors.push("maps differs")
  for(const key of ["observation","metadata","authoredInputs","externalVersions","diagnostics","events"])
    if (JSON.stringify(a[key])!==JSON.stringify(b[key])) errors.push(`${key} differs`)
  if(a.privateInventoryVerified!==true) errors.push("control private inventory unverified")
  if(b.privateInventoryVerified!==true) errors.push("candidate private inventory unverified")
  return errors
}
export function verifyProcessReports(reports:unknown[]):string[] {
  const errors:string[]=[]
  if(reports.length!==5)errors.push("expected five independent benchmark processes")
  const pids=new Set<number>()
  for(const value of reports){
    const run=record(value)
    if(!Number.isSafeInteger(run.pid)||pids.has(run.pid))errors.push("benchmark process is not independent")
    pids.add(run.pid)
    if(run.exitCode!==0)errors.push("benchmark smoke failed")
    const metrics=run.report?.metrics
    if(!Array.isArray(metrics)||metrics.filter((m:any)=>m.name?.startsWith("warm transform ") && m.samples===6).length!==2) errors.push("benchmark report is missing or truncated")
  }
  return errors
}
export function verifyQualificationPacket(directory:string):string[] {
  const inventory=JSON.parse(readFileSync(join(directory,"inventory.json"),"utf8")) as Array<{path:string;sha256:string}>
  const errors:string[]=[]
  for(const f of inventory)if(hash(readFileSync(join(directory,f.path)))!==f.sha256)errors.push(`inventory mismatch: ${f.path}`)
  for(const name of readdirSync(directory).filter(n=>n.endsWith("-comparison.json"))){
    const comparison=JSON.parse(readFileSync(join(directory,name),"utf8"))
    if(!Array.isArray(comparison.errors)) errors.push(`invalid comparison: ${name}`)
  }
  return errors
}

// Untimed worker only: actual compiler and source-map paths, isolated module instrumentation.
if (import.meta.main && process.argv[2] === "worker") {
  const { mock } = await import("bun:test")
  const { createRequire } = await import("node:module")
  const { resolve, dirname, relative } = await import("node:path")
  const { runInNewContext } = await import("node:vm")
  const [repoArg, outputArg] = process.argv.slice(3)
  if (!repoArg || !outputArg) throw Error("Worker requires repository and output")
  const repo=resolve(repoArg), pkg=join(repo,"packages/css"), ownRequire=createRequire(join(pkg,"package.json"))
  const integrationPath=ownRequire.resolve("@vanilla-extract/integration")
  const real=ownRequire(integrationPath), realCompile=real.compile
  let latest:{source:string;inputs:Record<string,unknown>} | undefined
  mock.module(integrationPath,()=>({...real,compile:async(options:any)=>{
    let inputs:Record<string,unknown>={}
    const capture={name:"qualification-raw-inputs",setup(build:any){build.onEnd((r:any)=>{inputs=r.metafile?.inputs ?? {}})}}
    const result=await realCompile({...options,esbuildOptions:{...options.esbuildOptions,plugins:[...(options.esbuildOptions?.plugins ?? []),capture]}})
    latest={source:result.source,inputs};return result
  }}))
  const transformerPath=join(pkg,"src/transformer.ts")
  const transformer=await import(transformerPath)
  function packageVersion(entry:string,name:string):string {
    for(let dir=dirname(entry);;dir=dirname(dir)){
      try{const m=JSON.parse(readFileSync(join(dir,"package.json"),"utf8"));if(m.name===name)return m.version}catch{}
      if(dir===dirname(dir))throw Error(`Missing version ${name}`)
    }
  }
  const integrationRequire=createRequire(integrationPath)
  const externalVersions={integration:packageVersion(integrationPath,"@vanilla-extract/integration"),esbuild:packageVersion(integrationRequire.resolve("esbuild"),"esbuild"),vanilla:packageVersion(ownRequire.resolve("@vanilla-extract/css"),"@vanilla-extract/css")}
  const normalize=(value:any):any=>typeof value==="string"?value.replaceAll(repo,"<repo>").replaceAll(dirname(repo),"<checkout-parent>"):Array.isArray(value)?value.map(normalize):value&&typeof value==="object"?Object.fromEntries(Object.entries(value).map(([k,v])=>[k,normalize(v)])):value
  function snapshot(value:any,seen=new Map<object,number>()):any {
    if(value===null)return null
    if(typeof value==="number")return Object.is(value,-0)?{number:"-0"}:value
    if(typeof value==="symbol")return{symbol:Symbol.keyFor(value) ?? value.description,global:Symbol.keyFor(value)!==undefined}
    if(typeof value==="undefined")return{undefined:true}
    if(typeof value!=="object"&&typeof value!=="function")return value
    if(seen.has(value))return{ref:seen.get(value)}
    const id=seen.size;seen.set(value,id)
    return{id,array:Array.isArray(value),frozen:Object.isFrozen(value),properties:Reflect.ownKeys(value).map(key=>{
      const d=Object.getOwnPropertyDescriptor(value,key)!
      return{key:typeof key==="symbol"?snapshot(key):key,enumerable:d.enumerable,configurable:d.configurable,...("value"in d?{writable:d.writable,value:snapshot(d.value,seen)}:{get:d.get?.toString(),set:d.set?.toString()})}
    })}
  }
  const {mkdirSync,writeFileSync,rmSync}=await import("node:fs")
  const owned=join(pkg,"fixtures/.fresh-pipeline-owned")
  mkdirSync(owned)
  const themeOriginal=readFileSync(join(pkg,"fixtures/consumer/styles/theme.css.ts"),"utf8")+"\nexport const ownedMinimumHeight = 48;\n"
  const buttonOriginal=readFileSync(join(pkg,"fixtures/consumer/styles/button.css.ts"),"utf8").replace("{ vars }","{ vars, ownedMinimumHeight }").replace("minHeight: 48","minHeight: ownedMinimumHeight")
  const ownedFile="fixtures/.fresh-pipeline-owned/button.css.ts"
  const cases= ["examples/recipe.css.ts","fixtures/consumer/styles/button.css.ts"].flatMap(file=>["ios","web"].flatMap(platform=>[true,false].map(dev=>({file,platform,dev,step:"base"}))))
  for(const step of ["baseline","entry-edit","entry-restore","dependency-edit","dependency-restore","syntax-error","syntax-repair","authoring-error","authoring-repair"])cases.push({file:ownedFile,platform:"ios",dev:true,step})
  const receipts:any[]=[]
  try{for(const {file,platform,dev,step} of cases){
      if(file===ownedFile){
        writeFileSync(join(owned,"theme.css.ts"),step==="dependency-edit"?themeOriginal.replace("ownedMinimumHeight = 48","ownedMinimumHeight = 50"):themeOriginal)
        writeFileSync(join(owned,"button.css.ts"),step==="entry-edit"?buttonOriginal.replace("minHeight: ownedMinimumHeight","minHeight: ownedMinimumHeight + 1"):step==="syntax-error"?"export const broken = ;":step==="authoring-error"?buttonOriginal+"\nthrow new Error('owned authoring failure');":buttonOriginal)
      }
      const filename=join(pkg,file), cwd=file===ownedFile?owned:file.startsWith("examples/")?pkg:join(pkg,"fixtures/consumer")
      let result:any
      try{result=await transformer.transform({upstreamTransformerPath:join(pkg,"fixtures/upstream-source-map.cjs"),nativeStyles:{strictDiagnostics:true,includeStyleExplanations:dev}},cwd,filename,readFileSync(filename),{platform,dev})}catch(error){
        if(step!=="syntax-error"&&step!=="authoring-error")throw error
        receipts.push({case:`${file}:${platform}:${dev}:${step}`,error:normalize({name:(error as Error).name,message:(error as Error).message}),authoredInputs:[{path:file,hash:hash(readFileSync(filename))}]});continue
      }
      if(step==="syntax-error"||step==="authoring-error")throw Error("Expected authored failure was accepted")
      if(!latest)throw Error("No observed fresh compilation")
      const metadata=result.__crumbsNativeStyles, identity=metadata.resolutionIdentity
      const isPrivate=(p:string)=>p.startsWith(join(pkg,"dist")+"/")
      const privateInputs=Object.keys(latest.inputs).map(p=>resolve(cwd,p)).filter(isPrivate).sort().map(p=>({path:relative(pkg,p),hash:hash(readFileSync(p))}))
      const privateInventoryVerified=privateInputs.every(f=>hash(readFileSync(join(pkg,f.path)))===f.hash)
      const authoredInputs=Object.keys(latest.inputs).map(p=>resolve(cwd,p)).filter(p=>!isPrivate(p)).sort().map(p=>({path:relative(pkg,p),hash:hash(readFileSync(p))}))
      const byPath=(a:any,b:any)=>a.sourcePath<b.sourcePath?-1:a.sourcePath>b.sourcePath?1:0
      const publicIdentity={...identity,files:normalize(identity.files.filter((f:any)=>!isPrivate(f.sourcePath))).sort(byPath),links:normalize(identity.links.filter((f:any)=>!isPrivate(f.sourcePath))).sort(byPath)}
      const exports:Record<string,unknown>={}
      runInNewContext(result.code.replace(/^import .*;$/gm,"").replace(/export const (\w+) =/g,"exports.$1 ="),{exports,StyleSheet:{create:(v:unknown)=>v}})
      const context={compilerKey:`${transformer.getCacheKey()}:style-explanations=${dev?1:0}`,platform,dev,strictDiagnostics:true,useStyleSheet:platform!=="web",identOption:process.env.NODE_ENV==="production"?"short":"debug"}
      const dependencies=metadata.dependencies.map((f:any)=>({importPath:relative(dirname(filename),f.sourcePath).startsWith(".")?relative(dirname(filename),f.sourcePath):"./"+relative(dirname(filename),f.sourcePath),sourceHash:f.sourceHash}))
      const proof={kind:"legacy",source:latest.source,inputs:latest.inputs,resolutionIdentity:identity,context,dependencies,entryHash:identity.files.find((f:any)=>f.sourcePath===filename)?.sourceHash}
      const receipt={case:`${file}:${platform}:${dev}:${step}`,code:result.code,proof,observation:snapshot(exports),maps:result.map,metadata:normalize({...metadata,resolutionIdentity:publicIdentity}),authoredInputs,externalVersions,privateInputs,privateInventoryVerified,rawMetadata:metadata,diagnostics:[],events:[]}
      if(verifyMarker(receipt).length)proof.kind="fresh"
      if(verifyMarker(receipt).length)throw Error("Neither independently derived marker domain matches")
      receipts.push(receipt)
    }
    const trace=receipts.filter(r=>r.case.startsWith(ownedFile)&&!r.error),baseline=trace[0]!.code
    for(const restored of trace.filter(r=>/restore|repair/.test(r.case)))if(restored.code!==baseline)throw Error(`Full edit restoration failed: ${restored.case}`)
  }finally{rmSync(owned,{recursive:true,force:true})}
  await Bun.write(outputArg,JSON.stringify(receipts,null,2)+"\n")
  integrationRequire("esbuild").stop()
}
