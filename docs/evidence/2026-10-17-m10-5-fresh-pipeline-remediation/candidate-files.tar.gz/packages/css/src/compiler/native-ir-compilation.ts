import { captureScalarIntoNativeIr,lowerScalarBlock,lowerAdmittedScalarBlock,type ScalarDeclarationBlock } from "./native-ir"
import { captureStructuredIntoNativeIr,lowerStructuredBlock,lowerAdmittedStructuredBlock,type StructuredDeclarationBlock } from "./structured-ir"
import { captureCompatibilityIntoNativeIr } from "./compatibility-adapter"

export type NativeIrCompilation = {
  readonly captureScalar: typeof captureScalarIntoNativeIr
  readonly captureStructured: typeof captureStructuredIntoNativeIr
  readonly captureCompatibility: typeof captureCompatibilityIntoNativeIr
  readonly lowerScalar: (block:ScalarDeclarationBlock)=>ReturnType<typeof lowerScalarBlock>
  readonly lowerStructured: (block:StructuredDeclarationBlock)=>ReturnType<typeof lowerStructuredBlock>
  readonly dispose: ()=>void
}

/** Only capture results can mint an identity/family proof. No caller registration. */
export function createNativeIrCompilation():NativeIrCompilation {
  let active=true
  let scalar=new WeakSet<ScalarDeclarationBlock>(),structured=new WeakSet<StructuredDeclarationBlock>()
  const assertActive=()=>{if(!active)throw new TypeError("Native IR compilation is disposed")}
  return {
    captureScalar(rule,context){
      assertActive();const result=captureScalarIntoNativeIr(rule,context)
      if(result.block)scalar.add(result.block)
      return result
    },
    captureStructured(rule,context){
      assertActive();const result=captureStructuredIntoNativeIr(rule,context)
      if(result.block)structured.add(result.block)
      return result
    },
    captureCompatibility(rule,context){
      assertActive();const result=captureCompatibilityIntoNativeIr(rule,context)
      if(result.scalarBlock)scalar.add(result.scalarBlock)
      if(result.structuredBlock)structured.add(result.structuredBlock)
      return result
    },
    lowerScalar(block){assertActive();return scalar.has(block)?lowerAdmittedScalarBlock(block):lowerScalarBlock(block)},
    lowerStructured(block){assertActive();return structured.has(block)?lowerAdmittedStructuredBlock(block):lowerStructuredBlock(block)},
    dispose(){active=false;scalar=new WeakSet();structured=new WeakSet()},
  }
}
