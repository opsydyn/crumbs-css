import { createHash } from "node:crypto"
import { CompilerRecordAdmissionError } from "./record-admission"
import type { ResolutionIdentity } from "./resolution-identity"

const sha256=(value:string)=>createHash("sha256").update(value).digest("hex")

/** Post-compile identity only. No compiler text or evaluation reuse is authorized. */
export function createFreshInputFingerprint(
  source:string,
  inputs:Readonly<Record<string,unknown>>,
  resolutionIdentity:ResolutionIdentity,
):string {
  const active=new Set<object>()
  const invalid=(at:readonly string[]):never=>{throw new CompilerRecordAdmissionError(`Unsupported fingerprint data at ${at.join(".") || "<root>"}`)}
  function encode(value:unknown,at:readonly string[]=[]):string {
    if(value===null)return "n;"
    if(typeof value==="boolean")return value?"b1;":"b0;"
    if(typeof value==="string"){
      // JSON escapes lone UTF-16 surrogates, preventing UTF-8 replacement collisions.
      const text=JSON.stringify(value)
      return `s${Buffer.byteLength(text)}:${text}`
    }
    if(typeof value==="number"&&Number.isFinite(value))return `d${Object.is(value,-0)?"-0":value};`
    if(typeof value!=="object")return invalid(at)
    if(active.has(value))return invalid(at)
    const array=Array.isArray(value),prototype=Object.getPrototypeOf(value)
    if(array?prototype!==Array.prototype:prototype!==Object.prototype&&prototype!==null)return invalid(at)
    const descriptors=Object.getOwnPropertyDescriptors(value)
    if(Reflect.ownKeys(descriptors).some(key=>typeof key==="symbol"))return invalid(at)
    active.add(value)
    try{
      if(array){
        const length=descriptors.length!.value as number
        const keys=Object.keys(descriptors).filter(key=>key!=="length")
        if(keys.length!==length||keys.some(key=>!/^\d+$/.test(key)||String(Number(key))!==key||Number(key)>=length))return invalid(at)
        const items:string[]=[]
        for(let i=0;i<length;i++){
          const descriptor=descriptors[String(i)]
          if(!descriptor||!("value"in descriptor))return invalid([...at,String(i)])
          items.push(encode(descriptor.value,[...at,String(i)]))
        }
        if(at.length===3&&at[0]==="inputs"&&at[2]==="imports")items.sort()
        return `a${length}[${items.join("")}]`
      }
      const keys=Object.keys(descriptors).filter(key=>descriptors[key]!.enumerable).sort()
      return `o${keys.length}{${keys.map(key=>{
        const descriptor=descriptors[key]!
        if(!("value"in descriptor))return invalid([...at,key])
        return encode(key)+encode(descriptor.value,[...at,key])
      }).join("")}}`
    }finally{active.delete(value)}
  }
  return sha256("crumbs-fresh-input-v1\0"+encode({sourceHash:sha256(source),inputs,resolutionIdentity}))
}
