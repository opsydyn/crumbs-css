import { createHash } from "node:crypto"
import { readFileSync, readdirSync } from "node:fs"
import { mkdir,writeFile } from "node:fs/promises"
import { resolve,join } from "node:path"
import { execFileSync } from "node:child_process"
import { compareTransformReceipts,verifyMarker,verifyProcessReports,verifyQualificationPacket,type QualificationInputs } from "../packages/css/test-support/fresh-pipeline-qualification"
import { acceptBenchmarkProcessReport } from "./host-budget-report-collection"
import { budgetRegistryCodec, summarizeBenchmarkReports,compareRecordedMetrics } from "../packages/css/bench/budget-contract"
const [stage,manifest]=process.argv.slice(2)
if(!stage||!manifest||!manifest.startsWith("/"))throw Error("Requires stage and absolute qualification input manifest")
const inputs=JSON.parse(readFileSync(manifest,"utf8")) as QualificationInputs
const out=join(inputs.scratchRoot,"qualification");await mkdir(out,{recursive:true})
const sha=(b:Uint8Array|string)=>createHash("sha256").update(b).digest("hex")
const save=async(name:string,data:unknown)=>writeFile(join(out,name),JSON.stringify(data,null,2)+"\n")
async function worker(repo:string,name:string){
 const destination=join(out,name+".json"),script=resolve(import.meta.dir,"../packages/css/test-support/fresh-pipeline-qualification.ts")
 const child=Bun.spawn([process.execPath,script,"worker",repo,destination],{cwd:repo,stdout:"pipe",stderr:"pipe"})
 const [exit,stdout,stderr]=await Promise.all([child.exited,new Response(child.stdout).text(),new Response(child.stderr).text()])
 await writeFile(join(out,name+".log"),stdout+"\n"+stderr)
 if(exit!==0)throw Error(`${name} worker failed: ${stderr.slice(-1500)}`)
 return JSON.parse(readFileSync(destination,"utf8")) as unknown[]
}
if(stage==="preflight"){
 if(sha(readFileSync(inputs.controlTarball))!=="4bd7897aa5beb6383b158f4e214436ba5d0d659b6b0fc005142c945a10dda02e")throw Error("Control tarball mismatch")
 if(execFileSync(inputs.floorNode,["--version"],{encoding:"utf8"}).trim()!=="v22.0.0")throw Error("Genuine Node22.0.0 required")
 const head=execFileSync("git",["rev-parse","HEAD"],{cwd:inputs.controlRepoRoot,encoding:"utf8"}).trim()
 if(head!=="5a13f913b17ae957172968144ec83c391caee337")throw Error("Control source mismatch")
 const recovery=JSON.parse(readFileSync(join(inputs.controlPackageRoot,"../recovery.json"),"utf8"))
 for(const f of recovery.files){
  if(sha(readFileSync(join(inputs.controlPackageRoot,f.path)))!==f.sha256)throw Error(`Recovered control mismatch: ${f.path}`)
  if(f.path.startsWith("dist/")&&sha(readFileSync(join(inputs.controlRepoRoot,"packages/css",f.path)))!==f.sha256)throw Error(`Control source dist mismatch: ${f.path}`)
 }
 await save("preflight.json",{passed:true,controlRevision:head,tarballSha256:sha(readFileSync(inputs.controlTarball)),floor:execFileSync(inputs.floorNode,["--version"],{encoding:"utf8"}).trim(),bun:Bun.version,controlFiles:recovery.files.length})
}else if(stage==="control"||stage==="parity"){
 const control=await worker(inputs.controlRepoRoot,stage+"-control")
 const candidate=await worker(stage==="control"?inputs.controlRepoRoot:inputs.candidateRepoRoot,stage+"-candidate")
 const errors=control.length===candidate.length?control.flatMap((r,i)=>compareTransformReceipts(r,candidate[i],inputs).map(e=>`case ${i}: ${e}`)):["case count differs"]
 await save(stage+"-comparison.json",{errors,cases:control.length,passed:errors.length===0})
 if(errors.length)throw Error(errors.join("\n"))
}else if(stage==="warm"){
 const runs=[]
 for(let i=1;i<=5;i++){
  const file=join(out,`warm-${i}.json`),child=Bun.spawn([process.execPath,"packages/css/bench/native-styles.bench.ts"],{cwd:inputs.candidateRepoRoot,env:{...process.env,CRUMBS_BENCH_WARM_TRANSFORM_CWD:"package-root",CRUMBS_BENCH_JSON_OUTPUT:file},stdout:"pipe",stderr:"pipe"})
  const [exitCode,stdout,stderr]=await Promise.all([child.exited,new Response(child.stdout).text(),new Response(child.stderr).text()])
  await writeFile(join(out,`warm-${i}.log`),stdout+"\n"+stderr)
  const report=JSON.parse(readFileSync(file,"utf8"))
  acceptBenchmarkProcessReport(report,exitCode,stderr)
  const printed=stdout.slice(stdout.indexOf("{\n"),stdout.lastIndexOf("\n}")+2)
  if(JSON.stringify(JSON.parse(printed))!==JSON.stringify(report))throw Error("Printed benchmark differs")
  runs.push({pid:child.pid,exitCode,report})
 }
 const errors=verifyProcessReports(runs),summary=summarizeBenchmarkReports(runs.map(r=>r.report))
 const decoded=budgetRegistryCodec.decodeJson(readFileSync(join(inputs.candidateRepoRoot,"packages/css/bench/budgets.json"),"utf8"))
 if(!decoded.ok)throw Error("Invalid registry")
 const registry={...decoded.value,metrics:decoded.value.metrics.filter(m=>m.id==="warm-transform-ms")}
 if(registry.metrics.length!==1)throw Error("Expected unchanged warm metric")
 const comparison=compareRecordedMetrics(registry,inputs.candidateRepoRoot,{effect:{},runtimeInit:{},editor:{},incremental:{},benchmark:summary})
 await save("warm-runs.json",runs);await save("warm-summary.json",summary);await save("warm-comparison.json",{...comparison,errors,feasible:errors.length===0&&comparison.metrics.length===1&&comparison.metrics[0]!.result==="pass"})
 if(errors.length||comparison.metrics[0]!.result!=="pass")throw Error("Complete candidate failed unchanged warm feasibility gate")
}else if(stage==="verify"){
 const errors=verifyQualificationPacket(out)
 for(const name of ["control-control.json","control-candidate.json","parity-control.json","parity-candidate.json"]){
  try{for(const receipt of JSON.parse(readFileSync(join(out,name),"utf8"))){ if(!receipt.error)errors.push(...verifyMarker(receipt)) }}catch(e){if(name.startsWith("control"))throw e}
 }
 if(errors.length)throw Error(errors.join("\n"))
}else throw Error("Unknown qualification stage")
const inventory=readdirSync(out).filter(n=>n!=="inventory.json").sort().map(path=>({path,sha256:sha(readFileSync(join(out,path)))}))
await save("inventory.json",inventory)
console.log(`Fresh pipeline ${stage}: passed (${out})`)
