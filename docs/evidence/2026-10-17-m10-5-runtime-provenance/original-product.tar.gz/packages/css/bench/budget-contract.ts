import * as Schema from "effect/Schema"
import { readFileSync } from "node:fs"
import { resolve, sep } from "node:path"
import { makeDataCodec } from "../src/contracts/data-codec"
import { admitMetroIncrementalReport } from "./metro-incremental"

export const BudgetRegistryVersion = 2 as const
export const requiredBudgetDomains = [
  "js-frames",
  "ui-frames",
  "allocations",
  "retained-memory",
  "runtime-footprint",
  "cold-transform",
  "warm-transform",
  "incremental-rebuild",
  "editor",
] as const

const FiniteNonNegative = Schema.Finite.check(Schema.isGreaterThanOrEqualTo(0))
const PositiveInteger = Schema.Int.check(Schema.isGreaterThan(0))
const Id = Schema.String.check(Schema.isPattern(/^[a-z][a-z0-9-]*$/))
const BaselineSelectorSchema = Schema.Literals([
  "effect.runtime.cjs.graph-bytes",
  "runtime.theme-core.esm.graph-bytes",
  "runtime.theme-core.cjs.graph-bytes",
  "runtime.tokens.esm.graph-bytes",
  "runtime.tokens.cjs.graph-bytes",
  "runtime.theme-compatibility.esm.graph-bytes",
  "runtime.theme-compatibility.cjs.graph-bytes",
  "runtime-init.floor.esm.load-ms.median",
  "runtime-init.floor.cjs.load-ms.median",
  "runtime-init.current.esm.load-ms.median",
  "runtime-init.current.cjs.load-ms.median",
  "benchmark.cold-transform.max-median-ms",
  "benchmark.warm-transform.max-median-ms",
  "metro-incremental.direct-css-edit-ms.median",
  "editor.tsc.10000.wall-ms.median",
  "editor.tsgo.10000.wall-ms.median",
  "editor.tsc.10000.memory-kib.median",
  "editor.tsgo.10000.memory-kib.median",
  "editor.tsc.10000.instantiations",
  "editor.tsgo.10000.instantiations",
  "editor.10000.first-completion-ms.median",
  "editor.10000.warm-completion-ms.median",
])
const commonMetricFields = {
  id: Id,
  domain: Schema.Literals(requiredBudgetDomains),
  scenario: Schema.NonEmptyString,
  measure: Schema.NonEmptyString,
  unit: Schema.Literals(["ms", "bytes", "KiB", "count"]),
  direction: Schema.Literal("lower-is-better"),
  environmentClass: Schema.NonEmptyString,
}
const MissingBaselineSchema = Schema.Struct({ status: Schema.Literal("missing"), reason: Schema.NonEmptyString })
const DiagnosticBaselineSchema = Schema.Struct({
  status: Schema.Literal("diagnostic"), evidence: Schema.NonEmptyString,
  selector: Schema.optionalKey(BaselineSelectorSchema), value: Schema.optionalKey(Schema.Finite),
  reason: Schema.NonEmptyString, repetitions: PositiveInteger,
})
const RecordedBaselineSchema = Schema.Struct({
  status: Schema.Literal("recorded"), evidence: Schema.NonEmptyString,
  selector: BaselineSelectorSchema, value: Schema.Finite, repetitions: PositiveInteger,
})
const PendingThresholdSchema = Schema.Struct({
  status: Schema.Literal("pending-review"), absoluteMax: Schema.Null, maxRegressionPercent: Schema.Null,
})
const ApprovedThresholdSchema = Schema.Struct({
  status: Schema.Literal("approved"), absoluteMax: FiniteNonNegative,
  maxRegressionPercent: FiniteNonNegative, approvedBy: Schema.NonEmptyString,
  approvedAt: Schema.String.check(Schema.isPattern(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z$/)),
  evidence: Schema.NonEmptyString,
})
const BudgetMetricSchema = Schema.Union([
  Schema.Struct({ ...commonMetricFields, baseline: MissingBaselineSchema, threshold: PendingThresholdSchema }),
  Schema.Struct({ ...commonMetricFields, baseline: DiagnosticBaselineSchema, threshold: PendingThresholdSchema }),
  Schema.Struct({ ...commonMetricFields, baseline: RecordedBaselineSchema, threshold: PendingThresholdSchema }),
  Schema.Struct({ ...commonMetricFields, baseline: RecordedBaselineSchema, threshold: ApprovedThresholdSchema }),
])
const DiagnosticMetricSchema = Schema.Struct({ ...commonMetricFields, baseline: DiagnosticBaselineSchema })
export const BudgetRegistrySchema = Schema.Struct({
  _tag: Schema.Literal("CrumbsPerformanceBudgetRegistry"),
  version: Schema.Literal(BudgetRegistryVersion),
  status: Schema.Literals(["thresholds-pending-review", "active"]),
  protocol: Schema.Struct({
    minimumIndependentRepetitions: PositiveInteger,
    comparisonStatistic: Schema.Literal("median"),
    noiseEnvelope: Schema.Literal("min-median-max"),
    environmentPolicy: Schema.Literal("exact-or-explicit-equivalence"),
    approvalPolicy: Schema.Literal("reviewer-recorded"),
    unapprovedBehavior: Schema.Literal("incomplete"),
    regressionRule: Schema.Literal("absolute-and-relative-must-pass"),
  }),
  metrics: Schema.Array(BudgetMetricSchema),
  diagnostics: Schema.Array(DiagnosticMetricSchema),
}).check(Schema.makeFilter(registry => {
  const issues: Array<{ path: Array<string | number>; issue: string }> = []
  const seen = new Set<string>()
  registry.metrics.forEach((metric, index) => {
    if (seen.has(metric.id)) issues.push({ path: ["metrics", index, "id"], issue: `Duplicate metric id: ${metric.id}` })
    seen.add(metric.id)
    if (metric.baseline.status === "recorded" && metric.baseline.repetitions < registry.protocol.minimumIndependentRepetitions) {
      issues.push({ path: ["metrics", index, "baseline", "repetitions"], issue: "Recorded baseline has fewer repetitions than the protocol minimum" })
    }
  })
  registry.diagnostics.forEach((metric, index) => {
    if (seen.has(metric.id)) issues.push({ path: ["diagnostics", index, "id"], issue: `Duplicate metric id: ${metric.id}` })
    seen.add(metric.id)
  })
  for (const domain of requiredBudgetDomains) {
    if (!registry.metrics.some(metric => metric.domain === domain)) issues.push({ path: ["metrics"], issue: `Missing required domain: ${domain}` })
  }
  const incomplete = registry.metrics.some(metric => metric.baseline.status !== "recorded" || metric.threshold.status !== "approved")
  if (registry.status === "active" && incomplete) issues.push({ path: ["status"], issue: "Active registry requires recorded baselines and approved thresholds" })
  if (registry.status === "thresholds-pending-review" && !incomplete) issues.push({ path: ["status"], issue: "Fully approved registry must be active" })
  return issues
}))
export type BudgetRegistry = typeof BudgetRegistrySchema.Type
export const budgetRegistryCodec = makeDataCodec("performance-budget-registry", BudgetRegistrySchema)

export function assessBudgetRegistry(registry: BudgetRegistry) {
  const pendingThresholds = registry.metrics.filter(metric => metric.threshold.status === "pending-review").map(metric => metric.id)
  const missingBaselines = registry.metrics.filter(metric => metric.baseline.status === "missing").map(metric => metric.id)
  const diagnosticBaselines = registry.metrics.filter(metric => metric.baseline.status === "diagnostic").map(metric => metric.id)
  return {
    ready: registry.status === "active" && pendingThresholds.length === 0 && missingBaselines.length === 0 && diagnosticBaselines.length === 0,
    pendingThresholds,
    missingBaselines,
    diagnosticBaselines,
    diagnosticOnlyMetrics: registry.diagnostics.map(metric => metric.id),
  }
}

export type BaselineVerificationIssue = {
  readonly id: string
  readonly code: "invalid-evidence-path" | "unreadable-evidence" | "baseline-value-mismatch" | "incomplete-diagnostic-metadata"
  readonly message: string
}

export function verifyRecordedBaselines(registry: BudgetRegistry, repoRoot: string): BaselineVerificationIssue[] {
  const evidenceRoot = resolve(repoRoot, "docs/evidence") + sep
  const issues: BaselineVerificationIssue[] = []
  for (const metric of registry.metrics) {
    if (metric.baseline.status !== "recorded") continue
    const file = resolve(repoRoot, metric.baseline.evidence)
    if (!file.startsWith(evidenceRoot)) {
      issues.push({ id: metric.id, code: "invalid-evidence-path", message: "Recorded evidence must stay under docs/evidence" })
      continue
    }
    try {
      const evidence: unknown = JSON.parse(readFileSync(file, "utf8"))
      const actual = median(extractBaselineSamples(metric.baseline.selector, evidence))
      if (!Object.is(actual, metric.baseline.value)) {
        issues.push({ id: metric.id, code: "baseline-value-mismatch", message: `Recorded ${metric.baseline.value}; evidence resolves to ${actual}` })
      }
    } catch (error) {
      issues.push({ id: metric.id, code: "unreadable-evidence", message: error instanceof Error ? error.message : "Evidence could not be read" })
    }
  }
  return issues
}

export function verifyDiagnosticBaselines(registry: BudgetRegistry, repoRoot: string): BaselineVerificationIssue[] {
  const evidenceRoot = resolve(repoRoot, "docs/evidence") + sep
  const issues: BaselineVerificationIssue[] = []
  for (const metric of [...registry.metrics, ...registry.diagnostics]) {
    if (metric.baseline.status !== "diagnostic") continue
    const hasSelector = metric.baseline.selector !== undefined
    const hasValue = metric.baseline.value !== undefined
    if (hasSelector !== hasValue) {
      issues.push({ id: metric.id, code: "incomplete-diagnostic-metadata", message: "Diagnostic selector and value must be supplied together" })
      continue
    }
    if (!hasSelector || !hasValue) continue
    const file = resolve(repoRoot, metric.baseline.evidence)
    if (!file.startsWith(evidenceRoot)) {
      issues.push({ id: metric.id, code: "invalid-evidence-path", message: "Diagnostic evidence must stay under docs/evidence" })
      continue
    }
    try {
      const evidence: unknown = JSON.parse(readFileSync(file, "utf8"))
      const actual = median(extractBaselineSamples(metric.baseline.selector, evidence))
      if (!Object.is(actual, metric.baseline.value)) {
        issues.push({ id: metric.id, code: "baseline-value-mismatch", message: `Diagnostic ${metric.baseline.value}; evidence resolves to ${actual}` })
      }
    } catch (error) {
      issues.push({ id: metric.id, code: "unreadable-evidence", message: error instanceof Error ? error.message : "Evidence could not be read" })
    }
  }
  return issues
}

type BaselineSelector = typeof BaselineSelectorSchema.Type
type EvidenceBundle = {
  readonly effect: unknown
  readonly runtimeInit: unknown
  readonly benchmark: unknown
  readonly incremental: unknown
  readonly editor: unknown
  readonly runtimeGraph?: unknown
}

export function summarizeBenchmarkReports(inputs: unknown[]) {
  if (inputs.length === 0) throw Error("At least one benchmark report is required")
  const reports = inputs as BenchmarkRunEvidence[]
  const environment = JSON.stringify(reports[0]!.environment)
  const protocol = JSON.stringify(reports[0]!.protocol)
  const fixtures = JSON.stringify(reports[0]!.fixtures)
  const names = reports[0]!.metrics.map(metric => metric.name)
  for (const report of reports) {
    if (JSON.stringify(report.environment) !== environment) throw Error("Benchmark environments differ")
    if (JSON.stringify(report.protocol) !== protocol || JSON.stringify(report.fixtures) !== fixtures) throw Error("Benchmark protocols or fixtures differ")
    if (JSON.stringify(report.metrics.map(metric => metric.name)) !== JSON.stringify(names)) throw Error("Benchmark scenarios differ")
  }
  return {
    formatVersion: 1,
    environment: reports[0]!.environment,
    protocol: reports[0]!.protocol,
    fixtures: reports[0]!.fixtures,
    sourceRevisions: [...new Set(reports.map(report => report.sourceRevision))],
    results: names.map((name, index) => ({
      name,
      sampleKind: reports[0]!.metrics[index]!.sampleKind,
      iterationsPerSample: reports[0]!.metrics[index]!.iterationsPerSample,
      warmupIterations: reports[0]!.metrics[index]!.warmupIterations,
      samplesPerRun: reports[0]!.metrics[index]!.samples,
      runBatchMeanP50Ms: numbers(reports.map(report => report.metrics[index]!.batchMeanP50Ms)),
    })),
  }
}

export function createThresholdReviewPacket(registry: BudgetRegistry, repoRoot: string) {
  const recorded = registry.metrics.flatMap(metric => {
    if (metric.baseline.status !== "recorded") return []
    const evidence = JSON.parse(readFileSync(resolve(repoRoot, metric.baseline.evidence), "utf8")) as unknown
    const samples = extractBaselineSamples(metric.baseline.selector, evidence)
    const envelope = summarizeEnvelope(samples)
    return [{ metric, baseline: metric.baseline, samples, envelope }]
  })
  const candidates = recorded.flatMap(({ metric, baseline, samples, envelope }) => {
    if (metric.threshold.status !== "pending-review") return []
    const maxRegressionPercent = roundUpToFive(Math.max(10, envelope.maxDeviationPercent * 2))
    const unroundedAbsolute = Math.max(envelope.max, envelope.median * (1 + maxRegressionPercent / 100))
    const absoluteMax = metric.unit === "ms" ? Math.ceil(unroundedAbsolute * 1000) / 1000 : Math.ceil(unroundedAbsolute)
    return [{
      id: metric.id, unit: metric.unit, samples: samples.length, baseline: baseline.value, envelope,
      proposal: { status: "candidate-not-approved" as const, absoluteMax, maxRegressionPercent,
        formula: "max(observed max, median plus twice observed deviation or 10 percent); rounded upward" },
    }]
  })
  const approved = recorded.flatMap(({ metric, baseline, samples, envelope }) => metric.threshold.status === "approved" ? [{
    id: metric.id, unit: metric.unit, samples: samples.length, baseline: baseline.value, envelope,
    decision: metric.threshold,
  }] : [])
  return {
    status: candidates.length === 0 ? "recorded-thresholds-approved" as const : "review-required" as const,
    registryStatus: registry.status,
    candidates,
    approved,
    reviewAttention: {
      highNoise: recorded.filter(({ envelope }) => envelope.maxDeviationPercent >= 20).map(({ metric }) => metric.id),
      zeroGrowthPolicy: approved.filter(entry => entry.decision.maxRegressionPercent === 0).map(entry => entry.id),
    },
    blockers: assessBudgetRegistry(registry),
    limits: [
      "Candidates are mechanical review inputs; approved entries preserve reviewer decisions; neither qualifies current performance",
      "High-noise metrics should be isolated or remeasured before approval",
      "Deterministic byte/count metrics need an explicit allowed-growth policy",
    ],
  }
}

export function compareRecordedMetrics(registry: BudgetRegistry, repoRoot: string, current: EvidenceBundle) {
  const metrics = registry.metrics.flatMap(metric => {
    if (metric.baseline.status !== "recorded") return []
    const baselineEvidence = JSON.parse(readFileSync(resolve(repoRoot, metric.baseline.evidence), "utf8")) as unknown
    const currentEvidence = evidenceForSelector(metric.baseline.selector, current)
    const samples = extractBaselineSamples(metric.baseline.selector, currentEvidence)
    const currentEnvelope = summarizeEnvelope(samples)
    const delta = currentEnvelope.median - metric.baseline.value
    const deltaPercent = metric.baseline.value === 0 ? (delta === 0 ? 0 : null) : delta / metric.baseline.value * 100
    const baselineIdentity = comparisonIdentity(metric.baseline.selector, baselineEvidence)
    const currentIdentity = comparisonIdentity(metric.baseline.selector, currentEvidence)
    const environmentDifferences = differingPaths(baselineIdentity.environment, currentIdentity.environment)
    const measurementIdentityDifferences = differingPaths(baselineIdentity.measurement, currentIdentity.measurement)
    const environment = environmentDifferences.length === 0 ? "exact" as const : "mismatch" as const
    const measurementIdentity = measurementIdentityDifferences.length === 0 ? "exact" as const : "mismatch" as const
    let result: "incomplete-environment-mismatch" | "incomplete-measurement-identity-mismatch" | "incomplete-insufficient-repetitions" | "incomplete-threshold-pending" | "pass" | "fail"
    if (environment === "mismatch") result = "incomplete-environment-mismatch"
    else if (measurementIdentity === "mismatch") result = "incomplete-measurement-identity-mismatch"
    else if (samples.length < registry.protocol.minimumIndependentRepetitions) result = "incomplete-insufficient-repetitions"
    else if (metric.threshold.status === "pending-review") result = "incomplete-threshold-pending"
    else result = currentEnvelope.median <= metric.threshold.absoluteMax && deltaPercent !== null && deltaPercent <= metric.threshold.maxRegressionPercent ? "pass" : "fail"
    return [{ id: metric.id, unit: metric.unit, baseline: metric.baseline.value, current: currentEnvelope,
      delta, deltaPercent, environment, environmentDifferences, measurementIdentity, measurementIdentityDifferences,
      thresholdStatus: metric.threshold.status, result }]
  })
  return {
    performanceQualified: assessBudgetRegistry(registry).ready && metrics.length > 0 && metrics.every(metric => metric.result === "pass"),
    metrics,
    reviewAttention: { highNoise: metrics.filter(metric => metric.current.maxDeviationPercent >= 20).map(metric => metric.id) },
    limits: ["Only recorded host/editor metrics are adapted; missing and diagnostic domains remain blockers"],
  }
}

export function compareDiagnosticMetrics(registry: BudgetRegistry, repoRoot: string, current: EvidenceBundle) {
  const metrics = [...registry.metrics, ...registry.diagnostics].flatMap(metric => {
    if (metric.baseline.status !== "diagnostic" || metric.baseline.selector === undefined || metric.baseline.value === undefined) return []
    const baselineEvidence = JSON.parse(readFileSync(resolve(repoRoot, metric.baseline.evidence), "utf8")) as unknown
    const currentEvidence = evidenceForSelector(metric.baseline.selector, current)
    const samples = extractBaselineSamples(metric.baseline.selector, currentEvidence)
    const currentEnvelope = summarizeEnvelope(samples)
    const delta = currentEnvelope.median - metric.baseline.value
    const deltaPercent = metric.baseline.value === 0 ? (delta === 0 ? 0 : null) : delta / metric.baseline.value * 100
    const baselineIdentity = comparisonIdentity(metric.baseline.selector, baselineEvidence)
    const currentIdentity = comparisonIdentity(metric.baseline.selector, currentEvidence)
    const environmentDifferences = differingPaths(baselineIdentity.environment, currentIdentity.environment)
    const measurementIdentityDifferences = differingPaths(baselineIdentity.measurement, currentIdentity.measurement)
    const environment = environmentDifferences.length === 0 ? "exact" as const : "mismatch" as const
    const measurementIdentity = measurementIdentityDifferences.length === 0 ? "exact" as const : "mismatch" as const
    let result: "incomplete-environment-mismatch" | "incomplete-measurement-identity-mismatch" | "incomplete-insufficient-repetitions" | "pass" | "fail"
    if (environment === "mismatch") result = "incomplete-environment-mismatch"
    else if (measurementIdentity === "mismatch") result = "incomplete-measurement-identity-mismatch"
    else if (samples.length < registry.protocol.minimumIndependentRepetitions) result = "incomplete-insufficient-repetitions"
    else result = currentEnvelope.median <= metric.baseline.value && deltaPercent !== null && deltaPercent <= 0 ? "pass" : "fail"
    return [{ id: metric.id, unit: metric.unit, baseline: metric.baseline.value, current: currentEnvelope,
      delta, deltaPercent, environment, environmentDifferences, measurementIdentity, measurementIdentityDifferences,
      result, qualification: "diagnostic-only" as const }]
  })
  return {
    metrics,
    limits: [
      "Diagnostic comparisons preserve historical visibility but never contribute to performance qualification",
      "A diagnostic result uses the retained baseline as a zero-growth reference; current functionality is gated by admitted split metrics",
    ],
  }
}

export function compareRuntimeGraphMetrics(registry: BudgetRegistry, repoRoot: string, currentEvidence: unknown) {
  const runtimeGraphMetrics = registry.metrics.filter(metric => metric.baseline.status === "recorded" &&
    metric.baseline.selector.startsWith("runtime.") && metric.baseline.selector.endsWith(".graph-bytes"))
  const scopedRegistry: BudgetRegistry = { ...registry, metrics: runtimeGraphMetrics }
  const report = compareRecordedMetrics(scopedRegistry, repoRoot, {
    effect: {}, runtimeInit: {}, benchmark: {}, incremental: {}, editor: {}, runtimeGraph: currentEvidence,
  })
  return {
    metrics: report.metrics,
    allPassed: report.metrics.length > 0 && report.metrics.every(metric => metric.result === "pass"),
  }
}

function extractBaselineSamples(selector: BaselineSelector, evidence: unknown): number[] {
  if (selector === "effect.runtime.cjs.graph-bytes") {
    const data = evidence as EffectBoundaryEvidence
    const entries = data.results.filter(entry => entry.scenario === "runtime" && entry.format === "cjs")
    const value = unique(entries.map(entry => entry.graph.bytes))
    return Array.from({ length: Math.max(...entries.map(entry => entry.samples.length)) }, () => value)
  }
  const runtimeGraph = selector.match(/^runtime\.(theme-core|tokens|theme-compatibility)\.(esm|cjs)\.graph-bytes$/)
  if (runtimeGraph) {
    const data = evidence as RuntimeGraphBudgetEvidence
    const scope = runtimeGraph[1]!
    const format = runtimeGraph[2]!
    const entrypoint = scope === "theme-compatibility" ? "theme" : scope
    const graph = data.currentGraphs[entrypoint]?.[format]
    if (!graph) throw Error(`Missing runtime graph scenario: ${selector}`)
    return numbers(graph.samples)
  }
  const runtimeInit = selector.match(/^runtime-init\.(floor|current)\.(esm|cjs)\.load-ms\.median$/)
  if (runtimeInit) {
    const data = evidence as RuntimeInitializationEvidence
    const scenario = data.scenarios.find(entry => entry.runtime === runtimeInit[1] && entry.format === runtimeInit[2])
    if (!scenario) throw Error(`Missing runtime initialization scenario: ${selector}`)
    return numbers(scenario.samples.map(sample => sample.loadMs))
  }
  if (selector === "benchmark.cold-transform.max-median-ms" || selector === "benchmark.warm-transform.max-median-ms") {
    const data = evidence as BenchmarkSummaryEvidence
    const prefix = selector.includes(".cold-") ? "first transform " : "warm transform "
    return maximaByRepetition(data.results.filter(entry => entry.name.startsWith(prefix)).map(entry => entry.runBatchMeanP50Ms))
  }
  if (selector === "metro-incremental.direct-css-edit-ms.median") return admitMetroIncrementalReport(evidence)
  const data = evidence as EditorScaleEvidence
  const compiler = selector.match(/^editor\.(tsc|tsgo)\.10000\.(wall-ms|memory-kib|instantiations)(?:\.median)?$/)
  if (compiler) {
    const runs = data.compilerRuns.filter(entry => entry.engine === compiler[1] && entry.scale === 10000)
    const values = runs.map(entry => compiler[2] === "wall-ms" ? entry.wallMs
      : compiler[2] === "memory-kib" ? entry.diagnostics.memoryKiB : entry.diagnostics.instantiations)
    return numbers(values)
  }
  const completion = selector.match(/^editor\.10000\.(first|warm)-completion-ms\.median$/)
  if (completion) {
    const key = completion[1] === "first" ? "firstCompletionMs" : "warmCompletionMs"
    return numbers(data.completionRuns.filter(entry => entry.scale === 10000).map(entry => entry[key]))
  }
  throw Error(`Unsupported baseline selector: ${selector}`)
}

function evidenceForSelector(selector: BaselineSelector, evidence: EvidenceBundle): unknown {
  if (selector.startsWith("effect.")) return evidence.effect
  if (selector.startsWith("runtime.") && selector.endsWith(".graph-bytes")) return evidence.runtimeGraph
  if (selector.startsWith("runtime-init.")) return evidence.runtimeInit
  if (selector.startsWith("benchmark.")) return evidence.benchmark
  if (selector.startsWith("metro-incremental.")) return evidence.incremental
  return evidence.editor
}

function comparisonIdentity(selector: BaselineSelector, evidence: unknown): { environment: unknown; measurement: unknown } {
  if (selector.startsWith("effect.")) {
    const data = evidence as EffectBoundaryEvidence
    return {
      environment: { environment: { effect: data.effect, platform: data.environment.platform, architecture: data.environment.architecture,
        nodes: [...new Set(data.results.flatMap(entry => entry.samples.map(sample => sample.node)))].sort() } },
      measurement: { build: data.build, protocol: data.protocol },
    }
  }
  if (selector.startsWith("runtime.") && selector.endsWith(".graph-bytes")) {
    const data = evidence as RuntimeGraphBudgetEvidence
    const environment = data.environment as {
      bun?: unknown
      npm?: unknown
      platform?: unknown
      architecture?: unknown
      osRelease?: unknown
      buildTool?: unknown
    }
    return {
      environment: {
        bun: environment.bun,
        npm: environment.npm,
        platform: environment.platform,
        architecture: environment.architecture,
        osRelease: environment.osRelease,
        buildTool: environment.buildTool,
      },
      measurement: { protocol: data.protocol, selector },
    }
  }
  if (selector.startsWith("runtime-init.")) {
    const data = evidence as RuntimeInitializationEvidence
    return {
      environment: { environment: { platform: data.environment.platform, architecture: data.environment.architecture,
        osRelease: data.environment.osRelease, cpu: data.environment.cpu,
        nodes: data.scenarios.map(scenario => ({ runtime: scenario.runtime, format: scenario.format, node: scenario.node })) } },
      measurement: { protocol: data.protocol, repetitions: data.environment.repetitions },
    }
  }
  if (selector.startsWith("benchmark.")) {
    const data = evidence as BenchmarkSummaryEvidence
    const protocol = { ...data.protocol }
    const coldTransform = selector === "benchmark.cold-transform.max-median-ms"
    const warmTransform = selector === "benchmark.warm-transform.max-median-ms"
    const legacyOrdering = "Sequential scenarios in listed order; warmup excluded; filesystem caches uncontrolled"
    const currentOrdering = "Sequential scenarios in listed order; warmup excluded; cold and warm transforms use the same fixture-root process cwd; fixture paths are package-relative; filesystem caches uncontrolled"
    const packageRootWarmOrdering = "Sequential scenarios in listed order; warmup excluded; cold transforms use fixture-root cwd; warm transforms use package-root cwd; fixture paths are package-relative; filesystem caches uncontrolled"
    const warmCwdMode = protocol.warmTransformCwd
    // Package-root mode restores the legacy warm-transform cwd. Normalize it only with its exact
    // recorded ordering; retain fixture, host, sample, and all other protocol checks.
    if (warmTransform && warmCwdMode === "package-root" && protocol.ordering === packageRootWarmOrdering) {
      protocol.ordering = legacyOrdering
      delete protocol.warmTransformCwd
    }
    // The cold worker used fixture-root cwd in both retained protocols; warm cwd does not affect it.
    const coldOrderingMatches = protocol.ordering === legacyOrdering || protocol.ordering === currentOrdering ||
      warmCwdMode === "package-root" && protocol.ordering === packageRootWarmOrdering
    if (coldTransform && coldOrderingMatches) {
      if (warmCwdMode === "fixture-root" && protocol.ordering === currentOrdering ||
        warmCwdMode === "package-root" && protocol.ordering === packageRootWarmOrdering) {
        delete protocol.warmTransformCwd
      }
      protocol.ordering = "cold-transform-sequential-v1"
    }
    return {
      environment: { environment: data.environment },
      measurement: {
        protocol,
        fixtures: data.fixtures.map(fixture => ({ ...fixture, file: normalizeBenchmarkFixturePath(fixture.file) })),
        scenarios: data.results.map(({ name, sampleKind, iterationsPerSample, warmupIterations, samplesPerRun }) =>
          ({ name, sampleKind, iterationsPerSample, warmupIterations, samplesPerRun })),
      },
    }
  }
  if (selector.startsWith("metro-incremental.")) {
    const data = evidence as { environment: unknown; protocol: unknown; fixture: Record<string, unknown>; measurementFixture?: unknown }
    const fixture = data.measurementFixture ?? {
      entrySha256: data.fixture.entrySha256,
      styleSha256: data.fixture.originalStyleSha256,
      tokenSha256: data.fixture.originalTokenSha256,
      baseStyleSha256: data.fixture.originalBaseStyleSha256,
      workspaceTokenSha256: data.fixture.originalWorkspaceTokenSha256,
    }
    return { environment: { environment: data.environment }, measurement: { protocol: data.protocol, fixture } }
  }
  const identity = (evidence as EditorScaleEvidence).identity
  return {
    environment: { identity: { bun: identity.bun, node: identity.node, platform: identity.platform, arch: identity.arch, osRelease: identity.osRelease,
      cpuModel: identity.cpuModel, logicalCpus: identity.logicalCpus, totalMemoryBytes: identity.totalMemoryBytes,
      typescript: identity.typescript, tsgo: identity.tsgo } },
    measurement: {
      protocol: (evidence as EditorScaleEvidence).protocol,
      scales: (evidence as EditorScaleEvidence).manifest.scales.map(({ tokenCount, sourceSha256, sourceBytes, sourceLines }) =>
        ({ tokenCount, sourceSha256, sourceBytes, sourceLines })),
    },
  }
}

function normalizeBenchmarkFixturePath(file: string) {
  const normalized = file.replaceAll("\\", "/")
  const packageMarker = "/packages/css/"
  const packageIndex = normalized.lastIndexOf(packageMarker)
  if (packageIndex >= 0) return normalized.slice(packageIndex + packageMarker.length)
  const relativePackagePrefix = "packages/css/"
  if (normalized.startsWith(relativePackagePrefix)) return normalized.slice(relativePackagePrefix.length)
  return normalized
}

function differingPaths(expected: unknown, actual: unknown, path = ""): string[] {
  if (Object.is(expected, actual)) return []
  if (Array.isArray(expected) && Array.isArray(actual)) {
    const differences = expected.length === actual.length ? [] : [`${path}.length`]
    for (let index = 0; index < Math.min(expected.length, actual.length); index += 1) {
      differences.push(...differingPaths(expected[index], actual[index], `${path}[${index}]`))
    }
    return differences
  }
  if (isRecord(expected) && isRecord(actual)) {
    const differences: string[] = []
    for (const key of [...new Set([...Object.keys(expected), ...Object.keys(actual)])].sort()) {
      differences.push(...differingPaths(expected[key], actual[key], path ? `${path}.${key}` : key))
    }
    return differences
  }
  return [path || "$"]
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value)
}

type EffectBoundaryEvidence = {
  effect: string
  build: unknown
  protocol: unknown
  environment: { platform: string; architecture: string }
  results: Array<{ scenario: string; format: string; graph: { bytes: number }; samples: Array<{ loadMs: number; node: string }> }>
}
type RuntimeGraphBudgetEvidence = {
  sourceRevision: string
  environment: { bun?: unknown; node?: unknown; npm?: unknown; platform?: unknown; architecture?: unknown; osRelease?: unknown; buildTool?: unknown }
  protocol: unknown
  currentGraphs: Record<string, Record<string, { graphBytes: number; samples: number[] }>>
}
type BenchmarkSummaryEvidence = {
  environment: unknown
  protocol: Record<string, unknown>
  fixtures: Array<{ file: string; sha256: string; [key: string]: unknown }>
  results: Array<{ name: string; sampleKind: string; iterationsPerSample: number; warmupIterations: number; samplesPerRun: number; runBatchMeanP50Ms: number[] }>
}
type RuntimeInitializationEvidence = {
  environment: { platform: string; architecture: string; osRelease: string; cpu: string; repetitions: number }
  protocol: string
  scenarios: Array<{ runtime: string; format: string; node: string; samples: Array<{ loadMs: number }> }>
}
type BenchmarkRunEvidence = {
  sourceRevision: string
  environment: unknown
  protocol: unknown
  fixtures: unknown
  metrics: Array<{ name: string; sampleKind: string; iterationsPerSample: number; warmupIterations: number; samples: number; batchMeanP50Ms: number }>
}
type EditorScaleEvidence = {
  identity: { baseRevision?: string; crumbsVersion?: string; bun: string; node: string; platform: string; arch: string; osRelease: string; cpuModel: string; logicalCpus: number; totalMemoryBytes: number; typescript: string; tsgo: string }
  protocol: unknown
  manifest: { scales: Array<{ tokenCount: number; sourceSha256: string; sourceBytes: number; sourceLines: number }>; coverage?: unknown }
  compilerRuns: Array<{ engine: string; scale: number; wallMs: number; diagnostics: { memoryKiB: number; instantiations: number } }>
  completionRuns: Array<{ scale: number; firstCompletionMs: number; warmCompletionMs: number }>
}

function numbers(values: unknown[]): number[] {
  if (values.length === 0 || values.some(value => typeof value !== "number" || !Number.isFinite(value))) throw Error("Evidence selector did not produce finite numbers")
  return values as number[]
}
function median(values: unknown[]): number {
  const sorted = numbers(values).sort((left, right) => left - right)
  return sorted[Math.floor(sorted.length / 2)]!
}
function maximaByRepetition(series: number[][]): number[] {
  if (series.length === 0 || new Set(series.map(values => values.length)).size !== 1) throw Error("Evidence series are absent or have unequal repetition counts")
  return series[0]!.map((_, index) => Math.max(...series.map(values => values[index]!)))
}
function summarizeEnvelope(values: number[]) {
  const valid = numbers(values), middle = median(valid), min = Math.min(...valid), max = Math.max(...valid)
  const maxDeviationPercent = middle === 0 ? 0 : Math.max(Math.abs(min - middle), Math.abs(max - middle)) / Math.abs(middle) * 100
  return { min, median: middle, max, maxDeviationPercent }
}
function roundUpToFive(value: number): number { return Math.ceil(value / 5) * 5 }
function unique(values: unknown[]): number {
  const valid = numbers(values)
  if (new Set(valid).size !== 1) throw Error("Evidence selector did not produce one stable value")
  return valid[0]!
}
