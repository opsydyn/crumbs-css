import { describe, expect, it } from "bun:test"
import { readFileSync } from "node:fs"
import { resolve } from "node:path"
import {
  BudgetRegistryVersion,
  assessBudgetRegistry,
  budgetRegistryCodec,
  compareRuntimeGraphMetrics,
  compareRecordedMetrics,
  compareDiagnosticMetrics,
  createThresholdReviewPacket,
  requiredBudgetDomains,
  summarizeBenchmarkReports,
  verifyDiagnosticBaselines,
  verifyRecordedBaselines,
} from "../bench/budget-contract"

const registryFile = resolve(import.meta.dir, "../bench/budgets.json")

describe("performance budget registry", () => {
  it("admits the committed versioned registry with every required domain exactly once or more", () => {
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    expect(decoded.ok).toBe(true)
    if (!decoded.ok) return
    expect(decoded.value.version).toBe(BudgetRegistryVersion)
    expect(decoded.value.metrics).toHaveLength(25)
    expect(decoded.value.diagnostics).toHaveLength(1)
    const allIds = [...decoded.value.metrics, ...decoded.value.diagnostics].map(metric => metric.id)
    expect(new Set(allIds).size).toBe(allIds.length)
    for (const domain of requiredBudgetDomains) {
      expect(decoded.value.metrics.some(metric => metric.domain === domain)).toBe(true)
    }
  })

  it("reports pending and missing work without manufacturing qualification", () => {
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const assessment = assessBudgetRegistry(decoded.value)
    expect(assessment.ready).toBe(false)
    expect(assessment.pendingThresholds).toHaveLength(4)
    expect(assessment.pendingThresholds).not.toContain("runtime-emitted-bytes")
    expect(assessment.diagnosticOnlyMetrics).toEqual(["runtime-emitted-bytes"])
    expect(assessment.diagnosticBaselines).toEqual(["retained-memory-bytes"])
    expect(assessment.missingBaselines).toEqual(expect.arrayContaining([
      "js-frame-time", "ui-frame-time", "allocation-bytes",
    ]))
  })

  it("re-derives every recorded baseline from retained evidence", () => {
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    expect(verifyRecordedBaselines(decoded.value, resolve(import.meta.dir, "../../.."))).toEqual([])
    const metric = decoded.value.metrics.find(candidate => candidate.baseline.status === "recorded")
    if (!metric || metric.baseline.status !== "recorded") throw Error("Expected a recorded baseline")
    const drifted = {
      ...decoded.value,
      metrics: decoded.value.metrics.map(candidate => candidate.id === metric.id && candidate.baseline.status === "recorded"
        ? { ...candidate, baseline: { ...candidate.baseline, value: candidate.baseline.value + 1 } }
        : candidate),
    }
    expect(verifyRecordedBaselines(drifted, resolve(import.meta.dir, "../../.."))).toEqual([
      expect.objectContaining({ id: metric.id, code: "baseline-value-mismatch" }),
    ])
  })

  it("admits the split runtime graph selectors from the retained admission evidence", () => {
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const graphMetrics = decoded.value.metrics.filter(metric => metric.id.startsWith("runtime-theme-") || metric.id.startsWith("runtime-tokens-"))
    expect(graphMetrics.map(metric => metric.id)).toEqual([
      "runtime-theme-core-esm-graph-bytes",
      "runtime-theme-core-cjs-graph-bytes",
      "runtime-tokens-esm-graph-bytes",
      "runtime-tokens-cjs-graph-bytes",
      "runtime-theme-compatibility-esm-graph-bytes",
      "runtime-theme-compatibility-cjs-graph-bytes",
    ])
    for (const metric of graphMetrics) {
      expect(metric.baseline.status).toBe("recorded")
      expect(metric.threshold).toMatchObject({ status: "approved", maxRegressionPercent: 0 })
    }
    expect(verifyRecordedBaselines(decoded.value, resolve(import.meta.dir, "../../.."))).toEqual([])
  })

  it("keeps the historical compatibility graph as a verified diagnostic", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const metric = decoded.value.diagnostics.find(candidate => candidate.id === "runtime-emitted-bytes")
    if (!metric) throw Error("Expected the historical metric to be diagnostic-only")
    expect(metric.baseline).toMatchObject({
      evidence: "docs/evidence/2026-09-14-effect-boundary-audit/audit.json",
      selector: "effect.runtime.cjs.graph-bytes",
      value: 11307,
      repetitions: 5,
    })
    expect(verifyDiagnosticBaselines(decoded.value, repoRoot)).toEqual([])
    const assessment = assessBudgetRegistry(decoded.value)
    expect(assessment.diagnosticOnlyMetrics).toContain("runtime-emitted-bytes")
    expect(assessment.pendingThresholds).not.toContain("runtime-emitted-bytes")

    const effect = JSON.parse(readFileSync(resolve(repoRoot,
      "docs/evidence/2026-09-21-m4-6-full-host-comparison/effect.json"), "utf8"))
    const diagnostic = compareDiagnosticMetrics(decoded.value, repoRoot, {
      effect,
      runtimeInit: {},
      benchmark: {},
      incremental: {},
      editor: {},
    })
    expect(diagnostic.metrics).toHaveLength(1)
    expect(diagnostic.metrics[0]).toMatchObject({ id: "runtime-emitted-bytes", result: "fail", delta: 33457, deltaPercent: 295.8963473954188 })
  })

  it("adopts the expanded Metro invalidation protocol without weakening its approved ceiling", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const metric = decoded.value.metrics.find(candidate => candidate.id === "incremental-rebuild")
    if (!metric || metric.baseline.status !== "recorded" || metric.threshold.status !== "approved") {
      throw Error("Expected the reconciled incremental metric")
    }
    expect(metric.baseline.evidence).toBe("docs/evidence/2026-09-21-m4-6-incremental-baseline/metro-incremental.json")
    expect(metric.baseline.value).toBe(123.95049999999901)
    expect(metric.threshold).toMatchObject({ absoluteMax: 137.506, maxRegressionPercent: 10 })
    const evidence = JSON.parse(readFileSync(resolve(repoRoot, metric.baseline.evidence), "utf8"))
    expect(evidence.dependencyControls).toHaveLength(3)
    expect(evidence.protocol.cacheState).toContain("three dependency-only controls")
    expect(verifyRecordedBaselines(decoded.value, repoRoot)).toEqual([])
  })

  it("fails closed on unknown versions, fields, invalid repetition counts and duplicate ids", () => {
    const valid = JSON.parse(readFileSync(registryFile, "utf8"))
    for (const mutation of [
      { ...valid, version: BudgetRegistryVersion + 1 },
      { ...valid, version: 1 },
      { ...valid, unknown: true },
      { ...valid, protocol: { ...valid.protocol, minimumIndependentRepetitions: 0 } },
      { ...valid, metrics: [...valid.metrics, valid.metrics[0]] },
      { ...valid, diagnostics: [...valid.diagnostics, { ...valid.diagnostics[0], id: valid.metrics[0].id }] },
      { ...valid, diagnostics: valid.diagnostics.map((metric: object) => ({ ...metric, threshold: { status: "pending-review" } })) },
      { ...valid, metrics: valid.metrics.filter((metric: { domain: string }) => metric.domain !== "runtime-footprint") },
      { ...valid, metrics: valid.metrics.map((metric: { baseline: { status: string } }, index: number) => index === 5
        ? { ...metric, baseline: { ...metric.baseline, repetitions: 4 } } : metric) },
    ]) expect(budgetRegistryCodec.decode(mutation).ok).toBe(false)
  })

  it("requires recorded baselines and concrete limits before a threshold can be approved", () => {
    const valid = JSON.parse(readFileSync(registryFile, "utf8"))
    const metric = valid.metrics.find((candidate: { id: string }) => candidate.id === "editor-first-completion-10000")
    expect(metric).toBeDefined()
    for (const replacement of [
      { ...metric, threshold: { status: "approved", absoluteMax: null, maxRegressionPercent: null } },
      { ...metric, baseline: { status: "missing", reason: "removed for test" }, threshold: { status: "approved", absoluteMax: 50, maxRegressionPercent: 15 } },
    ]) {
      const mutated = { ...valid, metrics: valid.metrics.map((candidate: { id: string }) => candidate.id === metric.id ? replacement : candidate) }
      expect(budgetRegistryCodec.decode(mutated).ok).toBe(false)
    }
  })

  it("admits an active registry only when every baseline and threshold is qualified", () => {
    const valid = JSON.parse(readFileSync(registryFile, "utf8"))
    const active = {
      ...valid,
      status: "active",
      metrics: valid.metrics.map((metric: { baseline: { status: string }; threshold: unknown }) => ({
        ...metric,
        baseline: metric.baseline.status === "recorded" ? metric.baseline : {
          status: "recorded", evidence: "docs/evidence/test.json", selector: "effect.runtime.cjs.graph-bytes", value: 1, repetitions: 5,
        },
        threshold: {
          status: "approved", absoluteMax: 2, maxRegressionPercent: 10,
          approvedBy: "test reviewer", approvedAt: "2026-09-15T09:00:00Z", evidence: "test/review.md",
        },
      })),
    }
    const decoded = budgetRegistryCodec.decode(active)
    expect(decoded.ok).toBe(true)
    if (!decoded.ok) return
    expect(assessBudgetRegistry(decoded.value).ready).toBe(true)
    expect(assessBudgetRegistry(decoded.value).diagnosticOnlyMetrics).toEqual(["runtime-emitted-bytes"])
    active.metrics[0].threshold = { status: "pending-review", absoluteMax: null, maxRegressionPercent: null }
    expect(budgetRegistryCodec.decode(active).ok).toBe(false)
  })

  it("separates registry validation from activation readiness at the CLI boundary", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const script = resolve(repoRoot, "scripts/performance-budgets.ts")
    const validate = Bun.spawnSync([process.execPath, script, "validate"], { cwd: repoRoot })
    expect(validate.exitCode).toBe(0)
    expect(JSON.parse(validate.stdout.toString())).toMatchObject({
      valid: true,
      registryReady: false,
      performanceQualification: "not-run",
      metrics: 25,
      diagnosticOnlyMetrics: ["runtime-emitted-bytes"],
    })
    const readiness = Bun.spawnSync([process.execPath, script, "readiness"], { cwd: repoRoot })
    expect(readiness.exitCode).toBe(1)
    expect(JSON.parse(readiness.stdout.toString())).toMatchObject({ valid: true, registryReady: false, performanceQualification: "not-run" })
  })

  it("separates approved decisions from pending threshold candidates", () => {
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const packet = createThresholdReviewPacket(decoded.value, resolve(import.meta.dir, "../../.."))
    expect(packet.status).toBe("recorded-thresholds-approved")
    expect(packet.candidates).toHaveLength(0)
    expect(packet.approved).toHaveLength(21)
    expect(packet.approved.find(entry => entry.id === "incremental-rebuild")?.decision).toMatchObject({
      status: "approved", absoluteMax: 137.506, maxRegressionPercent: 10,
    })
    expect(packet.reviewAttention.highNoise).toContain("runtime-initialization-node22-cjs")
    expect(packet.reviewAttention.zeroGrowthPolicy).toEqual(expect.arrayContaining([
      "editor-tsc-instantiations-10000", "editor-tsgo-instantiations-10000",
      "runtime-theme-core-esm-graph-bytes", "runtime-theme-core-cjs-graph-bytes",
      "runtime-tokens-esm-graph-bytes", "runtime-tokens-cjs-graph-bytes",
      "runtime-theme-compatibility-esm-graph-bytes", "runtime-theme-compatibility-cjs-graph-bytes",
    ]))
    for (const approved of packet.approved) {
      expect(approved.samples).toBeGreaterThanOrEqual(5)
      expect(approved.envelope.median).toBe(approved.baseline)
      expect(approved.decision.status).toBe("approved")
    }
  })

  it("passes approved recorded metrics without manufacturing whole-registry qualification", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const report = compareRecordedMetrics(decoded.value, repoRoot, {
      effect: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-14-effect-boundary-audit/audit.json"), "utf8")),
      runtimeInit: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-15-runtime-initialization/baseline.json"), "utf8")),
      benchmark: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-14-benchmark-repair/adapter-summary.json"), "utf8")),
      incremental: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-21-m4-6-incremental-baseline/metro-incremental.json"), "utf8")),
      editor: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-15-editor-scale/raw.json"), "utf8")),
      runtimeGraph: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-21-m4-6-runtime-byte-budget-admission/admission.json"), "utf8")),
    })
    expect(report.performanceQualified).toBe(false)
    expect(report.metrics).toHaveLength(21)
    for (const metric of report.metrics) {
      expect(metric.environment).toBe("exact")
      expect(metric.delta).toBe(0)
      expect(metric.result).toBe("pass")
    }
  })

  it("compares split runtime graphs independently of the current source revision", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const admission = JSON.parse(readFileSync(resolve(repoRoot,
      "docs/evidence/2026-09-21-m4-6-runtime-byte-budget-admission/admission.json"), "utf8"))
    const current = {
      ...admission,
      sourceRevision: "current-working-tree",
      environment: { ...admission.environment, node: "v26.3.0" },
    }
    const report = compareRuntimeGraphMetrics(decoded.value, repoRoot, current)
    expect(report.metrics).toHaveLength(6)
    expect(report.allPassed).toBe(true)
    expect(report.metrics.every(metric => metric.environment === "exact" && metric.result === "pass")).toBe(true)

    const regressed = {
      ...current,
      currentGraphs: {
        ...current.currentGraphs,
        "theme-core": {
          ...current.currentGraphs["theme-core"],
          esm: {
            ...current.currentGraphs["theme-core"].esm,
            samples: current.currentGraphs["theme-core"].esm.samples.map((value: number) => value + 1),
          },
        },
      },
    }
    const failed = compareRuntimeGraphMetrics(decoded.value, repoRoot, regressed)
    expect(failed.metrics.find(metric => metric.id === "runtime-theme-core-esm-graph-bytes")?.result).toBe("fail")
    expect(failed.allPassed).toBe(false)
  })

  it("adapts independent benchmark reports only when their environments and scenarios agree", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const reports = [1, 2, 3, 4, 5].map(index => JSON.parse(readFileSync(resolve(repoRoot,
      `docs/evidence/2026-09-14-benchmark-repair/run-${index}.json`), "utf8")))
    const summary = summarizeBenchmarkReports(reports)
    expect(summary.environment).toEqual(reports[0].environment)
    expect(summary.results).toHaveLength(10)
    expect(summary.results.every(result => result.runBatchMeanP50Ms.length === 5)).toBe(true)
    expect(() => summarizeBenchmarkReports([reports[0], { ...reports[1], environment: { ...reports[1].environment, bun: "different" } }])).toThrow()
  })

  it("rejects editor comparisons when the generated scenario manifest changes", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const editor = JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-15-editor-scale/raw.json"), "utf8"))
    const report = compareRecordedMetrics(decoded.value, repoRoot, {
      effect: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-14-effect-boundary-audit/audit.json"), "utf8")),
      runtimeInit: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-15-runtime-initialization/baseline.json"), "utf8")),
      benchmark: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-14-benchmark-repair/adapter-summary.json"), "utf8")),
      incremental: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-21-m4-6-incremental-baseline/metro-incremental.json"), "utf8")),
      editor: { ...editor, manifest: { ...editor.manifest, scales: [] } },
      runtimeGraph: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-21-m4-6-runtime-byte-budget-admission/admission.json"), "utf8")),
    })
    const editorMetrics = report.metrics.filter(metric => metric.id.startsWith("editor-"))
    expect(editorMetrics.every(metric => metric.result === "incomplete-measurement-identity-mismatch")).toBe(true)
    expect(editorMetrics.every(metric => metric.environment === "exact" && metric.measurementIdentity === "mismatch")).toBe(true)
    expect(editorMetrics.every(metric => metric.measurementIdentityDifferences.includes("scales.length"))).toBe(true)
  })

  it("compares editor workload identity independently of source revision and coverage provenance", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const editor = JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-15-editor-scale/raw.json"), "utf8"))
    const evidence = {
      effect: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-14-effect-boundary-audit/audit.json"), "utf8")),
      runtimeInit: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-15-runtime-initialization/baseline.json"), "utf8")),
      benchmark: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-14-benchmark-repair/adapter-summary.json"), "utf8")),
      incremental: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-21-m4-6-incremental-baseline/metro-incremental.json"), "utf8")),
      editor: {
        ...editor,
        identity: { ...editor.identity, baseRevision: "new-revision", crumbsVersion: "new-version" },
        manifest: { ...editor.manifest, coverage: { ...editor.manifest.coverage, conditions: "implemented API; excluded from this fixture" } },
      },
      runtimeGraph: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-21-m4-6-runtime-byte-budget-admission/admission.json"), "utf8")),
    }
    const report = compareRecordedMetrics(decoded.value, repoRoot, evidence)
    const editorMetrics = report.metrics.filter(metric => metric.id.startsWith("editor-"))
    expect(editorMetrics.every(metric => metric.measurementIdentity === "exact")).toBe(true)
    expect(editorMetrics.every(metric => metric.measurementIdentityDifferences.length === 0)).toBe(true)

    const changedInput = { ...evidence, editor: { ...evidence.editor, manifest: {
      ...evidence.editor.manifest,
      scales: evidence.editor.manifest.scales.map((scale: { sourceSha256: string }, index: number) => index === 0
        ? { ...scale, sourceSha256: "changed" }
        : scale),
    } } }
    const changed = compareRecordedMetrics(decoded.value, repoRoot, changedInput)
    const changedMetrics = changed.metrics.filter(metric => metric.id.startsWith("editor-"))
    expect(changedMetrics.every(metric => metric.measurementIdentity === "mismatch")).toBe(true)
  })

  it("compares Metro measurement inputs separately from restored working-tree fixtures", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const baseline = JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-21-m4-6-incremental-baseline/metro-incremental.json"), "utf8"))
    const current = {
      ...baseline,
      measurementFixture: {
        entrySha256: baseline.fixture.entrySha256,
        styleSha256: baseline.fixture.originalStyleSha256,
        tokenSha256: baseline.fixture.originalTokenSha256,
        baseStyleSha256: baseline.fixture.originalBaseStyleSha256,
        workspaceTokenSha256: baseline.fixture.originalWorkspaceTokenSha256,
      },
      fixture: {
        ...baseline.fixture,
        originalStyleSha256: "a".repeat(64),
        restoredStyleSha256: "a".repeat(64),
        originalWorkspaceTokenSha256: "b".repeat(64),
        restoredWorkspaceTokenSha256: "b".repeat(64),
      },
    }
    const evidence = {
      effect: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-14-effect-boundary-audit/audit.json"), "utf8")),
      runtimeInit: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-15-runtime-initialization/baseline.json"), "utf8")),
      benchmark: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-14-benchmark-repair/adapter-summary.json"), "utf8")),
      incremental: current,
      editor: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-15-editor-scale/raw.json"), "utf8")),
      runtimeGraph: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-21-m4-6-runtime-byte-budget-admission/admission.json"), "utf8")),
    }
    const metric = () => compareRecordedMetrics(decoded.value, repoRoot, evidence).metrics.find(candidate => candidate.id === "incremental-rebuild")
    expect(metric()).toMatchObject({ environment: "exact", measurementIdentity: "exact", measurementIdentityDifferences: [] })

    evidence.incremental = { ...current, measurementFixture: { ...current.measurementFixture, styleSha256: "c".repeat(64) } }
    expect(metric()).toMatchObject({ environment: "exact", measurementIdentity: "mismatch" })
  })

  it("qualifies the retained M10.5 Metro/editor identity-repair measurements against unchanged limits", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const hostBudgetRoot = resolve(repoRoot, "docs/evidence/2026-10-04-m10-5-metro-editor-identity/host-budgets")
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const evidence = {
      effect: JSON.parse(readFileSync(resolve(hostBudgetRoot, "effect.json"), "utf8")),
      runtimeInit: JSON.parse(readFileSync(resolve(hostBudgetRoot, "runtime-initialization.json"), "utf8")),
      benchmark: JSON.parse(readFileSync(resolve(hostBudgetRoot, "benchmark-summary.json"), "utf8")),
      incremental: JSON.parse(readFileSync(resolve(hostBudgetRoot, "metro-incremental.json"), "utf8")),
      editor: JSON.parse(readFileSync(resolve(hostBudgetRoot, "editor.json"), "utf8")),
      runtimeGraph: JSON.parse(readFileSync(resolve(hostBudgetRoot, "runtime-graph.json"), "utf8")),
    }
    const report = compareRecordedMetrics(decoded.value, repoRoot, evidence)
    const repaired = report.metrics.filter(metric => metric.id === "incremental-rebuild" || metric.id.startsWith("editor-"))
    expect(repaired).toHaveLength(9)
    expect(repaired.every(metric => metric.environment === "exact" && metric.measurementIdentity === "exact" &&
      metric.measurementIdentityDifferences.length === 0 && metric.result === "pass")).toBe(true)
    expect(report.metrics.filter(metric => metric.result === "incomplete-environment-mismatch" ||
      metric.result === "incomplete-measurement-identity-mismatch")).toHaveLength(0)
    expect(report.metrics.filter(metric => metric.result === "pass")).toHaveLength(10)
    expect(report.metrics.filter(metric => metric.result === "fail")).toHaveLength(11)
  })

  it("separates host differences from measurement identity and compares equivalent cold-transform evidence", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const hostBudgetRoot = resolve(repoRoot, "docs/evidence/2026-10-01-m10-5-final/host-budgets")
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const evidence = {
      effect: JSON.parse(readFileSync(resolve(hostBudgetRoot, "effect.json"), "utf8")),
      runtimeInit: JSON.parse(readFileSync(resolve(hostBudgetRoot, "runtime-initialization.json"), "utf8")),
      benchmark: JSON.parse(readFileSync(resolve(hostBudgetRoot, "benchmark-summary.json"), "utf8")),
      incremental: JSON.parse(readFileSync(resolve(hostBudgetRoot, "metro-incremental.json"), "utf8")),
      editor: JSON.parse(readFileSync(resolve(hostBudgetRoot, "editor.json"), "utf8")),
      runtimeGraph: JSON.parse(readFileSync(resolve(hostBudgetRoot, "runtime-graph.json"), "utf8")),
    }
    const report = compareRecordedMetrics(decoded.value, repoRoot, evidence)
    const metric = (id: string) => report.metrics.find(candidate => candidate.id === id)

    expect(metric("cold-transform-ms")).toMatchObject({
      result: "pass",
      environment: "exact",
      environmentDifferences: [],
      measurementIdentity: "exact",
      measurementIdentityDifferences: [],
    })
    expect(metric("warm-transform-ms")).toMatchObject({
      result: "incomplete-measurement-identity-mismatch",
      environment: "exact",
      measurementIdentity: "mismatch",
      measurementIdentityDifferences: ["protocol.ordering"],
    })

    const incremental = metric("incremental-rebuild")
    expect(incremental).toMatchObject({ result: "incomplete-environment-mismatch", environment: "mismatch" })
    expect(incremental?.environmentDifferences).toContain("environment.expo")
    expect(incremental?.measurementIdentityDifferences).toContain("protocol.cacheState")
    expect(incremental?.measurementIdentityDifferences).toContain("fixture.styleSha256")

    const editor = metric("editor-tsc-wall-10000")
    expect(editor).toMatchObject({
      result: "incomplete-measurement-identity-mismatch",
      environment: "exact",
      measurementIdentity: "mismatch",
    })
    expect(editor?.measurementIdentityDifferences).toContain("scales[0].sourceSha256")
  })

  it("matches warm transforms only for the exact historical package-root protocol", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const hostBudgetRoot = resolve(repoRoot, "docs/evidence/2026-10-01-m10-5-final/host-budgets")
    const decoded = budgetRegistryCodec.decodeJson(readFileSync(registryFile, "utf8"))
    if (!decoded.ok) throw Error("Committed budget registry must decode")
    const benchmark = JSON.parse(readFileSync(resolve(hostBudgetRoot, "benchmark-summary.json"), "utf8"))
    const evidence = {
      effect: JSON.parse(readFileSync(resolve(hostBudgetRoot, "effect.json"), "utf8")),
      runtimeInit: JSON.parse(readFileSync(resolve(hostBudgetRoot, "runtime-initialization.json"), "utf8")),
      benchmark,
      incremental: JSON.parse(readFileSync(resolve(hostBudgetRoot, "metro-incremental.json"), "utf8")),
      editor: JSON.parse(readFileSync(resolve(hostBudgetRoot, "editor.json"), "utf8")),
      runtimeGraph: JSON.parse(readFileSync(resolve(hostBudgetRoot, "runtime-graph.json"), "utf8")),
    }
    const compare = (candidate: typeof benchmark) => compareRecordedMetrics(decoded.value, repoRoot, {
      ...evidence,
      benchmark: candidate,
    })
    const packageRootBenchmark = {
      ...benchmark,
      protocol: {
        ...benchmark.protocol,
        ordering: "Sequential scenarios in listed order; warmup excluded; cold transforms use fixture-root cwd; warm transforms use package-root cwd; fixture paths are package-relative; filesystem caches uncontrolled",
        warmTransformCwd: "package-root",
      },
    }
    const matched = compare(packageRootBenchmark)
    expect(matched.metrics.find(metric => metric.id === "warm-transform-ms")).toMatchObject({
      environment: "exact",
      measurementIdentity: "exact",
      measurementIdentityDifferences: [],
    })
    expect(matched.metrics.find(metric => metric.id === "cold-transform-ms")?.measurementIdentity).toBe("exact")

    const fixtureRootBenchmark = {
      ...packageRootBenchmark,
      protocol: { ...packageRootBenchmark.protocol, warmTransformCwd: "fixture-root" },
    }
    expect(compare(fixtureRootBenchmark).metrics.find(metric => metric.id === "warm-transform-ms"))
      .toMatchObject({ measurementIdentity: "mismatch" })

    const changedFixtureBenchmark = {
      ...packageRootBenchmark,
      fixtures: packageRootBenchmark.fixtures.map((fixture: { sha256: string }, index: number) => index === 0
        ? { ...fixture, sha256: "changed-fixture-digest" }
        : fixture),
    }
    expect(compare(changedFixtureBenchmark).metrics.find(metric => metric.id === "warm-transform-ms")?.measurementIdentityDifferences)
      .toContain("fixtures[0].sha256")
  })

  it("requires both approved absolute and relative limits to pass", () => {
    const repoRoot = resolve(import.meta.dir, "../../..")
    const valid = JSON.parse(readFileSync(registryFile, "utf8"))
    const approved = { ...valid, metrics: valid.metrics.map((metric: { baseline: { status: string; value?: number } }) =>
      metric.baseline.status === "recorded" ? { ...metric, threshold: {
        status: "approved", absoluteMax: metric.baseline.value, maxRegressionPercent: 0,
        approvedBy: "test reviewer", approvedAt: "2026-09-15T09:00:00Z", evidence: "test/review.md",
      } } : metric) }
    const decoded = budgetRegistryCodec.decode(approved)
    if (!decoded.ok) throw Error("Approved recorded metrics must decode")
    const evidence = {
      effect: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-14-effect-boundary-audit/audit.json"), "utf8")),
      runtimeInit: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-15-runtime-initialization/baseline.json"), "utf8")),
      benchmark: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-14-benchmark-repair/adapter-summary.json"), "utf8")),
      incremental: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-21-m4-6-incremental-baseline/metro-incremental.json"), "utf8")),
      editor: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-15-editor-scale/raw.json"), "utf8")),
      runtimeGraph: JSON.parse(readFileSync(resolve(repoRoot, "docs/evidence/2026-09-21-m4-6-runtime-byte-budget-admission/admission.json"), "utf8")),
    }
    expect(compareRecordedMetrics(decoded.value, repoRoot, evidence).metrics.every(metric => metric.result === "pass")).toBe(true)
    approved.metrics.find((metric: { id: string }) => metric.id === "runtime-theme-core-esm-graph-bytes").threshold.absoluteMax = 0
    const failed = budgetRegistryCodec.decode(approved)
    if (!failed.ok) throw Error("Tightened threshold must decode")
    expect(compareRecordedMetrics(failed.value, repoRoot, evidence).metrics.find(metric => metric.id === "runtime-theme-core-esm-graph-bytes")?.result).toBe("fail")
  })
})
