import { readFile } from "node:fs/promises"
import { auditPackedRuntimeEntrypoints } from "./packed-runtime-graph"
if(import.meta.main){
  const [command,requestPath,...extra]=process.argv.slice(2)
  if(command!=="audit-build"||!requestPath||extra.length)throw Error("Expected audit-build /absolute/request.json")
  const request=JSON.parse(await readFile(requestPath,"utf8"))
  if(!request.packageRoot?.startsWith("/")||!/^[a-f0-9]{64}$/.test(request.generation))throw Error("Invalid build audit request")
  console.log(JSON.stringify({generation:request.generation,entries:await auditPackedRuntimeEntrypoints(request.packageRoot)}))
}
