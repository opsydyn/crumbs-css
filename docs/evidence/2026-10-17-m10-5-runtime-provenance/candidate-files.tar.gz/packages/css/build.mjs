import { mkdtemp,readFile,writeFile,rm,open,lstat,realpath } from "node:fs/promises"
import { join,resolve } from "node:path"
import { tmpdir } from "node:os"
import { createHash,randomUUID } from "node:crypto"
import { createRequire } from "node:module"
import { fileURLToPath } from "node:url"
import { spawnSync } from "node:child_process"
import { canonicalProvenanceBytes,parseProvenancePolicy } from "./build/provenance-contract.mjs"
import { collectBuildInputs,finalizeProvenanceBuild,inspectCapturedBuild } from "./build/provenance-finalize.mjs"
const owners=["extensions","algebra","motion","motion-native","containers","theme","core","theme-token","tools","devtools"]
const hash=value=>createHash("sha256").update(value).digest("hex")
export async function runPackageBuild({packageRoot,repositoryRoot,bun,runBuild,observeOnly=false}){
  packageRoot=await realpath(packageRoot);repositoryRoot=await realpath(repositoryRoot)
  const lock=join(packageRoot,".runtime-provenance.lock"),nonce=randomUUID();let handle
  try{handle=await open(lock,"wx")}catch(e){throw Error("Concurrent build or foreign provenance lock",{cause:e})}
  const previous=process.env.CRUMBS_INTERNAL_PROVENANCE_SESSION;let sessionRoot
  try{
    await handle.writeFile(nonce);await handle.close();handle=null
    for(const file of ["runtime-provenance.json",".runtime-provenance-pending"]){
      const p=join(packageRoot,"dist",file)
      try{if((await lstat(p)).isSymbolicLink())throw Error(`Receipt symlink ${p}`);await rm(p)}catch(e){if(e.code!=="ENOENT")throw e}
    }
    const beforeInputs=await collectBuildInputs(repositoryRoot,packageRoot)
    const require=createRequire(import.meta.url)
    const tools=[]
    for(const name of ["tsdown","rolldown"]){
      let entry=(name==="rolldown"?createRequire(require.resolve("tsdown")):require).resolve(name),dir=entry
      const {dirname}=await import("node:path")
      for(;;){dir=dirname(dir);try{const p=JSON.parse(await readFile(join(dir,"package.json"),"utf8"));if(p.name===name){tools.push({name,version:p.version});break}}catch{}
        if(dirname(dir)===dir)throw Error(`Missing build tool identity ${name}`)}
    }
    const child=spawnSync(bun,["--version"],{encoding:"utf8"});if(child.status!==0)throw Error("Cannot read Bun version")
    tools.push({name:typeof Bun==="undefined"?"node-host":"bun-host",version:typeof Bun==="undefined"?process.version:Bun.version},{name:"bun-auditor",version:child.stdout.trim()})
    const generation=hash(canonicalProvenanceBytes({inputs:beforeInputs,tools}))
    sessionRoot=await mkdtemp(join(tmpdir(),"crumbs-provenance-session-"))
    await writeFile(join(sessionRoot,"session.json"),JSON.stringify({packageRoot,repositoryRoot,generation,tools,nonce,observeOnly}))
    process.env.CRUMBS_INTERNAL_PROVENANCE_SESSION=sessionRoot
    const build=runBuild??(await import("tsdown")).build
    await build({config:join(packageRoot,"tsdown.config.ts"),cwd:packageRoot})
    const input={packageRoot,repositoryRoot,sessionRoot,generation,beforeInputs,expectedOwners:owners,bun}
    if(observeOnly){
      // Observation is not admission: retain raw evidence and never emit a final sidecar.
      const result=await inspectCapturedBuild(input)
      console.log(JSON.stringify({status:"observed-not-qualified",sessionRoot,generation,artifacts:result.artifacts.length}))
      return {sessionRoot,generation}
    }
    const policy=parseProvenancePolicy(await readFile(join(packageRoot,"build/runtime-provenance-policy.json")))
    await finalizeProvenanceBuild({...input,policy})
  }catch(error){
    await rm(join(packageRoot,"dist/runtime-provenance.json"),{force:true})
    throw error
  }finally{
    if(previous===undefined)delete process.env.CRUMBS_INTERNAL_PROVENANCE_SESSION;else process.env.CRUMBS_INTERNAL_PROVENANCE_SESSION=previous
    if(sessionRoot&&!observeOnly){const marker=JSON.parse(await readFile(join(sessionRoot,"session.json"),"utf8"));if(marker.nonce===nonce)await rm(sessionRoot,{recursive:true})}
    if(handle)await handle.close()
    if(await readFile(lock,"utf8")===nonce)await rm(lock)
  }
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const packageRoot=fileURLToPath(new URL(".",import.meta.url)),repositoryRoot=resolve(packageRoot,"../..")
  await runPackageBuild({packageRoot,repositoryRoot,bun:process.env.CRUMBS_AUDIT_BUN??"bun",observeOnly:process.argv.includes("--observe-provenance")})
}
