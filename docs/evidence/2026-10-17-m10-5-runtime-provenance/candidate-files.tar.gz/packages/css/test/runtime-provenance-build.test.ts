import { describe,expect,test } from "bun:test"
import { mkdtemp,mkdir,writeFile,readFile,readdir,rm,symlink } from "node:fs/promises"
import { tmpdir } from "node:os"
import { join } from "node:path"
const owners=["extensions","algebra","motion","motion-native","containers","theme","core","theme-token","tools","devtools"]
async function modules(){
 const load=async(p:string)=>{try{return await import(p)}catch(e){if((e as Error).message.includes("Cannot find"))return {};throw e}}
 return {...await load(import.meta.resolve("../build.mjs")),...await load(import.meta.resolve("../build/provenance-capture.mjs"))}
}
async function fixture(){
 const root=await mkdtemp(join(tmpdir(),"crumbs-provenance-build-test-"));const pkg=join(root,"packages/css")
 await mkdir(join(pkg,"src"),{recursive:true});await mkdir(join(pkg,"build"));await mkdir(join(root,"scripts"))
 await writeFile(join(root,"bun.lock"),"fixture-lock\n");await writeFile(join(pkg,"src/runtime.ts"),"export const value=1\n")
 await writeFile(join(pkg,"package.json"),JSON.stringify({name:"@opsydyn/crumbs-css",version:"1.2.0",type:"module",exports:{"./tokens":{import:"./dist/tools.mjs",require:"./dist/tools.cjs"}}}))
 await writeFile(join(pkg,"tsdown.config.ts"),"export default []\n")
 await writeFile(join(pkg,"build/runtime-provenance-policy.json"),JSON.stringify({schema:"crumbs.runtime-provenance-policy.v1",runtimeSources:["src/runtime.ts"],helpers:[]}))
 return {root,pkg,cleanup:()=>rm(root,{recursive:true,force:true})}
}
async function emit(m:any,f:any,options:{skip?:string,wrongGeneration?:boolean,lateMutation?:boolean}={}) {
 const session=process.env.CRUMBS_INTERNAL_PROVENANCE_SESSION!;const marker=JSON.parse(await readFile(join(session,"session.json"),"utf8"))
 await mkdir(join(f.pkg,"dist"),{recursive:true})
 for(const owner of owners)for(const format of ["es","cjs"]){
  if(options.skip===`${owner}:${format}`)continue
  const extension=format==="es"?"mjs":"cjs",fileName=`${owner}.${extension}`
  const code=format==="es"?"export const value=1;":"exports.value=1;"
  const id=join(f.pkg,"src/runtime.ts")
  const chunk={type:"chunk",fileName,code,moduleIds:[id],modules:{[id]:{code:"const value=1;",renderedLength:14,renderedExports:["value"]}},imports:[],dynamicImports:[]}
  const plugin=m.createProvenanceCapture({packageRoot:f.pkg,repositoryRoot:f.root,sessionRoot:session,generation:options.wrongGeneration?"f".repeat(64):marker.generation,owner})
  const hook=typeof plugin.generateBundle==="function"?plugin.generateBundle:plugin.generateBundle.handler
  hook.call({}, {format}, {[fileName]:chunk},true)
  // Deliberately mutate the native-like view after the hook; its snapshot must already be owned.
  chunk.code="BROKEN VIEW";chunk.modules[id].renderedLength=999
  await writeFile(join(f.pkg,"dist",fileName),code)
 }
 await writeFile(join(f.pkg,"dist/runtime.d.mts"),"export declare const value=1;\n")
 if(options.lateMutation)await writeFile(join(f.pkg,"dist/tools.mjs"),"export const value=2;")
}

describe("provenance build ownership",()=>{
 test("awaits_all_twenty_js_owners_and_one_dts_owner",async()=>{
  const m=await modules();expect(typeof m.runPackageBuild).toBe("function");const f=await fixture()
  try{await m.runPackageBuild({packageRoot:f.pkg,repositoryRoot:f.root,bun:process.execPath,runBuild:async()=>{await emit(m,f)}})
   const r=JSON.parse(await readFile(join(f.pkg,"dist/runtime-provenance.json"),"utf8"))
   expect(r.artifacts.filter((a:any)=>a.kind==="javascript")).toHaveLength(20)
   expect(r.artifacts.filter((a:any)=>a.kind==="declaration")).toHaveLength(1)
   expect(r.artifacts.find((a:any)=>a.path==="dist/tools.mjs").members[0].renderedLength).toBe(14)
  }finally{await f.cleanup()}
 })
 test("rejects_partial_duplicate_or_wrong_generation_owner",async()=>{
  const m=await modules();expect(typeof m.runPackageBuild).toBe("function")
  for(const options of [{skip:"theme:es"},{wrongGeneration:true}]){const f=await fixture()
   try{await expect(m.runPackageBuild({packageRoot:f.pkg,repositoryRoot:f.root,bun:process.execPath,runBuild:async()=>emit(m,f,options)})).rejects.toThrow(/owner|generation/)
    expect(await readdir(join(f.pkg,"dist"))).not.toContain("runtime-provenance.json")
   }finally{await f.cleanup()}}
 })
 test("invalidates_receipt_before_skip_clean_and_preserves_environment",async()=>{
  const m=await modules();expect(typeof m.runPackageBuild).toBe("function");const f=await fixture();const previous=process.env.CRUMBS_INTERNAL_PROVENANCE_SESSION
  try{await mkdir(join(f.pkg,"dist"));await writeFile(join(f.pkg,"dist/runtime-provenance.json"),"stale")
   await expect(m.runPackageBuild({packageRoot:f.pkg,repositoryRoot:f.root,bun:process.execPath,runBuild:async()=>{
    expect(await readdir(join(f.pkg,"dist"))).not.toContain("runtime-provenance.json");throw Error("build failed")
   }})).rejects.toThrow("build failed")
   expect(process.env.CRUMBS_INTERNAL_PROVENANCE_SESSION).toBe(previous)
   expect(await readdir(join(f.pkg,"dist"))).not.toContain("runtime-provenance.json")
  }finally{await f.cleanup()}
 })
 test("rejects_concurrent_build_and_preserves_foreign_lock",async()=>{
  const m=await modules();expect(typeof m.runPackageBuild).toBe("function");const f=await fixture()
  try{await writeFile(join(f.pkg,".runtime-provenance.lock"),"foreign owner")
   await expect(m.runPackageBuild({packageRoot:f.pkg,repositoryRoot:f.root,bun:process.execPath,runBuild:async()=>{throw Error("must not run")}})).rejects.toThrow(/lock|concurrent/)
   expect(await readFile(join(f.pkg,".runtime-provenance.lock"),"utf8")).toBe("foreign owner")
  }finally{await f.cleanup()}
 })
 test("late_byte_mutation_or_changed_input_rejects",async()=>{
  const m=await modules();expect(typeof m.runPackageBuild).toBe("function")
  for(const late of [true,false]){const f=await fixture();try{
   await expect(m.runPackageBuild({packageRoot:f.pkg,repositoryRoot:f.root,bun:process.execPath,runBuild:async()=>{
    await emit(m,f,{lateMutation:late});if(!late)await writeFile(join(f.pkg,"src/runtime.ts"),"changed")
   }})).rejects.toThrow(/byte|input/)
  }finally{await f.cleanup()}}
 })
 test("unowned_skip_clean_output_rejects_and_symlink_target_is_preserved",async()=>{
  const m=await modules();expect(typeof m.runPackageBuild).toBe("function");const f=await fixture()
  try{await mkdir(join(f.pkg,"dist"));const foreign=join(f.root,"foreign.mjs");await writeFile(foreign,"foreign content")
   await symlink(foreign,join(f.pkg,"dist/foreign.mjs"))
   await expect(m.runPackageBuild({packageRoot:f.pkg,repositoryRoot:f.root,bun:process.execPath,runBuild:async()=>emit(m,f)})).rejects.toThrow(/symlink|unowned/)
   expect(await readFile(foreign,"utf8")).toBe("foreign content")
  }finally{await f.cleanup()}
 })
 test("observation_build_never_publishes_receipt",async()=>{
  const m=await modules();expect(typeof m.runPackageBuild).toBe("function");const f=await fixture()
  try{await m.runPackageBuild({packageRoot:f.pkg,repositoryRoot:f.root,bun:process.execPath,observeOnly:true,runBuild:async()=>emit(m,f)})
   expect(await readdir(join(f.pkg,"dist"))).not.toContain("runtime-provenance.json")
  }finally{await f.cleanup()}
 })
})

test('capture_normalizes_repeated_dependency_edges_and_retains_raw_edges',async()=>{
 const m=await modules();expect(typeof m.createProvenanceCapture).toBe('function');const f=await fixture()
 const {realpath}=await import('node:fs/promises');const pkg=await realpath(f.pkg),root=await realpath(f.root)
 const session=await mkdtemp(join(tmpdir(),'crumbs-provenance-edge-test-')),generation='e'.repeat(64)
 try{
  await writeFile(join(session,'session.json'),JSON.stringify({packageRoot:pkg,repositoryRoot:root,generation}))
  const id=join(pkg,'src/runtime.ts'),plugin=m.createProvenanceCapture({packageRoot:pkg,repositoryRoot:root,sessionRoot:session,generation,owner:'tools'})
  const chunk={type:'chunk',fileName:'index.cjs',code:'const a=require("./dep.cjs");const b=require("./dep.cjs");',moduleIds:[id],modules:{[id]:{code:'',renderedLength:0}},imports:['dep.cjs','dep.cjs'],dynamicImports:[]}
  plugin.generateBundle.handler.call({}, {format:'cjs'},{'index.cjs':chunk},true)
  const receipt=JSON.parse(await readFile(join(session,'tools-cjs.json'),'utf8'))
  expect(receipt.artifacts[0].imports).toEqual(['dep.cjs'])
  expect(receipt.dependencies[0].imports).toEqual(['dep.cjs','dep.cjs'])
 }finally{await f.cleanup();await rm(session,{recursive:true,force:true})}
})

test('captured_dependency_graph_must_agree_with_actual_audited_bytes',async()=>{
 const m=await modules();expect(typeof m.runPackageBuild).toBe('function');const f=await fixture()
 try{
  await expect(m.runPackageBuild({packageRoot:f.pkg,repositoryRoot:f.root,bun:process.execPath,runBuild:async()=>{
   await emit(m,f)
   const path=join(process.env.CRUMBS_INTERNAL_PROVENANCE_SESSION!,'tools-esm.json')
   const receipt=JSON.parse(await readFile(path,'utf8'));receipt.artifacts[0].imports=['css-to-react-native']
   await writeFile(path,JSON.stringify(receipt))
  }})).rejects.toThrow(/dependency|graph/)
 }finally{await f.cleanup()}
})
