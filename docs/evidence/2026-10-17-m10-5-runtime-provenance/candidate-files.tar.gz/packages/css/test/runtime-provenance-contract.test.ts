import { describe, expect, test } from "bun:test"
import { createHash } from "node:crypto"

// Removing canonical checks, membership denial, or cross-artifact identity checks must fail these cases.
const implementation = import.meta.resolve("../build/provenance-contract.mjs")
async function api() {
  try { return await import(implementation) }
  catch (error) { if ((error as Error).message.includes("Cannot find")) return {}; throw error }
}
const hash = (value: string) => createHash("sha256").update(value).digest("hex")
const digest = "a".repeat(64), tools = "b".repeat(64)
const source = {kind:"source",path:"src/theme-token.ts",sha256:digest,renderedLength:12}
const artifact = {kind:"javascript",path:"dist/theme-token.mjs",format:"esm",bytes:12,sha256:digest,
  owner:"theme-token",members:[source],imports:[],dynamicImports:[]}
const policy = {schema:"crumbs.runtime-provenance-policy.v1",runtimeSources:["src/theme-token.ts"],helpers:[]}
function fixture() {
 return {schema:"crumbs.runtime-provenance.v1",package:{name:"@opsydyn/crumbs-css",version:"1.2.0",manifestSha256:digest},
  policySha256:digest,inputs:[{path:"bun.lock",sha256:digest}],tools:[{name:"node",version:"24.15.0"}],
  generation:digest,artifacts:[structuredClone(artifact)],entries:[{subpath:"./theme/token",classification:"ordinary-runtime",
    format:"esm",entry:"./dist/theme-token.mjs",files:["dist/theme-token.mjs"],externalSpecifiers:[],dynamicLoaderExceptions:[]}]}
}
// Independent literal encoding oracle; does not reuse production canonicalization.
const canonicalFixture = (value: unknown): Uint8Array => {
 const sort = (v:any):any => Array.isArray(v) ? v.map(sort) : v !== null && typeof v === "object" ?
  Object.fromEntries(Object.keys(v).sort((a,b)=>Buffer.compare(Buffer.from(a),Buffer.from(b))).map(k=>[k,sort(v[k])])) : v
 return Buffer.from(JSON.stringify(sort(value))+"\n")
}

describe("runtime provenance admission",()=>{
 test("canonical_encoding_is_utf8_sorted_and_rejects_non_json_values",async()=>{
  const m=await api(); expect(typeof m.canonicalProvenanceBytes).toBe("function")
  expect(Buffer.from(m.canonicalProvenanceBytes({z:1,a:{z:2,a:3}})).toString()).toBe('{"a":{"a":3,"z":2},"z":1}\n')
  for(const value of [undefined,NaN,{x:undefined},{x:Infinity}]) expect(()=>m.canonicalProvenanceBytes(value)).toThrow()
 })
 test("rejects_duplicate_keys_or_noncanonical_bytes",async()=>{
  const m=await api(); expect(typeof m.parseProvenanceReceipt).toBe("function")
  const raw=canonicalFixture(fixture()).toString()
  expect(m.parseProvenanceReceipt(Buffer.from(raw)).artifacts.length).toBe(1)
  expect(()=>m.parseProvenanceReceipt(Buffer.from(raw.replace('"schema":','"schema":"crumbs.runtime-provenance.v1","schema":')))).toThrow(/canonical|duplicate/)
  expect(()=>m.parseProvenanceReceipt(Buffer.from(JSON.stringify(fixture(),null,2)))).toThrow(/canonical/)
 })
 test("allows_shared_source_across_artifacts_but_rejects_duplicate_member_in_one",async()=>{
  const m=await api(); expect(typeof m.parseProvenanceReceipt).toBe("function")
  const f=fixture(); f.artifacts.push({...structuredClone(artifact),path:"dist/theme.mjs",owner:"theme"})
  expect(m.parseProvenanceReceipt(canonicalFixture(f)).artifacts.length).toBe(2)
  f.artifacts[0].members.push(source)
  expect(()=>m.parseProvenanceReceipt(canonicalFixture(f))).toThrow(/duplicate member/)
  f.artifacts[0].members.pop();f.artifacts[1].members[0].sha256="c".repeat(64)
  expect(()=>m.parseProvenanceReceipt(canonicalFixture(f))).toThrow(/inconsistent member/)
 })
 test("rejects_unknown_schema_format_path_or_digest",async()=>{
  const m=await api(); expect(typeof m.parseProvenanceReceipt).toBe("function")
  for(const mutate of [(f:any)=>f.schema="other",(f:any)=>f.artifacts[0].format="system",(f:any)=>f.artifacts[0].path="../escape.mjs",
   (f:any)=>f.artifacts[0].sha256="no",(f:any)=>f.artifacts[0].extra=true,(f:any)=>f.artifacts.push({...f.artifacts[0],path:"dist/THEME-TOKEN.mjs"}),
   (f:any)=>f.artifacts[0].members[0].path="/outside/file.ts"]){
    const f=fixture();mutate(f);expect(()=>m.parseProvenanceReceipt(canonicalFixture(f))).toThrow()
   }
 })
 test("rejects_unknown_generated_or_vendor_member",async()=>{
  const m=await api();expect(typeof m.assertOrdinaryMembership).toBe("function")
  expect(()=>m.assertOrdinaryMembership(artifact,policy,tools)).not.toThrow()
  for(const member of [{kind:"generated",id:"\0unreviewed",codeSha256:digest,renderedLength:0},
   {kind:"vendor",package:"effect",version:"4.0.0-rc.115",path:"dist/Schema.js",sha256:digest,renderedLength:1},
   {...source,path:"src/native-style.ts"}]) expect(()=>m.assertOrdinaryMembership({...artifact,members:[member]},policy,tools)).toThrow()
 })
 test("requires_exact_helper_format_toolchain_and_complete_artifact_membership",async()=>{
  const m=await api();expect(typeof m.assertOrdinaryMembership).toBe("function")
  const a={...artifact,path:"dist/helper.cjs",format:"cjs",sha256:"ebf00b404775b437ace729fb112c17869280b27fbd61743c86d912e5ba20cadc",
   members:[{kind:"generated",id:"\0rolldown/runtime.js",codeSha256:null,renderedLength:554}]}
  const helper={id:"\0rolldown/runtime.js",format:"cjs",toolchainSha256:tools,codeSha256:null,artifactSha256:a.sha256,
   memberInventorySha256:hash(Buffer.from(canonicalFixture(a.members)).toString())}
  const p={...policy,helpers:[helper]}
  expect(()=>m.assertOrdinaryMembership(a,p,tools)).not.toThrow()
  for(const bad of [{...a,format:"esm"},{...a,sha256:digest},{...a,members:[...a.members,source]}])
   expect(()=>m.assertOrdinaryMembership(bad,p,tools)).toThrow()
  expect(()=>m.assertOrdinaryMembership(a,p,digest)).toThrow()
 })
 test("policy_rejects_duplicate_keys_unknown_fields_and_wildcard_sources",async()=>{
  const m=await api();expect(typeof m.parseProvenancePolicy).toBe("function")
  expect(m.parseProvenancePolicy(Buffer.from(JSON.stringify(policy))).runtimeSources).toEqual(["src/theme-token.ts"])
  for(const raw of [JSON.stringify(policy).replace('"helpers":','"helpers":[],"helpers":'),
    JSON.stringify({...policy,extra:1}),JSON.stringify({...policy,runtimeSources:["src/**"]})])
   expect(()=>m.parseProvenancePolicy(Buffer.from(raw))).toThrow()
 })
})
