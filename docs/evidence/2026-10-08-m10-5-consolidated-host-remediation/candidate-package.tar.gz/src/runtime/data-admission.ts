export type RuntimeRecordPolicy = Readonly<{
  mode: "repeat-null-prototype-check" | "snapshot-prototype"
  fail(reason: "record" | "symbol" | "property", context: string, key?: string): never
}>
export type RuntimeArrayPolicy = Readonly<{
  mode: "symbol-preflight-key-snapshot" | "keys-then-all-descriptors"
  fail(reason: "array" | "symbol" | "index" | "dense", context: string): never
}>

/** Boundary policies retain their original proxy inspection and error precedence. */
export function readRuntimeRecord(value: unknown, context: string, policy: RuntimeRecordPolicy): Array<[string, unknown]> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) policy.fail("record", context)
  const prototype = Object.getPrototypeOf(value)
  if (prototype !== Object.prototype &&
    (policy.mode === "repeat-null-prototype-check" ? Object.getPrototypeOf(value) : prototype) !== null) {
    policy.fail("record", context)
  }
  const entries: Array<[string, unknown]> = []
  for (const key of Reflect.ownKeys(value)) {
    if (typeof key !== "string") policy.fail("symbol", context)
    const descriptor = Object.getOwnPropertyDescriptor(value, key)
    if (descriptor === undefined || !("value" in descriptor) || !descriptor.enumerable) policy.fail("property", context, key)
    entries.push([key, descriptor.value])
  }
  return entries
}

export function readRuntimeArray(value: unknown, context: string, policy: RuntimeArrayPolicy): unknown[] {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype) policy.fail("array", context)
  const snapshotMode = policy.mode === "symbol-preflight-key-snapshot"
  if (snapshotMode && Object.getOwnPropertySymbols(value).length > 0) policy.fail("symbol", context)
  const keys = Reflect.ownKeys(value)
  for (const key of keys) {
    if (key === "length") continue
    if (typeof key !== "string") policy.fail("symbol", context)
    if (!/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length) policy.fail("index", context)
  }
  const descriptors: Record<string, PropertyDescriptor | undefined> = snapshotMode ? Object.create(null) : Object.getOwnPropertyDescriptors(value)
  if (snapshotMode) {
    for (const key of keys) descriptors[String(key)] = Object.getOwnPropertyDescriptor(value, key)
  }
  const result: unknown[] = []
  for (let index = 0; index < value.length; index += 1) {
    const descriptor = descriptors[String(index)]
    if (descriptor === undefined || !("value" in descriptor) || !descriptor.enumerable) policy.fail("dense", context)
    result.push(descriptor.value)
  }
  return result
}
