import {createBoundNativeStylesCacheStore,hasChangedBoundNativeTransformDependencies} from './metro-cache-binding'
import type {NativeCacheSession} from './compiler/metro-cache-session'
import type {CompiledTextWitness} from './compiler/compiled-text-witness'
import { createHash } from "node:crypto"
import { type ResolutionIdentity } from "./compiler/resolution-identity"
import type { CacheStore } from "metro-cache"

export const NativeTransformCacheMetadataType = "crumbs.css.transform-cache" as const

export type NativeTransformCacheMetadata = {
  readonly $$type: typeof NativeTransformCacheMetadataType
  readonly formatVersion?: 2
  readonly session?: NativeCacheSession
  readonly reuse?: "verified" | "fresh-only"
  readonly witnesses?: readonly CompiledTextWitness[]
  readonly resolutionIdentity?: ResolutionIdentity
  readonly dependencies: ReadonlyArray<{
    readonly sourcePath: string
    readonly sourceHash: string
  }>
}

type CachedTransformResult = {
  readonly __crumbsNativeStyles?: unknown
}

export function createNativeStylesCacheStore<T>(inner: Omit<CacheStore<T>, "name"> & { readonly name?: string | undefined }): CacheStore<T> {
  return createBoundNativeStylesCacheStore(inner)
}

export function hasChangedNativeTransformDependencies(value: unknown): boolean {
  return hasChangedBoundNativeTransformDependencies(value)
}

export function createNativeTransformResultKey(value: unknown, baseKey: unknown): string | undefined {
  const metadata = readMetadata(value)
  if (metadata === undefined || typeof baseKey !== "string") return undefined
  return `${baseKey}:crumbs:${createHash("sha1").update(JSON.stringify(metadata.formatVersion===2?metadata:metadata.resolutionIdentity === undefined ? metadata.dependencies : { dependencies: metadata.dependencies, resolutionIdentity: metadata.resolutionIdentity })).digest("hex")}`
}

function readMetadata(value: unknown): NativeTransformCacheMetadata | undefined {
  if (value === null || typeof value !== "object") return undefined
  const metadata = (value as CachedTransformResult).__crumbsNativeStyles
  if (metadata === null || typeof metadata !== "object") return undefined
  const candidate = metadata as { $$type?: unknown; dependencies?: unknown }
  if (candidate.$$type !== NativeTransformCacheMetadataType || !Array.isArray(candidate.dependencies)) return undefined
  if (!candidate.dependencies.every(dependency => {
    if (dependency === null || typeof dependency !== "object") return false
    const item = dependency as { sourcePath?: unknown; sourceHash?: unknown }
    return typeof item.sourcePath === "string" && typeof item.sourceHash === "string"
  })) return undefined
  return candidate as NativeTransformCacheMetadata
}

