import {randomUUID} from 'node:crypto'
import {realpathSync} from 'node:fs'
import {resolve,isAbsolute} from 'node:path'
export type NativeCacheSession=Readonly<{version:1;token:string;root:string;canonicalRoot:string;configIdentity:string}>
export function createNativeCacheSession(projectRoot:string,configIdentity:string):NativeCacheSession{return Object.freeze({version:1,token:randomUUID(),root:resolve(projectRoot),canonicalRoot:realpathSync(projectRoot),configIdentity})}
export function readNativeCacheSession(value:unknown):NativeCacheSession|undefined{
 if(!value||typeof value!=='object')return
 const s=value as NativeCacheSession
 if(s.version!==1||typeof s.token!=='string'||!/^[a-f0-9-]{36}$/.test(s.token)||typeof s.root!=='string'||!isAbsolute(s.root)||typeof s.canonicalRoot!=='string'||!isAbsolute(s.canonicalRoot)||typeof s.configIdentity!=='string'||!s.configIdentity.length)return
 return {version:1,token:s.token,root:s.root,canonicalRoot:s.canonicalRoot,configIdentity:s.configIdentity}
}
