import {createCompiledTextMemo} from './compiled-text-memo'
import {captureCompiledTextWitness,validateCompiledTextWitness,type CompiledTextRequest,type CompileInputs,type CompiledTextWitness} from './compiled-text-witness'
import {compileWithStableResolution} from './stable-resolution-compile'
import {captureResolutionIdentity,hasChangedResolutionIdentity} from './resolution-identity'
const changed=()=>new Error('Native style sources or resolution changed during compilation; retry after edits settle')
export function createCompiledTextSession(){
 const memo=createCompiledTextMemo()
 return {
  inspect:memo.inspect,
  async compile(request:CompiledTextRequest,fresh:()=>Promise<{source:string;inputs:CompileInputs}>){
   const {ticket,hit,prior}=memo.begin(request);let count=0,lastSource:string|undefined,lastInputs:CompileInputs|undefined,previous=prior?.inputs
   let witness:CompiledTextWitness|undefined=prior?.witness
   let beforeInputs:CompileInputs|undefined
   try{
    const result=hit?{source:hit.source,inputs:hit.inputs,resolutionIdentity:captureResolutionIdentity(hit.inputs,{cwd:request.cwd,absoluteEntryPath:request.absoluteEntryPath,verification:true})}:await compileWithStableResolution(request,fresh,{
     before(inputs){
      beforeInputs=previous??inputs
      if(!witness||!validateCompiledTextWitness(witness)){const r=captureCompiledTextWitness(request,beforeInputs);witness=r.kind==='eligible'?r.witness:undefined}
     },
     after(result){
      const sameGraph=JSON.stringify(beforeInputs)===JSON.stringify(result.inputs)
      if(witness&&sameGraph&&validateCompiledTextWitness(witness)){
       count=lastSource===undefined||lastSource===result.source&&JSON.stringify(lastInputs)===JSON.stringify(result.inputs)?count+1:1
       lastSource=result.source;lastInputs=result.inputs
      }else{
       count=0;const r=captureCompiledTextWitness(request,result.inputs);witness=r.kind==='eligible'?r.witness:undefined
      }
      previous=result.inputs
     }
    })
    if(hit)witness=hit.witness
    const validate=()=>{if((witness&&!validateCompiledTextWitness(witness))||hasChangedResolutionIdentity(result.resolutionIdentity)){memo.abort(ticket);throw changed()}}
    let finished=false
    return {...result,witness,validate,abort(){finished=true;memo.abort(ticket)},complete(){if(finished)return;validate();finished=true;memo.finish(ticket,witness?{source:result.source,inputs:result.inputs,witness}:undefined,count)}}
   }catch(e){memo.abort(ticket);throw e}
  }
 }
}
export const compiledTextSession=createCompiledTextSession()
