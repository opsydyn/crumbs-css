import {createHash} from 'node:crypto'
import {readFileSync,readdirSync,readlinkSync,realpathSync,lstatSync,statSync} from 'node:fs'
import * as path from 'node:path'
import {parse,parseExpression} from '@babel/parser'

export type CompileInputs=Readonly<Record<string,unknown>>
export type CompiledTextRequest=Readonly<{owner:string;key:string;cwd:string;absoluteEntryPath:string;options:Readonly<Record<string,unknown>>}>
type FileFact=Readonly<{path:string;canonical:string;sha256:string}>
type DirectoryFact=Readonly<{path:string;canonical:string;names?:readonly string[];entries:readonly Readonly<{name:string;kind:string;target:string|null}>[]}>
type LinkFact=Readonly<{path:string;target:string;canonical:string}>
type ImportFact=Readonly<{importer:string;request:string;kind:string;destination:string;external:boolean}>
export type CompiledTextWitness=Readonly<{version:1;integrity:string;requestKey:string;files:readonly FileFact[];directories:readonly DirectoryFact[];links:readonly LinkFact[];imports:readonly ImportFact[];absent:readonly Readonly<{ancestor:string;components:readonly string[]}>[];configurationPaths:readonly string[]}>
export type WitnessAdmission={kind:'eligible';witness:CompiledTextWitness}|{kind:'fresh';reason:string}
const hash=(s:Uint8Array|string)=>createHash('sha256').update(s).digest('hex')
const configs=['package.json','tsconfig.json','jsconfig.json','bun.lock','bun.lockb','package-lock.json','yarn.lock','pnpm-lock.yaml']
const compilerKeys=new Set('target module moduleResolution lib jsx strict exactOptionalPropertyTypes noUncheckedIndexedAccess noImplicitOverride noFallthroughCasesInSwitch allowImportingTsExtensions resolveJsonModule esModuleInterop isolatedModules verbatimModuleSyntax skipLibCheck forceConsistentCasingInFileNames types'.split(' '))
const object=(v:unknown):v is Record<string,any>=>v!==null&&typeof v==='object'&&!Array.isArray(v)
function stat(p:string){try{return lstatSync(p)}catch(e){if((e as NodeJS.ErrnoException).code==='ENOENT'||(e as NodeJS.ErrnoException).code==='ENOTDIR')return undefined;throw e}}
function directory(p:string,names?:readonly string[]):DirectoryFact{return {path:p,canonical:realpathSync(p),...(names?{names}:{}),entries:readdirSync(p,{withFileTypes:true}).filter(e=>!names||names.includes(e.name)).map(e=>({name:e.name,kind:e.isSymbolicLink()?'link':e.isDirectory()?'directory':e.isFile()?'file':'other',target:e.isSymbolicLink()?readlinkSync(path.join(p,e.name)):null})).sort((a,b)=>a.name.localeCompare(b.name))}}
function jsonc(text:string):any{
 const convert=(n:any):any=>{
  if(n.type==='ObjectExpression')return Object.fromEntries(n.properties.map((p:any)=>{if(p.type!=='ObjectProperty'||p.computed||p.key.type!=='StringLiteral')throw Error('unsupported JSONC property');return [p.key.value,convert(p.value)]}))
  if(n.type==='ArrayExpression')return n.elements.map(convert)
  if(['StringLiteral','NumericLiteral','BooleanLiteral'].includes(n.type))return n.value
  if(n.type==='NullLiteral')return null
  if(n.type==='UnaryExpression'&&n.operator==='-'&&n.argument.type==='NumericLiteral')return -n.argument.value
  throw Error('unsupported JSONC value')
 };return convert(parseExpression(text))
}
function syntax(text:string,file:string){
 if(file.endsWith('.json')){JSON.parse(text);return}
 const ast=parse(text,{sourceType:'unambiguous',plugins:['typescript','jsx']})
 const walk=(n:any):void=>{
  if(!n||typeof n!=='object')return
  if(n.type==='ImportExpression'||n.type==='TSImportEqualsDeclaration'||n.type==='Import'||(n.type==='CallExpression'&&n.callee?.type==='Identifier'&&n.callee.name==='require'&&(n.arguments.length!==1||n.arguments[0].type!=='StringLiteral')))throw Error('unsupported import syntax')
  for(const [key,v] of Object.entries(n)){if(['loc','start','end','comments','tokens'].includes(key))continue;if(Array.isArray(v))v.forEach(walk);else if(object(v))walk(v)}
 };walk(ast)
}

// This is a conservative witness, not a replacement resolver. Observe every
// candidate directory in the admitted grammar and corroborate selected inputs.
export function captureCompiledTextWitness(request:CompiledTextRequest,inputs:CompileInputs):WitnessAdmission{
 try{
  if(Object.keys(request.options).some(k=>!['identifiers','platform','format','target','define','conditions'].includes(k)))throw Error('unsupported compile options')
  if(Object.keys(inputs).length>512||Object.keys(inputs).length===0)throw Error('input bound')
  const files=new Map<string,FileFact>(),dirs=new Map<string,DirectoryFact>(),links=new Map<string,LinkFact>(),absent=new Map<string,{ancestor:string;components:string[]}>(),configuration=new Set<string>(),imports:ImportFact[]=[]
  const data=new Map<string,string>(),scoped=new Set<string>(),activeConfigs=new Set<string>(),doneConfigs=new Set<string>()
  const directoryNames=new Map<string,Set<string>>()
  const addDirectory=(p:string,names:readonly string[]=[])=>{
   if(!dirs.has(p)){if(dirs.size>=512)throw Error('directory bound');dirs.set(p,directory(p));directoryNames.set(p,new Set())}
   for(const name of names)directoryNames.get(p)!.add(name)
  }
  const candidateNames=(p:string)=>{
   const name=path.basename(p),out=[name,...['.tsx','.ts','.jsx','.js','.css','.json'].map(x=>name+x)]
   if(/\.(?:mjs|cjs|jsx|js)$/.test(name)){const stem=name.replace(/\.[^.]+$/,'');out.push(stem+'.ts',stem+'.tsx',stem+'.mts',stem+'.cts')}
   return out
  }
  const route=(input:string):boolean=>{
   const absolute=path.resolve(input),root=path.parse(absolute).root,parts=absolute.slice(root.length).split(path.sep).filter(Boolean);let current=root
   for(let i=0;i<parts.length;i++){
    addDirectory(current,[parts[i]!])
    const child=path.join(current,parts[i]!),s=stat(child)
    if(!s){absent.set(child,{ancestor:current,components:parts.slice(i)});return false}
    if(s.isSymbolicLink()){
     if(links.size>=128&&!links.has(child))throw Error('link bound')
     links.set(child,{path:child,target:readlinkSync(child),canonical:realpathSync(child)})
    }
    if(i<parts.length-1){if(!s.isDirectory()&&!s.isSymbolicLink())return false;current=child}
   }
   return true
  }
  const file=(p:string):string=>{
   p=path.resolve(p);if(data.has(p))return data.get(p)!
   if(!route(p))throw Error('missing file')
   const b=readFileSync(p);if(b.length>1048576)throw Error('file payload bound')
   const canonical=realpathSync(p);files.set(p,{path:p,canonical,sha256:hash(b)});data.set(p,b.toString());return b.toString()
  }
  const observedTargets=new Set<string>(),activeTargets=new Set<string>()
  const observeTarget=(p:string):void=>{
   if(activeTargets.has(p))throw Error('package target cycle')
   if(observedTargets.has(p))return
   if(observedTargets.size>=2048)throw Error('candidate bound')
   activeTargets.add(p);observedTargets.add(p);route(p)
   if(stat(path.dirname(p))&&statSync(path.dirname(p)).isDirectory())addDirectory(path.dirname(p),candidateNames(p))
   if(stat(p)&&statSync(p).isDirectory()){
    addDirectory(p,['package.json',...candidateNames(path.join(p,'index'))]);const pkg=path.join(p,'package.json')
    if(stat(pkg))packageTargets(p,manifest(pkg))
   }
   activeTargets.delete(p)
  }
  const config=(p:string)=>{
   if(activeConfigs.has(p))throw Error('config cycle');if(doneConfigs.has(p))return
   activeConfigs.add(p);configuration.add(p);if(configuration.size>64)throw Error('configuration bound')
   const c=jsonc(file(p));if(!object(c)||Object.keys(c).some(k=>!['compilerOptions','extends','include','exclude','files'].includes(k)))throw Error('unsupported configuration')
   if(c.compilerOptions!==undefined&&(!object(c.compilerOptions)||Object.keys(c.compilerOptions).some(k=>!compilerKeys.has(k))))throw Error('unsupported compiler configuration')
   for(const base of c.extends===undefined?[]:Array.isArray(c.extends)?c.extends:[c.extends]){
    if(typeof base!=='string'||(!base.startsWith('.')&&!path.isAbsolute(base)))throw Error('package configuration extends')
    const target=path.resolve(path.dirname(p),base);observeTarget(target);config(stat(target)?target:target+'.json')
   }
   activeConfigs.delete(p);doneConfigs.add(p)
  }
  const manifest=(p:string)=>{
   configuration.add(p);if(configuration.size>64)throw Error('configuration bound')
   const m=JSON.parse(file(p));if(!object(m))throw Error('invalid manifest');return m
  }
  const scope=(from:string)=>{
   for(let dir=path.dirname(from);;dir=path.dirname(dir)){
    if(scoped.has(dir))break;scoped.add(dir);route(dir);addDirectory(dir,configs)
    for(const name of configs){const p=path.join(dir,name);if(!stat(p))continue
     if(name==='tsconfig.json'||name==='jsconfig.json')config(p)
     else{configuration.add(p);if(configuration.size>64)throw Error('configuration bound');file(p)}
    }
    if(path.dirname(dir)===dir)break
   }
  }
  const packageTargets=(root:string,m:any)=>{
   if(m.browser!==undefined)throw Error('manifest remapping')
   const targets=(v:any,subpaths:boolean)=>{
    if(typeof v==='string'){if(!v.startsWith('./')||v.includes('*')||path.relative(root,path.resolve(root,v)).startsWith('..'))throw Error('unsupported package target');observeTarget(path.resolve(root,v));return}
    if(v===null)return
    if(!object(v))throw Error('unsupported exports')
    for(const [k,t]of Object.entries(v)){
     if(k.includes('*')||!(subpaths&&k.startsWith('.')||['types','import','require','node','default','module'].includes(k)))throw Error('unsupported export condition')
     targets(t,false)
    }
   }
   if(m.exports!==undefined)targets(m.exports,true)
   for(const name of ['main','module'])if(m[name]!==undefined){if(typeof m[name]!=='string'||path.relative(root,path.resolve(root,m[name])).startsWith('..'))throw Error('unsupported package entry');observeTarget(path.resolve(root,m[name]))}
  }
  const selected=new Set(Object.keys(inputs).map(p=>path.resolve(request.cwd,p)))
  for(const [input,info]of Object.entries(inputs)){
   if(!object(info)||!Array.isArray(info.imports))throw Error('missing imports')
   const p=path.resolve(request.cwd,input),bytes=file(p);syntax(bytes,p);scope(p);scope(realpathSync(p))
   for(const edge of info.imports){
    if(!object(edge)||!['import-statement','require-call'].includes(edge.kind)||typeof edge.path!=='string')throw Error('unsupported import metadata')
    const external=edge.external===true,specifier=edge.original??(external?edge.path:undefined)
    if(typeof specifier!=='string'||specifier.startsWith('#')||specifier.includes('*'))throw Error('unsupported import request')
    if(imports.length>=1024)throw Error('import bound')
    const destination=external?edge.path:path.resolve(request.cwd,edge.path)
    if(!external&&!selected.has(destination))throw Error('incomplete selected graph')
    imports.push({importer:p,request:specifier,kind:edge.kind,destination,external})
    if(external)continue // external modules are required afresh by the existing evaluator
    if(specifier.startsWith('.')||path.isAbsolute(specifier)){observeTarget(path.resolve(path.dirname(p),specifier));continue}
    if(specifier.includes(':'))throw Error('unsupported namespace')
    const parts=specifier.split('/'),name=specifier.startsWith('@')?parts.slice(0,2).join('/'):parts[0]!,suffix=parts.slice(name.startsWith('@')?2:1).join('/')
    for(let dir=path.dirname(p);;dir=path.dirname(dir)){
     const own=path.join(dir,'package.json');if(stat(own)){const m=manifest(own);if(m.name===name){packageTargets(dir,m);observeTarget(path.join(dir,suffix||'index'))}}
     const pkg=path.join(dir,'node_modules',name);observeTarget(pkg)
     if(stat(pkg)){const man=path.join(pkg,'package.json');if(stat(man))packageTargets(pkg,manifest(man));observeTarget(path.join(pkg,suffix||'index'))}
     if(path.dirname(dir)===dir)break
    }
   }
  }
  const body={version:1 as const,requestKey:request.key,files:[...files.values()],directories:[...dirs.values()].map(d=>{const names=[...directoryNames.get(d.path)!].sort();return {...d,names,entries:d.entries.filter(e=>names.includes(e.name))}}),links:[...links.values()],imports,absent:[...absent.values()],configurationPaths:[...configuration]}
  const witness:CompiledTextWitness={...body,integrity:hash(JSON.stringify(body))}
  if(Buffer.byteLength(JSON.stringify(witness))>1048576)throw Error('witness payload bound')
  return {kind:'eligible',witness}
 }catch(e){return {kind:'fresh',reason:e instanceof Error?e.message:'unverifiable input'}}
}
export function decodeCompiledTextWitness(v:unknown):CompiledTextWitness|undefined{
 try{
  if(!object(v)||v.version!==1||typeof v.requestKey!=='string')return
  for(const [name,max]of [['files',576],['directories',512],['links',128],['imports',1024],['configurationPaths',64],['absent',2048]] as const)if(!Array.isArray(v[name])||v[name].length>max)return
  if(!v.files.length||!v.directories.length||Buffer.byteLength(JSON.stringify(v))>1048576)return
  const absolute=(x:unknown)=>typeof x==='string'&&path.isAbsolute(x)&&x.length<=4096
  if(!v.files.every((f:any)=>object(f)&&absolute(f.path)&&absolute(f.canonical)&&typeof f.sha256==='string'&&/^[a-f0-9]{64}$/.test(f.sha256)))return
  if(!v.directories.every((d:any)=>object(d)&&absolute(d.path)&&absolute(d.canonical)&&Array.isArray(d.names)&&d.names.length<=8192&&d.names.every((n:any)=>typeof n==='string'&&!n.includes('/')&&n!=='.'&&n!=='..')&&Array.isArray(d.entries)&&d.entries.every((e:any)=>object(e)&&typeof e.name==='string'&&!e.name.includes('/')&&['file','directory','link','other'].includes(e.kind)&&(e.target===null||typeof e.target==='string'))))return
  if(!v.links.every((l:any)=>object(l)&&absolute(l.path)&&absolute(l.canonical)&&typeof l.target==='string'))return
  if(!v.imports.every((i:any)=>object(i)&&absolute(i.importer)&&typeof i.request==='string'&&typeof i.destination==='string'&&['import-statement','require-call'].includes(i.kind)&&typeof i.external==='boolean'))return
  if(!v.absent.every((a:any)=>object(a)&&absolute(a.ancestor)&&Array.isArray(a.components)&&a.components.length>0&&a.components.every((c:any)=>typeof c==='string'&&c!=='.'&&c!=='..'&&!c.includes('/'))))return
  if(!v.configurationPaths.every(absolute))return
  const {integrity,...body}=v
  if(typeof integrity!=='string'||integrity!==hash(JSON.stringify(body)))return
  return v as CompiledTextWitness
 }catch{return undefined}
}
export function validateCompiledTextWitness(witness:CompiledTextWitness):boolean{
 try{
  if(!decodeCompiledTextWitness(witness))return false
  return witness.files.every(f=>realpathSync(f.path)===f.canonical&&hash(readFileSync(f.path))===f.sha256)
   &&witness.directories.every(d=>{const now=directory(d.path,d.names);return now.canonical===d.canonical&&JSON.stringify(now.entries)===JSON.stringify(d.entries)})
   &&witness.links.every(l=>readlinkSync(l.path)===l.target&&realpathSync(l.path)===l.canonical)
   &&witness.absent.every(a=>!stat(path.join(a.ancestor,a.components[0]!)))
 }catch{return false}
}
