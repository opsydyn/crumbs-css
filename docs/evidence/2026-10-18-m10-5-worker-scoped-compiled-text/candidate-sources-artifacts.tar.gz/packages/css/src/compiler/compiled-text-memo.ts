import {validateCompiledTextWitness,type CompiledTextRequest,type CompiledTextWitness,type CompileInputs} from './compiled-text-witness'
export type CompiledTextValue=Readonly<{source:string;inputs:CompileInputs;witness:CompiledTextWitness}>
export type MemoTicket=Readonly<{owner:string;generation:number}>
type Entry={key:string;generation:number;pending:boolean;value?:CompiledTextValue;confirmations:number;bytes:number}
export function createCompiledTextMemo(){
 const entries=new Map<string,Entry>();let generation=0
 const total=()=>[...entries.values()].reduce((n,e)=>n+e.bytes,0)
 const evict=(except?:string)=>{for(const [owner,e]of entries){if(owner!==except&&!e.pending){entries.delete(owner);return true}}return false}
 return {
  begin(request:CompiledTextRequest):{ticket:MemoTicket|undefined;hit:CompiledTextValue|undefined;prior?:CompiledTextValue}{
   let e=entries.get(request.owner)
   if(e&&(e.key!==request.key||(e.value&&!validateCompiledTextWitness(e.value.witness)))){entries.delete(request.owner);e=undefined}
   if(!e){if(entries.size>=16&&!evict())return {ticket:undefined,hit:undefined};e={key:request.key,generation:0,pending:false,confirmations:0,bytes:0};entries.set(request.owner,e)}
   e.generation=++generation;e.pending=true
   return {ticket:{owner:request.owner,generation:e.generation},hit:e.confirmations>=2?e.value:undefined,...(e.value?{prior:e.value}:{})}
  },
  finish(ticket:MemoTicket|undefined,value:CompiledTextValue|undefined,freshConfirmations:number):void{
   if(!ticket)return
   const e=entries.get(ticket.owner);if(!e||e.generation!==ticket.generation)return
   e.pending=false
   if(!value||!Number.isInteger(freshConfirmations)||freshConfirmations<0){entries.delete(ticket.owner);return}
   const bytes=Buffer.byteLength(value.source)+Buffer.byteLength(JSON.stringify({inputs:value.inputs,witness:value.witness,owner:ticket.owner,key:e.key}))
   if(bytes>1048576){entries.delete(ticket.owner);return}
   const same=e.value?.source===value.source&&JSON.stringify(e.value.inputs)===JSON.stringify(value.inputs)&&JSON.stringify(e.value.witness)===JSON.stringify(value.witness)
   const confirmations=Math.min(2,(same?e.confirmations:0)+freshConfirmations)
   e.confirmations=confirmations;e.bytes=bytes;e.value=JSON.parse(JSON.stringify(value)) as CompiledTextValue
   while(total()>8*1048576){if(!evict(ticket.owner)){entries.delete(ticket.owner);return}}
   entries.delete(ticket.owner);entries.set(ticket.owner,e)
  },
  abort(ticket:MemoTicket|undefined):void{if(ticket&&entries.get(ticket.owner)?.generation===ticket.generation)entries.delete(ticket.owner)},
  clear():void{entries.clear()},
  inspect(){return {owners:entries.size,bytes:total(),probation:[...entries.values()].filter(e=>!!e.value&&e.confirmations<2).length,ready:[...entries.values()].filter(e=>e.confirmations===2).length}}
 }
}
