import {createHash} from 'node:crypto'
import {readFileSync} from 'node:fs'
import type {CacheStore} from 'metro-cache'
import {readNativeCacheSession,type NativeCacheSession} from './compiler/metro-cache-session'
import {decodeCompiledTextWitness,validateCompiledTextWitness} from './compiler/compiled-text-witness'
import {hasChangedResolutionIdentity} from './compiler/resolution-identity'
type Store<T>=Omit<CacheStore<T>,'name'>&{readonly name?:string|undefined}
const originals=new WeakMap<object,object>()
export function hasChangedBoundNativeTransformDependencies(value:unknown,session?:NativeCacheSession):boolean{
 if(!value||typeof value!=='object'||!('__crumbsNativeStyles' in value)||value.__crumbsNativeStyles===undefined)return false
 try{
  const m=value.__crumbsNativeStyles as any,s=readNativeCacheSession(m?.session)
  if(!session||!s||s.token!==session.token||s.root!==session.root||s.canonicalRoot!==session.canonicalRoot||s.configIdentity!==session.configIdentity)return true
  if(m.$$type!=='crumbs.css.transform-cache'||m.formatVersion!==2||m.reuse!=='verified'||!Array.isArray(m.witnesses)||!m.witnesses.length||m.witnesses.length>16||!Array.isArray(m.dependencies)||m.dependencies.length>512||Buffer.byteLength(JSON.stringify(m))>1048576)return true
  if(m.resolutionIdentity&&hasChangedResolutionIdentity(m.resolutionIdentity))return true
  for(const w of m.witnesses){const proof=decodeCompiledTextWitness(w);if(!proof||!validateCompiledTextWitness(proof))return true}
  return m.dependencies.some((d:any)=>!d||typeof d.sourcePath!=='string'||typeof d.sourceHash!=='string'||createHash('sha256').update(readFileSync(d.sourcePath)).digest('hex')!==d.sourceHash)
 }catch{return true}
}
export function createBoundNativeStylesCacheStore<T>(inner:Store<T>,session?:NativeCacheSession):CacheStore<T>{
 const underlying=(originals.get(inner)??inner) as Store<T>
 const wrapper:CacheStore<T>={name:`crumbs-dependency-aware:${underlying.name??'cache'}`,async get(key){const value=await underlying.get(key);return hasChangedBoundNativeTransformDependencies(value,session)?null:value},set(key,value){return underlying.set(key,value)},clear(){return underlying.clear()}}
 originals.set(wrapper,underlying);return wrapper
}
