import {test,expect} from 'bun:test'
import {mkdtempSync,writeFileSync,rmSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {captureCompiledTextWitness} from '../src/compiler/compiled-text-witness'
async function fixture(run:(memo:any,request:any,value:any)=>void){
 const m=await import('../src/compiler/compiled-text-memo').catch(()=>undefined);expect(typeof m?.createCompiledTextMemo).toBe('function');if(!m)return
 const cwd=mkdtempSync(join(tmpdir(),'crumbs-memo-')),entry=join(cwd,'entry.ts');writeFileSync(entry,'export const n=1')
 const request={owner:entry,key:'one',cwd,absoluteEntryPath:entry,options:{}},inputs={'entry.ts':{imports:[]}},r=captureCompiledTextWitness(request,inputs);expect(r.kind).toBe('eligible');if(r.kind!=='eligible')return
 try{run(m.createCompiledTextMemo(),request,{source:'export const n=1',inputs,witness:r.witness})}finally{rmSync(cwd,{recursive:true,force:true})}
}
test('memo requires two fresh confirmations and invalidates changed content',()=>fixture((memo,r,v)=>{
 let call=memo.begin(r);expect(call.hit).toBeUndefined();memo.finish(call.ticket,v,1)
 call=memo.begin(r);expect(call.hit).toBeUndefined();memo.finish(call.ticket,v,1)
 call=memo.begin(r);expect(call.hit?.source).toBe(v.source);memo.finish(call.ticket,v,0)
 writeFileSync(r.absoluteEntryPath,'export const n=2');expect(memo.begin(r).hit).toBeUndefined()
}))
test('aborted, superseded and evicted completions cannot promote or resurrect',()=>fixture((memo,r,v)=>{
 const old=memo.begin(r),next=memo.begin({...r,key:'two'});memo.finish(next.ticket,v,2);memo.finish(old.ticket,v,2)
 expect(memo.begin(r).hit).toBeUndefined();memo.clear()
 const delayed=memo.begin(r);memo.clear();const current=memo.begin(r);memo.finish(delayed.ticket,v,2);memo.abort(current.ticket);expect(memo.inspect().ready).toBe(0)
}))
test('memo bounds all pending owners and UTF8 payload with deterministic eviction',()=>fixture((memo,r,v)=>{
 for(let i=0;i<17;i++){const x=memo.begin({...r,owner:r.owner+i});memo.finish(x.ticket,v,2)}
 expect(memo.inspect().owners).toBe(16);expect(memo.begin({...r,owner:r.owner+'0'}).hit).toBeUndefined()
 memo.clear();const t=memo.begin(r);memo.finish(t.ticket,{...v,source:'é'.repeat(524289)},2);expect(memo.inspect().bytes).toBe(0)
 memo.clear();for(let i=0;i<20;i++){const x=memo.begin({...r,owner:r.owner+i});memo.finish(x.ticket,{...v,source:'a'.repeat(900000)},2)}
 expect(memo.inspect().bytes).toBeLessThanOrEqual(8*1024*1024)
 memo.clear();for(let i=0;i<17;i++)memo.begin({...r,owner:r.owner+i});expect(memo.inspect().owners).toBe(16);expect(memo.begin({...r,owner:r.owner+'overflow'}).ticket).toBeUndefined()
}))
