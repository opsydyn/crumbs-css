import {test,expect} from 'bun:test'
import {mkdtempSync,writeFileSync,rmSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {captureCompiledTextWitness} from '../src/compiler/compiled-text-witness'

test('session-bound stores reject foreign, malformed and legacy native results and retain ordinary hits',async()=>{
 const s=await import('../src/compiler/metro-cache-session').catch(()=>undefined),b=await import('../src/metro-cache-binding').catch(()=>undefined)
 expect(typeof s?.createNativeCacheSession).toBe('function');expect(typeof b?.createBoundNativeStylesCacheStore).toBe('function');if(!s||!b)return
 const root=mkdtempSync(join(tmpdir(),'crumbs-metro-session-')),entry=join(root,'entry.ts');writeFileSync(entry,'export const n=1')
 try{
  const session=s.createNativeCacheSession(root,'config'),other=s.createNativeCacheSession(root,'config')
  const w=captureCompiledTextWitness({owner:entry,key:'key',cwd:root,absoluteEntryPath:entry,options:{}},{'entry.ts':{imports:[]}});expect(w.kind).toBe('eligible');if(w.kind!=='eligible')return
  const valid={__crumbsNativeStyles:{$$type:'crumbs.css.transform-cache',formatVersion:2,session,reuse:'verified',witnesses:[w.witness],dependencies:[]}}
  let value:any=valid;const inner={name:'memory',get:()=>value,set:(_k:Buffer,v:any)=>{value=v},clear(){}}
  const store=b.createBoundNativeStylesCacheStore(inner,session),foreign=b.createBoundNativeStylesCacheStore(inner,other),key=Buffer.from('stable-key')
  expect(await store.get(key)).toEqual(valid);expect(await foreign.get(key)).toBeNull()
  for(const metadata of [null,{}, {$$type:'crumbs.css.transform-cache',dependencies:[]},{...valid.__crumbsNativeStyles,witnesses:[]},{...valid.__crumbsNativeStyles,reuse:'fresh-only'},{...valid.__crumbsNativeStyles,witnesses:[{}]}]){value={__crumbsNativeStyles:metadata};expect(await store.get(key)).toBeNull()}
  value={output:[]};expect(await store.get(key)).toEqual(value)
  value=valid;writeFileSync(entry,'export const n=2');expect(await store.get(key)).toBeNull()
 }finally{rmSync(root,{recursive:true,force:true})}
})
test('withNativeStyles carries a private session and rewrapping stays idempotent',async()=>{
 const {withNativeStyles}=await import('../src/metro-plugin')
 const config=withNativeStyles({projectRoot:join(import.meta.dir,'..'),transformer:{},cacheStores:[]} as any)
 const session=(config.transformer as any).__crumbsNativeCacheSession
 expect(session?.version).toBe(1);expect(typeof session?.token).toBe('string');expect(withNativeStyles(config)).toBe(config)
 const next=withNativeStyles({projectRoot:config.projectRoot,transformer:{},cacheStores:[]} as any)
 expect((next.transformer as any).__crumbsNativeCacheSession.token).not.toBe(session.token)
})
