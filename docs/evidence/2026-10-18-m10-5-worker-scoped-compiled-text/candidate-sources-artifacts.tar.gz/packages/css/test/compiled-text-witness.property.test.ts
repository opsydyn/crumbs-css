import {test,expect} from 'bun:test'
import fc from 'fast-check'
import {mkdtempSync,writeFileSync,rmSync,unlinkSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {createRequire} from 'node:module'
import {captureCompiledTextWitness,validateCompiledTextWitness} from '../src/compiler/compiled-text-witness'
const req=createRequire(import.meta.url),esbuild=req(req.resolve('esbuild',{paths:[req.resolve('@vanilla-extract/integration')]}))
test('supported edit and restore histories never validate stale compiled output',async()=>{
 await fc.assert(fc.asyncProperty(fc.array(fc.constantFrom('edit','restore','add','remove'),{minLength:1,maxLength:12}),async steps=>{
  const cwd=mkdtempSync(join(tmpdir(),'crumbs-witness-law-')),entry=join(cwd,'entry.ts');writeFileSync(entry,'import {x} from "./dep"; export {x}');writeFileSync(join(cwd,'dep.js'),'export const x=11;')
  const compile=()=>esbuild.build({entryPoints:[entry],absWorkingDir:cwd,bundle:true,write:false,platform:'node',format:'cjs',metafile:true})
  try{
   let old=await compile(),proof=captureCompiledTextWitness({owner:entry,key:'k',cwd,absoluteEntryPath:entry,options:{}},old.metafile.inputs)
   for(const step of steps){
    if(step==='add')writeFileSync(join(cwd,'dep.ts'),'export const x=33;')
    if(step==='remove')try{unlinkSync(join(cwd,'dep.ts'))}catch{}
    if(step==='edit'||step==='restore')writeFileSync(join(cwd,'dep.js'),`export const x=${step==='edit'?22:11};`)
    const next=await compile();expect(proof.kind).toBe('eligible')
    if(proof.kind==='eligible'&&validateCompiledTextWitness(proof.witness))expect(next.outputFiles[0].text).toBe(old.outputFiles[0].text)
    old=next;proof=captureCompiledTextWitness({owner:entry,key:'k',cwd,absoluteEntryPath:entry,options:{}},old.metafile.inputs)
   }
  }finally{rmSync(cwd,{recursive:true,force:true})}
 }),{seed:1051810,numRuns:30})
})
