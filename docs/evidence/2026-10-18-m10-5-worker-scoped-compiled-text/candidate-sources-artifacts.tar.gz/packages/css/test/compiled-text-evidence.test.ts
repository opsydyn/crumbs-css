import {expect,test} from 'bun:test'
import {mkdtempSync,writeFileSync,rmSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {createHash} from 'node:crypto'

test('compiled-text evidence binds source, raw files, parity and disposition',async()=>{
 const module=await import('../bench/compiled-text-reuse/verify').catch(()=>undefined)
 expect(typeof module?.verifyCompiledTextEvidence).toBe('function')
 if(!module) return
 const root=mkdtempSync(join(tmpdir(),'crumbs-text-evidence-'))
 const sha=(s:string)=>createHash('sha256').update(s).digest('hex')
 const control={source:sha('source'),output:sha('output'),inputs:['a','b']}
 const packet:any={version:1,disposition:'rejected',source:sha('source'),files:[{path:'raw.json',sha256:sha(JSON.stringify(control))}],pairs:[{control,candidate:control}],gates:{witness:'failed'}}
 const run=()=>{writeFileSync(join(root,'packet.json'),JSON.stringify(packet));return module.verifyCompiledTextEvidence(root)}
 try{
  writeFileSync(join(root,'raw.json'),JSON.stringify(control));expect(run()).toEqual([])
  packet.pairs[0].candidate={...control,output:sha('different')};expect(run().length).toBeGreaterThan(0)
  packet.pairs[0].candidate={...control,inputs:['a']};expect(run().length).toBeGreaterThan(0)
  packet.pairs[0].candidate={...control,source:sha('wrong')};expect(run().length).toBeGreaterThan(0)
  packet.pairs[0].candidate=control;packet.disposition='accepted';expect(run().length).toBeGreaterThan(0)
  packet.disposition='rejected';rmSync(join(root,'raw.json'));expect(run().length).toBeGreaterThan(0)
 }finally{rmSync(root,{recursive:true,force:true})}
})
