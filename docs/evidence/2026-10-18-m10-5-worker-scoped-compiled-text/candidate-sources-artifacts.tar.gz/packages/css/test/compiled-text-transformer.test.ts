import {test,expect} from 'bun:test'
import {mkdtempSync,writeFileSync,rmSync,readFileSync,symlinkSync} from 'node:fs'
import {join} from 'node:path'
import {tmpdir} from 'node:os'

test('text session confirms fresh compilations and returns request-owned completion',async()=>{
 const m=await import('../src/compiler/compiled-text-session').catch(()=>undefined);expect(typeof m?.createCompiledTextSession).toBe('function');if(!m)return
 const cwd=mkdtempSync(join(tmpdir(),'crumbs-session-')),entry=join(cwd,'entry.ts');writeFileSync(entry,'export const n=1')
 const request={owner:entry,key:'key',cwd,absoluteEntryPath:entry,options:{}},session=m.createCompiledTextSession();let calls=0
 const fresh=async()=>{calls++;return {source:readFileSync(entry,'utf8'),inputs:{'entry.ts':{imports:[]}}}}
 try{
  for(let i=0;i<3;i++){const result=await session.compile(request,fresh);result.complete()}
  const before=calls;const hit=await session.compile(request,async()=>{throw Error('native service unavailable')});expect(hit.source).toContain('n=1');hit.complete();expect(calls).toBe(before)
  writeFileSync(entry,'export const n=2');await expect(session.compile(request,async()=>{throw Error('native service unavailable')})).rejects.toThrow('native service unavailable')
 }finally{rmSync(cwd,{recursive:true,force:true})}
})

test('transformer reruns ambient authoring while admitting compiled text',async()=>{
 const {compiledTextSession}=await import('../src/compiler/compiled-text-session')
 const {transformCssTsToStyleSheet}=await import('../src/transformer')
 const cwd=mkdtempSync(join(tmpdir(),'crumbs-transform-effects-')),entry=join(cwd,'entry.css.ts'),log=join(cwd,'effects.log')
 writeFileSync(join(cwd,'package.json'),'{"name":"compiled-effects"}');writeFileSync(log,'');symlinkSync(join(import.meta.dir,'../node_modules'),join(cwd,'node_modules'))
 const style=join(import.meta.dir,'../dist/style.mjs')
 writeFileSync(entry,`import {style} from ${JSON.stringify(style)};import {appendFileSync} from 'node:fs';appendFileSync(${JSON.stringify(log)},process.env.CRUMBS_TEXT_EFFECT+'\\n');export const box=style({width:Number(process.env.CRUMBS_TEXT_EFFECT)});`)
 const outputs:string[]=[],old=process.env.CRUMBS_TEXT_EFFECT
 try{
  for(let i=0;i<8;i++){process.env.CRUMBS_TEXT_EFFECT=String(i+101);outputs.push(await transformCssTsToStyleSheet(entry,cwd))}
  expect(new Set(outputs).size).toBe(8);expect(readFileSync(log,'utf8').trim().split('\n')).toHaveLength(8);expect(compiledTextSession.inspect().ready).toBeGreaterThan(0)
 }finally{if(old===undefined)delete process.env.CRUMBS_TEXT_EFFECT;else process.env.CRUMBS_TEXT_EFFECT=old;rmSync(cwd,{recursive:true,force:true})}
})
