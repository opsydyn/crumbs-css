import {expect,test} from 'bun:test'
import {mkdtempSync,writeFileSync,rmSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {createRequire} from 'node:module'
const require=createRequire(import.meta.url)
const esbuild=require(require.resolve('esbuild',{paths:[require.resolve('@vanilla-extract/integration')]}))

test('complete witness invalidates a newly preferred TypeScript dependency',async()=>{
 const m=await import('../src/compiler/compiled-text-witness').catch(()=>undefined)
 expect(typeof m?.captureCompiledTextWitness).toBe('function');if(!m)return
 const cwd=mkdtempSync(join(tmpdir(),'crumbs-witness-')),entry=join(cwd,'entry.ts')
 const compile=()=>esbuild.build({entryPoints:[entry],absWorkingDir:cwd,bundle:true,write:false,platform:'node',format:'cjs',metafile:true})
 try{
  writeFileSync(entry,'import {width} from "./probe-input"; export {width};');writeFileSync(join(cwd,'probe-input.js'),'export const width = 11;')
  const before=await compile(),r=m.captureCompiledTextWitness({owner:entry,key:'key',cwd,absoluteEntryPath:entry,options:{}},before.metafile.inputs)
  expect(r.kind).toBe('eligible');if(r.kind!=='eligible')return
  expect(m.validateCompiledTextWitness(r.witness)).toBe(true)
  writeFileSync(join(cwd,'probe-input.ts'),'export const width = 22;')
  expect(m.validateCompiledTextWitness(r.witness)).toBe(false)
  const after=await compile();expect(after.outputFiles[0].text).toContain('width = 22');expect(before.outputFiles[0].text).toContain('width = 11')
 }finally{rmSync(cwd,{recursive:true,force:true})}
})

import * as fs from 'node:fs'
async function graph(run:(root:string,m:any,compile:()=>Promise<any>,request:any)=>Promise<void>){
 const m=await import('../src/compiler/compiled-text-witness').catch(()=>undefined);expect(typeof m?.captureCompiledTextWitness).toBe('function');if(!m)return
 const root=mkdtempSync(join(tmpdir(),'crumbs-witness-')),entry=join(root,'entry.ts')
 const request={owner:entry,key:'fixture',cwd:root,absoluteEntryPath:entry,options:{}}
 writeFileSync(entry,'import {width} from "./dep"; export {width};');writeFileSync(join(root,'dep.ts'),'export const width = 11;')
 const compile=()=>esbuild.build({entryPoints:[entry],absWorkingDir:root,bundle:true,write:false,platform:'node',format:'cjs',metafile:true})
 try{await run(root,m,compile,request)}finally{rmSync(root,{recursive:true,force:true})}
}
for(const change of ['bytes','config','lock','directory','symlink','package'] as const)test('witness detects '+change,()=>graph(async(root,m,compile,request)=>{
 if(change==='symlink'){fs.renameSync(join(root,'dep.ts'),join(root,'a.ts'));writeFileSync(join(root,'b.ts'),'export const width = 22;');fs.symlinkSync('./a.ts',join(root,'dep.ts'))}
 const r=m.captureCompiledTextWitness(request,(await compile()).metafile.inputs);expect(r.kind).toBe('eligible');if(r.kind!=='eligible')return
 if(change==='bytes'){const s=fs.statSync(join(root,'dep.ts'));writeFileSync(join(root,'dep.ts'),'export const width = 22;');fs.utimesSync(join(root,'dep.ts'),s.atime,s.mtime)}
 if(change==='config')writeFileSync(join(root,'tsconfig.json'),'{}')
 if(change==='lock')writeFileSync(join(root,'bun.lock'),'new lock')
 if(change==='package')writeFileSync(join(root,'package.json'),'{"name":"new-scope"}')
 if(change==='directory')fs.mkdirSync(join(root,'dep'))
 if(change==='symlink'){fs.unlinkSync(join(root,'dep.ts'));fs.symlinkSync('./b.ts',join(root,'dep.ts'))}
 expect(m.validateCompiledTextWitness(r.witness)).toBe(false)
}))
test('witness rejects unsupported syntax/config/options and malformed receipts',()=>graph(async(root,m,compile,request)=>{
 const inputs=(await compile()).metafile.inputs
 expect(m.captureCompiledTextWitness({...request,options:{plugins:[{}]}},inputs).kind).toBe('fresh')
 for(const body of ['export const x = import("./dep");','export function x(p:string){ return require(p); }']){
  writeFileSync(join(root,'entry.ts'),body);expect(m.captureCompiledTextWitness(request,(await compile()).metafile.inputs).kind).toBe('fresh')
 }
 writeFileSync(join(root,'entry.ts'),'export const x=1;');writeFileSync(join(root,'tsconfig.json'),'{"compilerOptions":{"paths":{"a":["./b"]}}}')
 expect(m.captureCompiledTextWitness(request,(await compile()).metafile.inputs).kind).toBe('fresh')
 for(const value of [null,{}, {version:1,files:[]}, {version:1,files:Array(513).fill({})}])expect(m.decodeCompiledTextWitness(value)).toBeUndefined()
}))
test('witness includes exact package self-reference and local JSONC extends',()=>graph(async(root,m,compile,request)=>{
 writeFileSync(join(root,'package.json'),'{"name":"fixture","exports":{"./dep":"./dep.ts"}}')
 writeFileSync(join(root,'entry.ts'),'import {width} from "fixture/dep"; export {width};')
 writeFileSync(join(root,'tsconfig.json'),'{/* comment */ "extends":"./base.json",}')
 writeFileSync(join(root,'base.json'),'{"compilerOptions":{"target":"ESNext"}}')
 const r=m.captureCompiledTextWitness(request,(await compile()).metafile.inputs);expect(r.kind).toBe('eligible');if(r.kind!=='eligible')return
 expect(m.validateCompiledTextWitness(r.witness)).toBe(true)
 writeFileSync(join(root,'base.json'),'{"compilerOptions":{"target":"ES2020"}}');expect(m.validateCompiledTextWitness(r.witness)).toBe(false)
}))

test('directory package manifest contents participate in relative resolution',()=>graph(async(root,m,compile,request)=>{
 rmSync(join(root,'dep.ts'));fs.mkdirSync(join(root,'dep'));writeFileSync(join(root,'dep/package.json'),'{"main":"./one.js"}');writeFileSync(join(root,'dep/one.js'),'export const width=11');writeFileSync(join(root,'dep/two.js'),'export const width=22')
 const r=m.captureCompiledTextWitness(request,(await compile()).metafile.inputs);expect(r.kind).toBe('eligible');if(r.kind!=='eligible')return
 writeFileSync(join(root,'dep/package.json'),'{"main":"./two.js"}');expect(m.validateCompiledTextWitness(r.witness)).toBe(false);expect((await compile()).outputFiles[0].text).toContain('width = 22')
}))
test('a missing entry of an unselected directory package invalidates fallback',()=>graph(async(root,m,compile,request)=>{
 // A main target may itself resolve through a second directory package.
 rmSync(join(root,'dep.ts'));fs.mkdirSync(join(root,'dep'));fs.mkdirSync(join(root,'dep/choice'));writeFileSync(join(root,'dep/package.json'),'{"main":"./choice"}');writeFileSync(join(root,'dep/choice/package.json'),'{"main":"./missing.js"}');writeFileSync(join(root,'dep/index.js'),'export const width=11');writeFileSync(join(root,'dep/choice/other.js'),'export const width=22')
 const r=m.captureCompiledTextWitness(request,(await compile()).metafile.inputs);expect(r.kind).toBe('eligible');if(r.kind!=='eligible')return
 writeFileSync(join(root,'dep/choice/package.json'),'{"main":"./other.js"}');expect(m.validateCompiledTextWitness(r.witness)).toBe(false)
}))

test('unrelated sibling files do not invalidate a complete resolution witness',()=>graph(async(root,m,compile,request)=>{
 const r=m.captureCompiledTextWitness(request,(await compile()).metafile.inputs);expect(r.kind).toBe('eligible');if(r.kind!=='eligible')return
 writeFileSync(join(root,'unrelated-log.txt'),'effect');expect(m.validateCompiledTextWitness(r.witness)).toBe(true)
}))

test('new extension candidates inside a symlinked package invalidate its witness',()=>graph(async(root,m,compile,request)=>{
 fs.mkdirSync(join(root,'workspace'));fs.mkdirSync(join(root,'node_modules'));fs.symlinkSync('../workspace',join(root,'node_modules/token-pkg'))
 writeFileSync(join(root,'workspace/package.json'),'{"name":"token-pkg","main":"./entry"}');writeFileSync(join(root,'workspace/entry.js'),'export const width=11')
 writeFileSync(join(root,'entry.ts'),'import {width} from "token-pkg";export {width}')
 const before=await compile(),r=m.captureCompiledTextWitness(request,before.metafile.inputs);expect(r.kind).toBe('eligible');if(r.kind!=='eligible')return
 writeFileSync(join(root,'workspace/entry.ts'),'export const width=22');expect(m.validateCompiledTextWitness(r.witness)).toBe(false);expect((await compile()).outputFiles[0].text).toContain('width = 11') // package main lookup retains JS precedence; the witness conservatively observes both
}))

test('oversized graphs, payloads, denied reads and config cycles use fresh compilation',()=>graph(async(root,m,compile,request)=>{
 const inputs=(await compile()).metafile.inputs
 expect(m.captureCompiledTextWitness(request,Object.fromEntries(Array.from({length:513},(_,i)=>[i+'.ts',{imports:[]}]))).kind).toBe('fresh')
 expect(m.captureCompiledTextWitness(request,{'entry.ts':{imports:Array.from({length:1025},()=>({path:'node:fs',kind:'import-statement',external:true}))}}).kind).toBe('fresh')
 fs.chmodSync(join(root,'dep.ts'),0);try{expect(m.captureCompiledTextWitness(request,inputs).kind).toBe('fresh')}finally{fs.chmodSync(join(root,'dep.ts'),0o600)}
 writeFileSync(join(root,'dep.ts'),' '.repeat(1048577));expect(m.captureCompiledTextWitness(request,inputs).kind).toBe('fresh');writeFileSync(join(root,'dep.ts'),'export const width=11')
 writeFileSync(join(root,'tsconfig.json'),'{"extends":"./base.json"}');writeFileSync(join(root,'base.json'),'{"extends":"./tsconfig.json"}');expect(m.captureCompiledTextWitness(request,inputs).kind).toBe('fresh')
 for(let i=0;i<65;i++)writeFileSync(join(root,`${i}.json`),JSON.stringify(i===64?{}:{extends:`./${i+1}.json`}))
 writeFileSync(join(root,'tsconfig.json'),'{"extends":"./0.json"}');expect(m.captureCompiledTextWitness(request,inputs).kind).toBe('fresh')
}))

test('truncating or weakening a populated witness is rejected before filesystem reuse',()=>graph(async(root,m,compile,request)=>{
 const result=m.captureCompiledTextWitness(request,(await compile()).metafile.inputs);expect(result.kind).toBe('eligible');if(result.kind!=='eligible')return
 for(const alter of [
  (w:any)=>{w.files.pop()},
  (w:any)=>{w.directories.pop()},
  (w:any)=>{w.imports=[]},
  (w:any)=>{w.directories[0].names=[];w.directories[0].entries=[]},
 ]){const truncated=structuredClone(result.witness);alter(truncated);expect(m.decodeCompiledTextWitness(truncated)).toBeUndefined()}
}))
