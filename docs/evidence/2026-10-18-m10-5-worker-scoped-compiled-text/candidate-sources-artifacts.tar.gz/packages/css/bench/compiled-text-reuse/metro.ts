import {mkdirSync,writeFileSync,readFileSync,readdirSync,realpathSync,symlinkSync,existsSync} from 'node:fs'
import {join,resolve} from 'node:path'
import {createServer} from 'node:net'
import {spawn} from 'node:child_process'
import {runInNewContext} from 'node:vm'
import {createHash} from 'node:crypto'
const [controlArg,candidateArg,outputArg]=process.argv.slice(2)
if(!controlArg||!candidateArg||!outputArg)throw Error('Expected control root, candidate root, fresh output root')
const control=resolve(controlArg),candidate=resolve(candidateArg),out=resolve(outputArg)
mkdirSync(out,{recursive:false});const app=join(out,'app'),modules=join(app,'node_modules'),cache=join(out,'cache');mkdirSync(modules,{recursive:true});mkdirSync(cache);mkdirSync(join(out,'file-map'))
for(const source of [join(candidate,'apps/storybook/node_modules'),join(candidate,'packages/css/node_modules'),join(candidate,'node_modules')]){
 for(const name of readdirSync(source)){
  if(name.startsWith('.')||name==='@opsydyn')continue
  if(name.startsWith('@')){mkdirSync(join(modules,name),{recursive:true});for(const child of readdirSync(join(source,name))){const dest=join(modules,name,child);if(!existsSync(dest))try{symlinkSync(realpathSync(join(source,name,child)),dest)}catch{}}}
  else if(!existsSync(join(modules,name)))try{symlinkSync(realpathSync(join(source,name)),join(modules,name))}catch{}
 }
}
writeFileSync(join(app,'package.json'),JSON.stringify({name:'crumbs-text-metro-fixture',version:'1.0.0',main:'index.js',dependencies:{expo:JSON.parse(readFileSync(join(modules,'expo/package.json'),'utf8')).version,'react-native':JSON.parse(readFileSync(join(modules,'react-native/package.json'),'utf8')).version}}))
writeFileSync(join(app,'app.json'),'{"expo":{"name":"Crumbs text proof","slug":"crumbs-text-proof"}}')
writeFileSync(join(app,'tsconfig.json'),'{}');writeFileSync(join(app,'babel.config.js'),"module.exports={presets:['babel-preset-expo']};")
writeFileSync(join(app,'index.js'),"import {box} from './card.css';globalThis.__crumbsTextProof=box;")
writeFileSync(join(app,'value.js'),'export const width=11111;')
const observations:any[]=[];let owned:any
const digest=(s:string)=>createHash('sha256').update(s).digest('hex')
async function port(){const s=createServer();await new Promise<void>(r=>s.listen(0,'127.0.0.1',r));const p=(s.address() as any).port;await new Promise<void>(r=>s.close(()=>r()));return p}
async function stop(){if(!owned)return;const p=owned;owned=undefined;p.kill('SIGTERM');await Promise.race([new Promise<void>(r=>p.once('exit',()=>r())),new Promise<void>(r=>setTimeout(()=>{p.kill('SIGKILL');r()},5000))])}
function configure(root:string,label:string){
 const pkg=join(root,'packages/css'),trace=join(out,label+'.jsonl'),wrapper=join(out,(root===candidate?'candidate':'control')+'.cjs')
 writeFileSync(join(app,'card.css.ts'),`import {viewStyle} from ${JSON.stringify(join(pkg,'dist/style.mjs'))};import {width} from './value';export const box=viewStyle({width});`)
 if(!existsSync(wrapper))writeFileSync(wrapper,`const t=require(${JSON.stringify(join(pkg,'dist/transformer.cjs'))}),fs=require('node:fs');exports.getCacheKey=t.getCacheKey;exports.transform=async(...args)=>{const r=await t.transform(...args);fs.appendFileSync(process.env.CRUMBS_TEXT_TRACE,JSON.stringify({filename:args[2],session:args[0].__crumbsNativeCacheSession,metadata:r.__crumbsNativeStyles})+'\\n');return r;};`)
 writeFileSync(join(app,'metro.config.js'),`const {getDefaultConfig}=require('expo/metro-config');const {FileStore}=require('metro-cache');const {withNativeStyles}=require(${JSON.stringify(join(pkg,'dist/metro-plugin.cjs'))});const c=getDefaultConfig(__dirname);c.watchFolders=${JSON.stringify([out,join(candidate,'node_modules'),join(candidate,'packages/css'),join(control,'packages/css')])};c.resolver.useWatchman=false;c.resolver.nodeModulesPaths=[__dirname+'/node_modules'];c.transformer={...c.transformer,upstreamTransformerPath:c.transformerPath};c.cacheStores=[new FileStore({root:${JSON.stringify(cache)}})];c.fileMapCacheDirectory=${JSON.stringify(join(out,'file-map'))};c.maxWorkers=1;const config=withNativeStyles(c);config.transformerPath=${JSON.stringify(wrapper)};module.exports=config;`)
 return trace
}
async function start(root:string,label:string){const trace=configure(root,label),p=await port(),log=join(out,label+'.log');owned=spawn(process.env.CRUMBS_M105_NODE??'node',[join(modules,'expo/bin/cli'),'start','--offline','--port',String(p),'--max-workers','1'],{cwd:app,env:{...process.env,EXPO_NO_TYPESCRIPT_SETUP:'1',CRUMBS_TEXT_TRACE:trace,CI:'1',EXPO_NO_TELEMETRY:'1',NODE_OPTIONS:'--dns-result-order=ipv4first'},stdio:['ignore','pipe','pipe']});owned.stdout.on('data',(b:Buffer)=>require('node:fs').appendFileSync(log,b));owned.stderr.on('data',(b:Buffer)=>require('node:fs').appendFileSync(log,b));
 const url=`http://127.0.0.1:${p}/index.bundle?platform=web&dev=true&minify=false&hot=false&lazy=false`
 for(let i=0;i<120;i++){if(owned.exitCode!==null)throw Error('Metro exited: '+readFileSync(log,'utf8'));try{const r=await fetch(`http://127.0.0.1:${p}/status`);if(r.ok)return {url,trace}}catch{}await new Promise(r=>setTimeout(r,250))}throw Error('Metro start timeout')
}
function cacheKeys(root:string):string[]{return readdirSync(root,{withFileTypes:true}).flatMap(e=>e.isDirectory()?cacheKeys(join(root,e.name)):[join(root,e.name).slice(cache.length+1)]).sort()}
async function read(url:string,trace:string,stage:string,expected:number){const response=await fetch(url);const text=await response.text();if(!response.ok)throw Error(stage+': '+text.slice(0,1500));const context:any={console,process:{env:{NODE_ENV:'development'}},setTimeout,clearTimeout};context.global=context;context.globalThis=context;runInNewContext(text,context);const value=context.__crumbsTextProof;const width=Array.isArray(value)?Object.assign({},...value).width:value?.width;if(width!==expected)throw Error(stage+': expected '+expected+' got '+JSON.stringify(value));writeFileSync(join(out,stage.replaceAll(' ','-')+'.bundle.js'),text);const rows=existsSync(trace)?readFileSync(trace,'utf8').trim().split('\n').filter(Boolean).map(l=>JSON.parse(l)):[];observations.push({stage,expected,width,bundleSha256:digest(text),transforms:rows.length,native:rows.filter(r=>r.metadata).length,verified:rows.filter(r=>r.metadata?.reuse==='verified').length,sessionSeen:rows.some(r=>r.session?.version===1),ordinaryFiles:rows.filter(r=>!r.metadata).map(r=>r.filename),keys:cacheKeys(cache)});return rows}
try{
 for(const [root,label]of [[control,'control'],[candidate,'candidate']] as const){
  const server=await start(root,label);await read(server.url,server.trace,label+' initial',11111);await read(server.url,server.trace,label+' repeated',11111)
  writeFileSync(join(app,'value.ts'),'export const width=22222;');await new Promise(r=>setTimeout(r,300));await read(server.url,server.trace,label+' new candidate',22222)
  require('node:fs').unlinkSync(join(app,'value.ts'));await new Promise(r=>setTimeout(r,300));await read(server.url,server.trace,label+' restore',11111);await stop()
 }
 for(let i=0;i<3;i++){const restarted=await start(candidate,'restart'+i);await read(restarted.url,restarted.trace,'candidate restart'+i,11111);await stop()}
 const candidateRows=observations.filter(r=>r.stage.startsWith('candidate'))
 if(!candidateRows.every(r=>r.verified>0))throw Error('eligible Metro fixture never produced verified native metadata')
 if(candidateRows[0].native!==candidateRows[1].native)throw Error('same-session native cache missed')
 const restarts=candidateRows.filter(r=>r.stage.includes('restart'))
 if(restarts.some(r=>r.ordinaryFiles.length))throw Error('ordinary modules missed after restart')
 if(restarts.some(r=>JSON.stringify(r.keys)!==JSON.stringify(candidateRows[3].keys)))throw Error('store keys grew or changed across restarts')
 writeFileSync(join(out,'result.json'),JSON.stringify({passed:true,observations},null,2))
}catch(e){writeFileSync(join(out,'result.json'),JSON.stringify({passed:false,error:String(e),observations},null,2));throw e}finally{await stop()}
