import {createHash} from 'node:crypto'
import {readFileSync} from 'node:fs'
import {isAbsolute,relative,resolve} from 'node:path'
export function verifyCompiledTextEvidence(packetRoot:string):readonly string[]{
 const errors:string[]=[]
 try{
  const p=JSON.parse(readFileSync(resolve(packetRoot,'packet.json'),'utf8'))
  if(p.version!==1||!['accepted','rejected','incomplete'].includes(p.disposition)||!/^[a-f0-9]{64}$/.test(p.source))return ['invalid packet identity']
  if(!Array.isArray(p.files)||!p.files.length||!Array.isArray(p.pairs)||!p.gates||typeof p.gates!=='object')return ['missing observations']
  for(const f of p.files){
   if(typeof f.path!=='string'||isAbsolute(f.path)||relative(resolve(packetRoot),resolve(packetRoot,f.path)).startsWith('..')){errors.push('invalid file path');continue}
   try{if(createHash('sha256').update(readFileSync(resolve(packetRoot,f.path))).digest('hex')!==f.sha256)errors.push('file digest: '+f.path)}catch{errors.push('missing file: '+f.path)}
  }
  for(const {control,candidate} of p.pairs){
   if(candidate?.source!==p.source)errors.push('candidate source differs')
   if(!control?.output||control.output!==candidate?.output)errors.push('output differs')
   if(!Array.isArray(control?.inputs)||JSON.stringify(control.inputs)!==JSON.stringify(candidate?.inputs))errors.push('inputs differ')
  }
  if(p.disposition==='accepted')for(const gate of ['witness','memo','transformer','metro','isolation','sdk','native','host'])if(p.gates[gate]!=='passed')errors.push('unqualified gate: '+gate)
  if(p.disposition==='rejected'&&!Object.values(p.gates).includes('failed'))errors.push('rejection missing failed gate')
 }catch{errors.push('unreadable packet')}
 return errors
}
if(import.meta.main){const root=process.argv[2];if(!root)throw Error('Expected packet root');const errors=verifyCompiledTextEvidence(root);console.log(JSON.stringify({valid:errors.length===0,errors},null,2));if(errors.length)process.exitCode=1}
